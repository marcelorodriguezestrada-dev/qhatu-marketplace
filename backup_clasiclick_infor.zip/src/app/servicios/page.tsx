'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import dynamic from 'next/dynamic'
import { usePathname, useRouter } from 'next/navigation'
import { ServiceIcon } from '@/components/ServiceIcon'
import { useCategorias } from '@/lib/useCategorias'
import { esPremiumVigente } from '@/lib/planPremium'
import { ChipsCiudad, useFiltroCiudad } from '@/components/SelectorCiudad'
import { buscarCiudad, ciudadDe, ciudadEnTexto, profesionalEnCiudad } from '@/data/ciudades'
import BuscadorServicios from '@/components/BuscadorServicios'
import { coincideServicio } from '@/lib/busquedaServicios'

const MapaProfesionales = dynamic(() => import('@/components/MapaProfesionales').then((m) => m.MapaProfesionales), {
  ssr: false,
  loading: () => <div className="w-full h-[380px] rounded-xl border border-line bg-panelalt flex items-center justify-center font-body text-sm text-inksoft">Cargando mapa...</div>,
})

type Profesional = {
  id: string
  nombre: string
  rubro: string
  especialidad?: string
  descripcion: string
  zona: string
  direccion?: string
  dondeTrabaja?: string
  educacion?: string
  lat: number | null
  lng: number | null
  icono: string
  imagenUrl?: string
  precio?: number | null
  experiencia?: string
  servicios?: string[]
  ciudad?: string
  atiendeOnline?: boolean
  atiendePresencial?: boolean
  viajaA?: string[]
  plan: string
  ratingPromedio: number
  cantidadResenas: number
}

function bs(n: number) {
  return 'Bs ' + n.toLocaleString('es-BO')
}

// Fórmula de Haversine — distancia en km entre dos puntos geográficos.
function distanciaKm(lat1: number, lng1: number, lat2: number, lng2: number) {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

function Estrellas({ valor }: { valor: number }) {
  return (
    <span className="text-ochre font-body text-xs">
      {'★'.repeat(Math.round(valor))}
      {'☆'.repeat(5 - Math.round(valor))}
    </span>
  )
}

export default function ServiciosPage() {
  const { categorias, rubrosFlat, buscarRubro } = useCategorias()
  const [profesionales, setProfesionales] = useState<Profesional[]>([])
  const [categoriaSel, setCategoriaSel] = useState('Todo')
  const [grupoSel, setGrupoSel] = useState('Todo')
  const [rubro, setRubro] = useState('Todo')

  // Los links de las migas de pan del perfil de un profesional apuntan
  // acá con ?categoria=...&grupo=...&rubro=... — antes esos parámetros
  // se ignoraban por completo (el click no filtraba nada). Se leen una
  // sola vez al montar; de ahí en más manda lo que el usuario toque.
  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const cat = params.get('categoria')
    const grupo = params.get('grupo')
    const rub = params.get('rubro')
    if (cat) setCategoriaSel(cat)
    if (grupo) setGrupoSel(grupo)
    if (rub) setRubro(rub)
  }, [])
  const [busqueda, setBusqueda] = useState('')
  const [orden, setOrden] = useState<'calificacion' | 'cercania'>('calificacion')
  const [ubicacion, setUbicacion] = useState<{ lat: number; lng: number } | null>(null)
  const [buscandoUbicacion, setBuscandoUbicacion] = useState(false)
  const [errorUbicacion, setErrorUbicacion] = useState('')
  const [vista, setVista] = useState<'lista' | 'mapa'>('lista')
  const router = useRouter()
  const pathname = usePathname()

  // Filtro geográfico por defecto: Potosí, Bolivia
  const [soloPotosi, setSoloPotosi] = useState(false)
  const POTOSI = { lat: -19.5886, lng: -65.7531 }
  const POTOSI_RADIUS_KM = 50

  useEffect(() => {
    if (typeof window === 'undefined') return
    const params = new URLSearchParams(window.location.search)
    const q = params.get('q') || ''
    if (q) setBusqueda(q)
    const categoriaParam = params.get('categoria')
    if (categoriaParam) setCategoriaSel(categoriaParam)
    const rubroParam = params.get('rubro')
    if (rubroParam) setRubro(rubroParam)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    fetch('/api/profesionales')
      .then((r) => r.json())
      .then((data) => setProfesionales(data.profesionales || []))
  }, [])

  function pedirUbicacion(luegoMostrarMapa: boolean) {
    setErrorUbicacion('')
    setBuscandoUbicacion(true)
    if (!navigator.geolocation) {
      setErrorUbicacion('Tu navegador no soporta geolocalización.')
      setBuscandoUbicacion(false)
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUbicacion({ lat: pos.coords.latitude, lng: pos.coords.longitude })
        if (luegoMostrarMapa) setVista('mapa')
        else setOrden('cercania')
        setBuscandoUbicacion(false)
      },
      () => {
        setErrorUbicacion('No pudimos acceder a tu ubicación. Revisá los permisos del navegador.')
        setBuscandoUbicacion(false)
      }
    )
  }

  // Rubros que pertenecen a la categoría elegida — así el filtro "por
  // categoría" incluye a cualquier profesional cuyo rubro esté en esa
  // categoría, sea un rubro de la base o uno agregado después.
  const rubrosDeCategoria = categorias.find((c) => c.id === categoriaSel)?.rubros || []
  const rubroIdsDeCategoria = rubrosDeCategoria.map((r) => r.id)

  // Grupos (nivel intermedio) presentes en esta categoría, sin repetir
  // y en el orden en que vienen del servidor.
  const gruposDeCategoria = rubrosDeCategoria.reduce<{ id: string; label: string }[]>((acc, r) => {
    if (r.grupo && !acc.some((g) => g.id === r.grupo!.id)) acc.push({ id: r.grupo.id, label: r.grupo.label })
    return acc
  }, [])

  // Rubros que se muestran como botones del tercer nivel: si hay un
  // grupo elegido, solo los de ese grupo; si no, todos los de la categoría.
  const rubrosVisibles = grupoSel === 'Todo'
    ? rubrosDeCategoria
    : rubrosDeCategoria.filter((r) => r.grupo?.id === grupoSel)
  const rubroIdsDeGrupo = rubrosVisibles.map((r) => r.id)

  // Ciudad: el filtro "📍 Buscar en" (o la ciudad escrita en la
  // búsqueda: "abogado en La Paz").
  const { valor: ciudadFiltro, cambiar: cambiarCiudadFiltro, multiciudad } = useFiltroCiudad()
  const { ciudad: ciudadDelTexto, resto: textoBusqueda } = ciudadEnTexto(busqueda)
  const ciudadBuscada = ciudadDelTexto || ciudadFiltro
  const sinAcentos = (t: string) => t.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
  const q = sinAcentos(textoBusqueda.trim())

  // Cada palabra tiene que estar (nombre, especialidad, rubro, grupo,
  // categoría, servicios, zona), con plurales, femenino y sinónimos
  // ("doctor" → médico) — ver src/lib/busquedaServicios.ts.
  const coincideTexto = (p: Profesional) => {
    const r = rubrosFlat.find((x) => x.id === p.rubro)
    return coincideServicio(p, r ? { label: r.label, grupoLabel: r.grupoLabel, categoriaLabel: r.categoriaLabel } : undefined, textoBusqueda, { parcial: true })
  }

  // Cuántos profesionales hay (en la ciudad elegida) por rubro, grupo y
  // categoría: las filas de botones solo muestran lo que tiene resultados.
  const enCiudad = profesionales.filter((p) => profesionalEnCiudad(p, ciudadBuscada))
  const conteo: Record<string, number> = {}
  for (const p of enCiudad) {
    const r = rubrosFlat.find((x) => x.id === p.rubro)
    if (!r) continue
    for (const k of [r.id, `c:${r.categoriaId}`, r.grupoId ? `g:${r.grupoId}` : '']) if (k) conteo[k] = (conteo[k] || 0) + 1
  }
  const cuenta = (k: string) => (conteo[k] ? ` (${conteo[k]})` : '')

  const coincideBusqueda = (p: Profesional) => {
    let matchRubro = true
    if (rubro !== 'Todo') matchRubro = p.rubro === rubro
    else if (grupoSel !== 'Todo') matchRubro = rubroIdsDeGrupo.includes(p.rubro)
    else if (categoriaSel !== 'Todo') matchRubro = rubroIdsDeCategoria.includes(p.rubro)
    return matchRubro && (!q || coincideTexto(p))
  }
  // Para el aviso "no hay en tu ciudad, pero hay N en otras".
  const enOtrasCiudades = ciudadBuscada === 'todas' ? 0 : profesionales.filter((p) => coincideBusqueda(p) && !profesionalEnCiudad(p, ciudadBuscada)).length

  let filtrados = profesionales.filter((p) => {
    if (!profesionalEnCiudad(p, ciudadBuscada)) return false
    if (soloPotosi) {
      const zonaRaw = (p.zona || '').toLowerCase()
          const zonaNormalized = zonaRaw.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
      const zonaMatch = zonaNormalized.includes('potos')
      const hasCoords = p.lat != null && p.lng != null
      const withinRadius = hasCoords && distanciaKm(POTOSI.lat, POTOSI.lng, p.lat as number, p.lng as number) <= POTOSI_RADIUS_KM
      if (!zonaMatch && !withinRadius) return false
    }

    // Todo (sin categoría ni rubro elegido) siempre muestra a todos
    // los profesionales, incluso los que quedaron con un rubro que
    // todavía no está en ninguna categoría — así nadie desaparece del
    // directorio por un dato de taxonomía incompleto.
    let matchRubro = true
    if (rubro !== 'Todo') {
      matchRubro = p.rubro === rubro
    } else if (grupoSel !== 'Todo') {
      // Elegido un grupo pero no una especialidad puntual: entran todos
      // los rubros de ese grupo (ej. "Médicos" trae clínicos,
      // ginecólogos, neurocirujanos, etc.).
      matchRubro = rubroIdsDeGrupo.includes(p.rubro)
    } else if (categoriaSel !== 'Todo') {
      matchRubro = rubroIdsDeCategoria.includes(p.rubro)
    }

    return matchRubro && (!q || coincideTexto(p))
  })

  if (orden === 'cercania' && ubicacion) {
    filtrados = [...filtrados].sort((a, b) => {
      const da = a.lat != null && a.lng != null ? distanciaKm(ubicacion.lat, ubicacion.lng, a.lat, a.lng) : Infinity
      const db = b.lat != null && b.lng != null ? distanciaKm(ubicacion.lat, ubicacion.lng, b.lat, b.lng) : Infinity
      return da - db
    })
  } else {
    filtrados = [...filtrados].sort((a, b) => (b.ratingPromedio || 0) - (a.ratingPromedio || 0))
  }

  // Beneficio Premium: aparecer primero, sin importar el criterio de
  // orden elegido arriba. .sort es estable, así que esto no desordena
  // lo que ya se ordenó por cercanía/rating dentro de cada grupo
  // (premium entre sí, básicos entre sí) — solo antepone un grupo al otro.
  filtrados = [...filtrados].sort((a, b) => (esPremiumVigente(b) ? 1 : 0) - (esPremiumVigente(a) ? 1 : 0))

  return (
    <div className="min-h-screen">
      <div className="bg-ink px-5 py-3.5">
        <div className="max-w-[960px] mx-auto flex items-center gap-2 flex-wrap">
          <Link href="/" className="font-display text-xl font-bold text-white shrink-0">Clasi Click</Link>
          <span className="font-body text-sm text-white/70 hidden sm:inline sm:flex-1">Servicios profesionales</span>
          <div className="flex items-center gap-2 ml-auto">
            <Link
              href="/publicar-servicio"
              className="border-none bg-white/10 text-white px-3 py-2 rounded-lg font-body text-xs sm:text-sm shrink-0 whitespace-nowrap"
            >
              Publicá tu servicio
            </Link>
            <Link
              href="/mi-perfil"
              className="border border-white/20 text-white px-3 py-2 rounded-lg font-body text-xs sm:text-sm shrink-0 whitespace-nowrap"
            >
              Mi perfil
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-[960px] mx-auto px-5 py-6 pb-12">
        <div className="flex items-center gap-2 mb-4">
          <BuscadorServicios
            valor={busqueda}
            onCambiar={setBusqueda}
            onBuscar={(texto) => {
              const q = encodeURIComponent(texto || '')
              router.push(`${pathname}${q ? `?q=${q}` : ''}`)
            }}
            onElegirRubro={(r) => {
              setCategoriaSel(r.categoriaId)
              setGrupoSel(r.grupoId || 'Todo')
              setRubro(r.id)
            }}
            profesionales={enCiudad}
            rubrosFlat={rubrosFlat}
            placeholder={multiciudad ? 'Buscar (ej: abogado en La Paz)' : 'Buscar por nombre, rubro o zona'}
          />
          <button
            type="button"
            onClick={() => {
              const q = encodeURIComponent(busqueda || '')
              router.push(`${pathname}${q ? `?q=${q}` : ''}`)
            }}
            className="px-3 py-2 rounded-lg bg-maroon text-white text-sm"
            aria-label="Buscar servicios"
          >
            🔍
          </button>
        </div>

        <ChipsCiudad valor={ciudadDelTexto || ciudadFiltro} onChange={cambiarCiudadFiltro} className="mb-4 -mt-1" />
        {ciudadDelTexto && ciudadDelTexto !== ciudadFiltro && multiciudad && (
          <div className="font-body text-[12px] text-teal -mt-2 mb-3">Buscando en {buscarCiudad(ciudadDelTexto).nombre} (lo escribiste en la búsqueda)</div>
        )}

        {/* Un solo nivel de botones a la vez — categoría, o grupo, o
            especialidad — nunca los tres juntos. Las migas de pan de
            abajo ("Todos los servicios › Salud › Médicos") son la
            forma de volver a un nivel anterior; acá arriba solo se ve
            el paso siguiente, para no enterrar la pantalla en botones. */}
        {categoriaSel === 'Todo' && (
          <div className="flex gap-2 mb-3 items-center overflow-x-auto -mx-5 px-5 sm:mx-0 sm:px-0 pb-1" style={{ scrollbarWidth: 'none' }}>
            <button
              type="button"
              onClick={() => { setCategoriaSel('Todo'); setGrupoSel('Todo'); setRubro('Todo') }}
              aria-label="Todas las categorías"
              title="Todas las categorías"
              className="w-9 h-9 rounded-full border flex items-center justify-center text-base shrink-0 border-maroon bg-maroonsoft text-maroon"
            >
              🏠
            </button>
            {categorias.filter((c) => conteo[`c:${c.id}`]).map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setCategoriaSel(c.id)
                  setGrupoSel('Todo')
                  setRubro('Todo')
                  fetch('/api/analitica/categoria', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tipo: 'servicio', valor: c.id }),
                  }).catch(() => {})
                }}
                className="px-4 py-1.5 rounded-full border font-body text-sm font-medium border-line bg-panel text-inksoft shrink-0 whitespace-nowrap"
              >
                {c.label}<span className="text-[11px] opacity-70">{cuenta(`c:${c.id}`)}</span>
              </button>
            ))}
          </div>
        )}

        {/* Grupos de la categoría elegida (ej. "Médicos", "Salud
            mental") — solo mientras no se haya elegido un grupo
            todavía, y solo si esa categoría tiene grupos definidos
            (categorías simples como "Belleza" pasan directo a rubros). */}
        {categoriaSel !== 'Todo' && grupoSel === 'Todo' && gruposDeCategoria.length > 0 && (
          <div className="flex gap-2 mb-2 items-center overflow-x-auto -mx-5 px-5 sm:mx-0 sm:px-0 pb-1" style={{ scrollbarWidth: 'none' }}>
            <button
              type="button"
              onClick={() => { setGrupoSel('Todo'); setRubro('Todo') }}
              className="px-3.5 py-1.5 rounded-full border font-body text-xs font-medium border-maroon bg-maroonsoft text-maroon shrink-0 whitespace-nowrap"
            >
              Todo {categorias.find((c) => c.id === categoriaSel)?.label || ''}{cuenta(`c:${categoriaSel}`)}
            </button>
            {gruposDeCategoria.filter((g) => conteo[`g:${g.id}`]).map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => { setGrupoSel(g.id); setRubro('Todo') }}
                className="px-3.5 py-1.5 rounded-full border font-body text-xs font-medium border-line bg-panel text-inksoft shrink-0 whitespace-nowrap"
              >
                {g.label}<span className="opacity-70">{cuenta(`g:${g.id}`)}</span>
              </button>
            ))}
          </div>
        )}

        {/* Especialidades/rubros — recién cuando ya se pasó el nivel de
            grupo (o la categoría no tiene grupos, así que se salta
            directo acá). Esta fila SÍ se queda visible aunque ya
            hayas elegido una, para poder cambiar entre especialidades
            del mismo grupo sin tener que volver para atrás. */}
        {categoriaSel !== 'Todo' && (grupoSel !== 'Todo' || gruposDeCategoria.length === 0) && (
          <div className="flex gap-2 mb-2 items-center overflow-x-auto -mx-5 px-5 sm:mx-0 sm:px-0 pb-1" style={{ scrollbarWidth: 'none' }}>
            <button
              type="button"
              onClick={() => setRubro('Todo')}
              className={`px-3.5 py-1.5 rounded-full border font-body text-xs font-medium shrink-0 whitespace-nowrap ${
                rubro === 'Todo' ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
              }`}
            >
              {grupoSel === 'Todo' ? 'Todos los rubros' : `Todo ${gruposDeCategoria.find((g) => g.id === grupoSel)?.label || ''}`}
            </button>
            {rubrosVisibles.filter((r) => conteo[r.id] || rubro === r.id).map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => {
                  setRubro(r.id)
                  fetch('/api/analitica/categoria', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tipo: 'servicio', valor: r.id }),
                  }).catch(() => {})
                }}
                className={`px-3.5 py-1.5 rounded-full border font-body text-xs font-medium shrink-0 whitespace-nowrap ${
                  rubro === r.id ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                }`}
              >
                {r.label}<span className="opacity-70">{cuenta(r.id)}</span>
              </button>
            ))}
          </div>
        )}

        {/* Migas de pan: Categoría › Grupo › Rubro (ej. "Salud ›
            Médicos › Ginecólogo/a"). Cada nivel es clickeable para
            volver hacia atrás. */}
        {(categoriaSel !== 'Todo' || rubro !== 'Todo') && (
          <div className="font-body text-xs text-inksoft mb-4 flex items-center gap-1.5 flex-wrap">
            <button
              type="button"
              onClick={() => { setCategoriaSel('Todo'); setGrupoSel('Todo'); setRubro('Todo') }}
              className="hover:text-maroon hover:underline"
            >
              Todos los servicios
            </button>
            {categoriaSel !== 'Todo' && (
              <>
                <span className="text-line">›</span>
                <button
                  type="button"
                  onClick={() => { setGrupoSel('Todo'); setRubro('Todo') }}
                  className={`hover:text-maroon hover:underline ${grupoSel === 'Todo' && rubro === 'Todo' ? 'text-ink font-semibold' : ''}`}
                >
                  {categorias.find((c) => c.id === categoriaSel)?.label}
                </button>
              </>
            )}
            {grupoSel !== 'Todo' && (
              <>
                <span className="text-line">›</span>
                <button
                  type="button"
                  onClick={() => setRubro('Todo')}
                  className={`hover:text-maroon hover:underline ${rubro === 'Todo' ? 'text-ink font-semibold' : ''}`}
                >
                  {gruposDeCategoria.find((g) => g.id === grupoSel)?.label}
                </button>
              </>
            )}
            {rubro !== 'Todo' && (
              <>
                <span className="text-line">›</span>
                <span className="text-ink font-semibold">{buscarRubro(rubro)?.label || rubro}</span>
              </>
            )}
          </div>
        )}

        <div className="flex gap-3 mb-4 flex-wrap items-center">
          <div className="flex gap-1 bg-panelalt border border-line rounded-lg p-1">
            <button
              onClick={() => setVista('lista')}
              className={`px-3 py-1.5 rounded-md font-body text-xs font-semibold ${vista === 'lista' ? 'bg-panel text-ink shadow-sm' : 'text-inksoft'}`}
            >
              Lista
            </button>
            <button
              onClick={() => setVista('mapa')}
              disabled={buscandoUbicacion}
              className={`px-3 py-1.5 rounded-md font-body text-xs font-semibold ${vista === 'mapa' ? 'bg-panel text-ink shadow-sm' : 'text-inksoft'}`}
            >
              {buscandoUbicacion ? 'Ubicando...' : 'Mapa'}
            </button>
          </div>
        </div>

        {vista === 'lista' && (
          <div className="flex items-center gap-3 mb-5">
            <button
              onClick={() => setOrden('calificacion')}
              className={`font-body text-xs font-semibold ${orden === 'calificacion' ? 'text-maroon' : 'text-inksoft'}`}
            >
              Mejor calificados
            </button>
            <span className="text-inksoft text-xs">·</span>
            <button
              onClick={() => pedirUbicacion(false)}
              disabled={buscandoUbicacion}
              className={`font-body text-xs font-semibold ${orden === 'cercania' ? 'text-maroon' : 'text-inksoft'}`}
            >
              {buscandoUbicacion ? 'Buscando tu ubicación...' : 'Más cercanos'}
            </button>
          </div>
        )}
        {errorUbicacion && <div className="font-body text-xs text-maroon mb-4">{errorUbicacion}</div>}

        {vista === 'mapa' ? (
          <MapaProfesionales
            profesionales={filtrados.map((p) => ({ ...p, rubroLabel: buscarRubro(p.rubro)?.label }))}
            centro={ubicacion ?? (soloPotosi ? POTOSI : null)}
          />
        ) : (
          <div className="flex flex-col gap-3">
            {filtrados.map((p) => (
              <Link
                key={p.id}
                href={`/servicios/${p.id}`}
                className="bg-panel border border-line rounded-lg overflow-hidden flex items-stretch gap-4 p-3 hover:shadow-md transition-shadow"
              >
                <div className="w-28 h-28 rounded-lg bg-panelalt flex items-center justify-center text-maroon shrink-0 overflow-hidden relative">
                  {p.imagenUrl ? (
                    <img src={p.imagenUrl} alt={p.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
                  ) : (
                    <ServiceIcon kind={p.icono} size={40} />
                  )}
                  {esPremiumVigente(p) && (
                    <span className="absolute top-1.5 left-1.5 bg-ochre text-white text-[10px] font-semibold px-2 py-0.5 rounded-full font-body">
                      Destacado
                    </span>
                  )}
                </div>
                <div className="flex-1 py-1 flex flex-col justify-center min-w-0">
                  <div className="font-body text-[11px] text-inksoft mb-0.5">
                    {p.especialidad || buscarRubro(p.rubro)?.label || p.rubro}
                  </div>
                  <div className="font-display text-base font-semibold text-ink mb-1 truncate">{p.nombre}</div>
                  {p.precio ? (
                    <div className="font-body text-sm font-bold text-ink mb-1">{bs(p.precio)}</div>
                  ) : null}
                  {(p.zona || multiciudad) && (
                    <div className="font-body text-xs text-inksoft mb-1">
                      {multiciudad ? `📍 ${buscarCiudad(ciudadDe(p)).nombre}${p.zona ? ` · ${p.zona}` : ''}` : `Zona: ${p.zona}`}
                    </div>
                  )}
                  {(p.atiendeOnline || (multiciudad && p.viajaA && p.viajaA.length > 0)) && (
                    <div className="flex flex-wrap gap-1 mb-1">
                      {p.atiendeOnline && <span className="bg-indigo-50 text-indigo-700 font-body text-[10px] font-semibold px-1.5 py-0.5 rounded-full">💻 Atiende online</span>}
                      {multiciudad && p.viajaA && p.viajaA.length > 0 && (
                        <span className="bg-tealsoft text-teal font-body text-[10px] font-semibold px-1.5 py-0.5 rounded-full">🚗 Viaja a {p.viajaA.map((c) => buscarCiudad(c).nombre).join(', ')}</span>
                      )}
                    </div>
                  )}
                  {p.servicios && p.servicios.length > 0 && (
                    <div className="font-body text-[11px] text-inksoft mb-1 truncate">
                      {p.servicios.slice(0, 2).join(' · ')}
                    </div>
                  )}
                  {p.cantidadResenas > 0 ? (
                    <div className="flex items-center gap-1.5">
                      <Estrellas valor={p.ratingPromedio} />
                      <span className="font-body text-[11px] text-inksoft">({p.cantidadResenas})</span>
                    </div>
                  ) : (
                    <span className="font-body text-[11px] text-inksoft">Sin reseñas todavía</span>
                  )}
                </div>
              </Link>
            ))}
          </div>
        )}

        {vista === 'lista' && filtrados.length === 0 && (
          <div className="text-center py-14 text-inksoft font-body text-sm">
            {ciudadBuscada !== 'todas' && multiciudad ? `No encontramos profesionales en ${buscarCiudad(ciudadBuscada).nombre} para esta búsqueda.` : 'No hay profesionales publicados en esta categoría todavía.'}
            {enOtrasCiudades > 0 && multiciudad && (
              <div className="mt-3">
                <button type="button" onClick={() => { cambiarCiudadFiltro('todas'); if (ciudadDelTexto) setBusqueda(textoBusqueda) }} className="px-4 py-2 rounded-lg border border-teal bg-tealsoft text-teal font-semibold">
                  👉 Hay {enOtrasCiudades} en otras ciudades — Ver
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}