import { NextRequest, NextResponse } from 'next/server'
import { sumarCampana } from '@/lib/campanasServer'
import { sanearCiudad } from '@/data/ciudades'
import { cargarCiudadesServidor } from '@/lib/ciudadesServer'
import { getDb, getUsuarioDesdeRequest } from '@/lib/firebaseAdmin'
import { evaluarConIA, categorizarAnuncio } from '@/lib/moderacionIA'
import { validarWhatsappPorPais, numeroConCodigoPais } from '@/lib/validarWhatsapp'
import { buscarPais, PAIS_FALLBACK_ID } from '@/data/paises'
import { construirArbolCategorias } from '@/lib/categoriasServer'
import { esClaveAdmin } from '@/lib/adminAuth'
import { cabeceraCDN, enCache } from '@/lib/cacheLecturas'

export const dynamic = 'force-dynamic'

// GET — público: solo anuncios aprobados, los más nuevos primero.
// Con header x-admin-password válido, devuelve TODOS (para el panel
// de moderación en /admin).
export async function GET(req: NextRequest) {
  try {
    const db = getDb()
    const esAdmin = (await esClaveAdmin(req.headers.get('x-admin-password')))
    // Para el público: 1 minuto en memoria y en el CDN (ver /api/productos).
    const fresco = esAdmin || req.nextUrl.searchParams.has('fresco')
    const leer = async () => (await db.collection('anuncios').get()).docs.map((d) => ({ id: d.id, ...d.data() }))
    let anuncios = [...(fresco ? await leer() : await enCache('anuncios', 60_000, leer))] as any[]
    if (!esAdmin) anuncios = anuncios.filter((a) => a.estado === 'aprobado')
    anuncios.sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
    return NextResponse.json({ anuncios }, { headers: fresco || req.headers.get('x-admin-password') ? { 'Cache-Control': 'no-store' } : cabeceraCDN(60) })
  } catch (err) {
    console.error('GET /api/anuncios', err)
    return NextResponse.json({ error: 'No se pudieron cargar los anuncios.' }, { status: 500 })
  }
}

// POST — necesita estar logueado (así el anuncio queda atado a una
// cuenta real, y el admin sabe a quién pausar/eliminar si hace falta).
// Siempre entra como pendiente_revision, nunca se publica directo.
export async function POST(req: NextRequest) {
  const usuario = await getUsuarioDesdeRequest(req)
  if (!usuario) return NextResponse.json({ error: 'Necesitás iniciar sesión para publicar un anuncio.' }, { status: 401 })

  try {
    const body = await req.json()
    const { titulo, descripcion, tipo, whatsapp, whatsappPais, precio, imagenUrl, rubro } = body

    if (!titulo || !descripcion || !whatsapp) {
      return NextResponse.json({ error: 'Faltan datos (título, descripción y WhatsApp son obligatorios).' }, { status: 400 })
    }

    const paisId = whatsappPais || PAIS_FALLBACK_ID
    const validacionWhatsapp = validarWhatsappPorPais(whatsapp, paisId)
    if (!validacionWhatsapp.valido) {
      return NextResponse.json({ error: validacionWhatsapp.motivo }, { status: 400 })
    }
    const whatsappCompleto = numeroConCodigoPais(whatsapp, buscarPais(paisId).codigo)

    const moderacionIA = await evaluarConIA(`Anuncio clasificado.\nTítulo: ${titulo}\nDescripción: ${descripcion}`)

    // Si la persona ya eligió un rubro a mano (hoy solo pasa en tipo
    // "busqueda"), respetamos esa elección — la IA solo entra a
    // categorizar cuando no hay nada elegido, para cualquier tipo de
    // anuncio (no solo "busqueda"), así también se puede filtrar
    // /anuncios por rubro y el macheo cubre más casos.
    let rubroFinal = tipo === 'busqueda' && rubro ? rubro : null
    if (!rubroFinal) {
      try {
        const { rubrosFlat } = await construirArbolCategorias()
        rubroFinal = await categorizarAnuncio(`Título: ${titulo}\nDescripción: ${descripcion}`, rubrosFlat)
      } catch (err) {
        console.error('No se pudo categorizar el anuncio con IA:', err)
      }
    }

    const db = getDb()
    await cargarCiudadesServidor() // ciudades agregadas desde el admin
    const ref = await db.collection('anuncios').add({
      titulo,
      descripcion,
      tipo: tipo || 'otro',
      // Puede venir de que la persona lo eligió a mano, o de que la IA
      // lo categorizó sola con los rubros que ya existen (ver arriba) —
      // en null si ninguno de los dos casos aplicó.
      rubro: rubroFinal,
      whatsapp: whatsappCompleto,
      whatsappPais: paisId,
      precio: precio ? Number(precio) : null,
      imagenUrl: imagenUrl || '',
      ciudad: sanearCiudad(body.ciudad),
      autorUid: usuario.uid,
      autorEmail: usuario.email,
      estado: 'pendiente_revision',
      moderacionIA,
      vistas: 0,
      createdAt: new Date().toISOString(),
    })

    if (body.campana) await sumarCampana(body.campana, { anuncios: 1 })
    return NextResponse.json({ id: ref.id }, { status: 201 })
  } catch (err) {
    console.error('POST /api/anuncios', err)
    return NextResponse.json({ error: 'No se pudo publicar el anuncio.' }, { status: 500 })
  }
}
