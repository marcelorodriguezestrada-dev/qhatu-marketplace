import { NextRequest, NextResponse } from 'next/server'
import { getDb } from '@/lib/firebaseAdmin'
import { esClaveAdmin } from '@/lib/adminAuth'

export const dynamic = 'force-dynamic'

// Admin → Pedidos → "🌙 Quisieron comprar fuera de horario".
// GET → { compras } (más recientes primero, con si ya vio el aviso).
// PATCH { id, contactado: true } → marca que le escribiste por WhatsApp.
const autorizado = async (req: NextRequest) => {
  const pw = req.headers.get('x-admin-password')
  return (await esClaveAdmin(pw))
}

export async function GET(req: NextRequest) {
  if (!(await autorizado(req))) return NextResponse.json({ error: 'Contraseña de administrador inválida.' }, { status: 401 })
  try {
    const db = getDb()
    const snap = await db.collection('comprasFueraHorario').get()
    const compras = snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })).sort((a, b) => String(b.ultimoIntento).localeCompare(String(a.ultimoIntento))).slice(0, 300)
    const ids = compras.map((c) => c.notificacionId).filter(Boolean) as string[]
    const leidas = new Set<string>()
    for (let i = 0; i < ids.length; i += 100) {
      const docs = await db.getAll(...ids.slice(i, i + 100).map((id) => db.collection('notificaciones').doc(id)))
      docs.forEach((d) => { if (d.exists && d.data()?.leida) leidas.add(d.id) })
    }
    // Si no escribió su WhatsApp en el checkout, usamos el celular de su
    // cuenta (el que dejó al registrarse) para poder escribirle igual.
    const sinNumero = Array.from(new Set(compras.filter((c) => !c.whatsapp && c.uid).map((c) => c.uid as string)))
    const deCuenta = new Map<string, { whatsapp: string; nombre: string }>()
    for (let i = 0; i < sinNumero.length; i += 100) {
      const docs = await db.getAll(...sinNumero.slice(i, i + 100).map((uid) => db.collection('usuarios').doc(uid)))
      docs.forEach((d) => {
        const u = d.data()
        const numero = String(u?.whatsapp || u?.celular || '')
        if (numero) deCuenta.set(d.id, { whatsapp: numero, nombre: String(u?.nombre || '') })
      })
    }
    return NextResponse.json({
      compras: compras.map((c) => {
        const cuenta = !c.whatsapp ? deCuenta.get(c.uid) : undefined
        return { ...c, avisoLeido: leidas.has(c.notificacionId), ...(cuenta ? { whatsapp: cuenta.whatsapp, whatsappDeCuenta: true, nombre: c.nombre || cuenta.nombre } : {}) }
      }),
    })
  } catch (err) {
    console.error('GET /api/admin/fuera-horario', err)
    return NextResponse.json({ error: 'No se pudo leer la lista.' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  if (!(await autorizado(req))) return NextResponse.json({ error: 'Contraseña de administrador inválida.' }, { status: 401 })
  const b = await req.json().catch(() => ({}))
  if (!b.id) return NextResponse.json({ error: 'Falta el id.' }, { status: 400 })
  await getDb().collection('comprasFueraHorario').doc(String(b.id)).update({ contactadoAt: b.contactado ? new Date().toISOString() : null })
  return NextResponse.json({ ok: true })
}
