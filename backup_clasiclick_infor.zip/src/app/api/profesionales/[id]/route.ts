import { NextRequest, NextResponse } from 'next/server'
import { getDb, getUsuarioDesdeRequest } from '@/lib/firebaseAdmin'
import { FieldValue } from 'firebase-admin/firestore'
import { sumarMetricaDiaria } from '@/lib/metricasDiarias'
import { sumarEstadisticaUsuario } from '@/lib/estadisticasUsuario'
import { validarHorario } from '@/data/turnos'
import { esPremiumVigente, calcularNuevaVigencia, PRECIO_PREMIUM_BS } from '@/lib/planPremium'
import { sanearHistorialLaboral, sanearIdiomas } from '@/lib/cvEstandar'
import { sanearCiudad, sanearViajaA, ciudadDe } from '@/data/ciudades'
import { cargarCiudadesServidor } from '@/lib/ciudadesServer'
import { validarWhatsappPorPais, numeroConCodigoPais } from '@/lib/validarWhatsapp'
import { buscarPais } from '@/data/paises'
import { sanearRedes } from '@/lib/redesSociales'
import { sanearReservas, sanearLinkVideollamada } from '@/lib/reservas'
import { esClaveAdmin } from '@/lib/adminAuth'

export const dynamic = 'force-dynamic'

// GET: perfil público de un profesional, con sus reseñas incluidas.
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const db = getDb()
    const ref = db.collection('profesionales').doc(params.id)
    const doc = await ref.get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'No encontrado.' }, { status: 404 })
    }
    const resenasSnap = await ref.collection('resenas').get()
    const resenas = resenasSnap.docs
      .map((d) => ({ id: d.id, ...d.data() }))
      .sort((a: any, b: any) => (b.createdAt || '').localeCompare(a.createdAt || ''))

    // Sumamos +1 a las vistas del perfil — no esperamos a que termine
    // (fire-and-forget) para no hacer más lenta la respuesta al
    // visitante. Si falla, no rompe nada; es solo una métrica.
    // La página del CV (/servicios/[id]/cv) manda ?sinVista=1: la usan
    // sobre todo el propio profesional y el admin para revisarlo y
    // descargarlo, y no queremos inflar las vistas del perfil con eso.
    if (!req.nextUrl.searchParams.get('sinVista')) {
      ref.update({ vistas: FieldValue.increment(1) }).catch(() => {})
      sumarMetricaDiaria('vistasProfesionales').catch(() => {})
      sumarEstadisticaUsuario(doc.get('solicitanteUid'), 's', params.id, 'vistas').catch(() => {})
    }

    const datos: Record<string, any> = { ...doc.data() }
    // CV oculto (cvPublico === false, lo elige el profesional en
    // /mi-perfil o el admin): al público no le mandamos el historial
    // laboral ni los idiomas — así desaparece el botón "Ver CV completo"
    // del perfil y /servicios/[id]/cv muestra "no disponible". El dueño
    // y el admin lo siguen viendo para poder revisarlo y descargarlo.
    if (datos.cvPublico === false) {
      const password = req.headers.get('x-admin-password')
      let puedeVerCV = (await esClaveAdmin(password))
      if (!puedeVerCV) {
        const usuario = await getUsuarioDesdeRequest(req)
        puedeVerCV = !!usuario && datos.solicitanteUid === usuario.uid
      }
      if (!puedeVerCV) {
        delete datos.historialLaboral
        delete datos.idiomas
        datos.cvOculto = true
      }
    }

    // El link de videollamada solo para el dueño y el admin (al cliente se
    // lo damos al reservar el turno).
    if (datos.linkVideollamada) {
      const password = req.headers.get('x-admin-password')
      let esDueño = (await esClaveAdmin(password))
      if (!esDueño) {
        const usuario = await getUsuarioDesdeRequest(req)
        esDueño = !!usuario && datos.solicitanteUid === usuario.uid
      }
      if (!esDueño) delete datos.linkVideollamada
    }

    return NextResponse.json({ id: doc.id, ...datos, resenas })
  } catch (err) {
    console.error('GET /api/profesionales/[id]', err)
    return NextResponse.json({ error: 'No se pudo cargar el perfil.' }, { status: 500 })
  }
}

// PATCH: dos niveles de permiso.
//  - Admin (con ADMIN_PASSWORD) → puede editar cualquier campo, incluido
//    estado, plan y demás datos "de gestión" de la plataforma.
//  - El propio profesional (con su login de Firebase, dueño de este
//    documento vía solicitanteUid) → puede editar solo los campos de su
//    "presentación": nombre, especialidad, descripción, experiencia,
//    servicios, estudios y su CV (historial laboral, idiomas y si el CV
//    se muestra o no en el perfil público).
//    Es lo que usa /mi-perfil al guardar la propuesta armada desde su
//    CV (ver /api/profesionales/extraer-cv) — el resto de los campos
//    (rubro, contacto, ubicación, plan, estado) siguen siendo territorio
//    del admin para no abrir la puerta a que alguien se recategorice o
//    se autoapruebe.
const CAMPOS_EDITABLES_DUEÑO = ['nombre', 'especialidad', 'descripcion', 'experiencia', 'servicios', 'dondeTrabaja', 'educacion', 'historialLaboral', 'idiomas', 'cvPublico', 'ciudad', 'zona', 'atiendePresencial', 'atiendeOnline', 'viajaA', 'instagram', 'redes', 'reservas', 'linkVideollamada'] as const

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const password = req.headers.get('x-admin-password')
  const esAdmin = (await esClaveAdmin(password))

  const db = getDb()
  const ref = db.collection('profesionales').doc(params.id)

  let esDueño = false
  if (!esAdmin) {
    const usuario = await getUsuarioDesdeRequest(req)
    if (usuario) {
      const doc = await ref.get()
      esDueño = doc.exists && doc.data()?.solicitanteUid === usuario.uid
    }
    if (!esDueño) {
      return NextResponse.json({ error: 'No autorizado para editar este perfil.' }, { status: 401 })
    }
  }

  try {
    const body = await req.json()

    // El dueño (no-admin) solo puede tocar su subset de campos — lo
    // filtramos acá mismo para que ni por error se cuele un cambio de
    // estado/plan/rubro/contacto desde un pedido armado a mano.
    const bodyPermitido = esAdmin
      ? body
      : Object.fromEntries(Object.entries(body).filter(([k]) => (CAMPOS_EDITABLES_DUEÑO as readonly string[]).includes(k)))

    const { estado, nombre, rubro, especialidad, descripcion, dondeTrabaja, educacion, zona, direccion, lat, lng, whatsapp, instagram, email, notaAdmin, icono, plan, planVigenciaHasta, planEstadoPago, fotosAdicionales, imagenUrl, precio, experiencia, horarioTurnos, servicios, historialLaboral, idiomas, cvPublico, ciudad, atiendePresencial, atiendeOnline, viajaA, redes, reservas, linkVideollamada } = bodyPermitido
    const cambios: Record<string, unknown> = {}
    // Invitación por WhatsApp desde /admin: queda registrado cuándo (y
    // cuántas veces) se le escribió, para no invitar dos veces sin querer.
    if (esAdmin && bodyPermitido.registrarInvitacion) {
      cambios.invitadoEn = new Date().toISOString()
      cambios.invitaciones = FieldValue.increment(1)
    }

    if (estado !== undefined) {
      if (!['pendiente_revision', 'info_solicitada', 'aprobado', 'rechazado'].includes(estado)) {
        return NextResponse.json({ error: 'Estado inválido.' }, { status: 400 })
      }
      cambios.estado = estado
    }
    if (nombre !== undefined) cambios.nombre = nombre
    if (rubro !== undefined) cambios.rubro = rubro
    if (especialidad !== undefined) cambios.especialidad = especialidad
    if (descripcion !== undefined) cambios.descripcion = descripcion
    if (dondeTrabaja !== undefined) cambios.dondeTrabaja = String(dondeTrabaja || '').trim().slice(0, 500)
    if (educacion !== undefined) cambios.educacion = String(educacion || '').trim().slice(0, 300)
    if (zona !== undefined) cambios.zona = zona
    if (direccion !== undefined) cambios.direccion = direccion
    if (lat !== undefined) cambios.lat = lat === '' || lat === null ? null : Number(lat)
    if (lng !== undefined) cambios.lng = lng === '' || lng === null ? null : Number(lng)
    if (whatsapp !== undefined) {
      // Con el país (Admin → Servicios), se valida y se guarda con su código (591 / 549).
      const paisWa = bodyPermitido.whatsappPais
      if (esAdmin && paisWa) {
        const v = validarWhatsappPorPais(whatsapp, paisWa)
        if (!v.valido) return NextResponse.json({ error: v.motivo }, { status: 400 })
        cambios.whatsapp = numeroConCodigoPais(whatsapp, buscarPais(paisWa).codigo)
        cambios.whatsappPais = buscarPais(paisWa).id
      } else {
        cambios.whatsapp = whatsapp
      }
    }
    if (instagram !== undefined) cambios.instagram = instagram
    if (redes !== undefined) cambios.redes = sanearRedes(redes)
    if (reservas !== undefined) cambios.reservas = sanearReservas(reservas)
    if (linkVideollamada !== undefined) cambios.linkVideollamada = sanearLinkVideollamada(linkVideollamada)
    if (email !== undefined) cambios.email = email
    // Nota interna del admin sobre qué le pidió al profesional y está
    // esperando (ej. "le pedí una foto mejor, quedé de escribirle el viernes").
    // No se le manda automáticamente a nadie — es solo para que quede
    // registrado en vez de perderse en la cabeza del admin.
    if (notaAdmin !== undefined) cambios.notaAdmin = notaAdmin
    if (icono !== undefined) cambios.icono = icono
    if (plan !== undefined) cambios.plan = plan === 'premium' ? 'premium' : 'basico'
    if (planVigenciaHasta !== undefined) cambios.planVigenciaHasta = planVigenciaHasta
    if (planEstadoPago !== undefined) cambios.planEstadoPago = planEstadoPago
    if (fotosAdicionales !== undefined) cambios.fotosAdicionales = fotosAdicionales
    if (imagenUrl !== undefined) cambios.imagenUrl = imagenUrl
    if (precio !== undefined) cambios.precio = precio ? Number(precio) : null
    if (experiencia !== undefined) cambios.experiencia = experiencia
    // Lista de servicios concretos (ej: "Diseña arquitecturas de datos").
    // La sanamos igual del lado del dueño que del admin — nunca
    // confiamos en que el body ya venga limpio.
    if (servicios !== undefined) {
      cambios.servicios = Array.isArray(servicios)
        ? servicios
            .filter((s: unknown) => typeof s === 'string' && s.trim().length > 0)
            .map((s: string) => s.trim().slice(0, 80))
            .slice(0, 6)
        : []
    }
    // CV estandarizado (ver src/lib/cvEstandar.ts) — mismo saneo para
    // el dueño y para el admin.
    if (historialLaboral !== undefined) cambios.historialLaboral = sanearHistorialLaboral(historialLaboral)
    if (idiomas !== undefined) cambios.idiomas = sanearIdiomas(idiomas)
    if (cvPublico !== undefined) cambios.cvPublico = cvPublico !== false
    // Ciudad y forma de atención (lo edita el dueño desde Mi perfil o el admin).
    await cargarCiudadesServidor() // ciudades agregadas desde el admin
    if (ciudad !== undefined) cambios.ciudad = sanearCiudad(ciudad)
    if (atiendePresencial !== undefined) cambios.atiendePresencial = atiendePresencial !== false
    if (atiendeOnline !== undefined) cambios.atiendeOnline = atiendeOnline === true
    if (viajaA !== undefined || ciudad !== undefined) {
      const propia = (cambios.ciudad as any) || ciudadDe((await db.collection('profesionales').doc(params.id).get()).data() as any)
      const lista = viajaA !== undefined ? viajaA : ((await db.collection('profesionales').doc(params.id).get()).data() as any)?.viajaA
      cambios.viajaA = sanearViajaA(lista, propia)
    }
    // El admin puede cargar/corregir la agenda de turnos de un
    // profesional (mismo campo que el self-service de
    // /api/profesionales/[id]/horarios, pero sin exigirle Premium —
    // es una herramienta de soporte, por si hay que arreglarle algo
    // a mano mientras habla con él).
    if (horarioTurnos !== undefined) {
      const horario = { bloques: horarioTurnos.bloques || [] }
      if (!validarHorario(horario)) {
        return NextResponse.json({ error: 'Horario inválido.' }, { status: 400 })
      }
      cambios.horarioTurnos = horario
    }

    // Si el admin activa Premium desde el formulario general de edición
    // (no desde "Confirmar pago recibido"), y no mandó una vigencia
    // explícita, la activamos ya mismo — si no, quedaría guardado
    // plan:'premium' pero sin efecto (esPremiumVigente exige AMBAS
    // cosas: plan Y una vigencia futura), y el profesional no vería
    // nada nuevo pese a que el admin cree que ya lo activó.
    if (cambios.plan === 'premium' && planVigenciaHasta === undefined) {
      const actual = (await ref.get()).data() || {}
      if (!esPremiumVigente(actual)) {
        cambios.planVigenciaHasta = calcularNuevaVigencia(actual.planVigenciaHasta)
      }
    }

    if (Object.keys(cambios).length === 0) {
      return NextResponse.json({ error: 'No mandaste ningún campo para actualizar.' }, { status: 400 })
    }
    await ref.update(cambios)

    // Registro contable: solo cuando esto vino del flujo real de
    // "Confirmar pago recibido" (planEstadoPago:'ninguno' + una
    // vigencia calculada explícita) — no cuando el admin activa
    // Premium a mano desde el formulario general de edición (arriba),
    // porque ahí no hubo necesariamente un pago real de por medio.
    if (cambios.plan === 'premium' && planEstadoPago === 'ninguno' && planVigenciaHasta !== undefined) {
      const profDoc = await ref.get()
      await db.collection('pagos_premium').add({
        profesionalId: params.id,
        profesionalNombre: profDoc.data()?.nombre || null,
        monto: PRECIO_PREMIUM_BS,
        vigenciaHasta: planVigenciaHasta,
        fecha: new Date().toISOString(),
      })
    }

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('PATCH /api/profesionales/[id]', err)
    return NextResponse.json({ error: 'No se pudo actualizar.' }, { status: 500 })
  }
}

// DELETE: solo admin.
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const password = req.headers.get('x-admin-password')
  if (!(await esClaveAdmin(password))) {
    return NextResponse.json({ error: 'Contraseña de administrador inválida.' }, { status: 401 })
  }
  try {
    const db = getDb()
    await db.collection('profesionales').doc(params.id).delete()
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('DELETE /api/profesionales/[id]', err)
    return NextResponse.json({ error: 'No se pudo borrar.' }, { status: 500 })
  }
}
