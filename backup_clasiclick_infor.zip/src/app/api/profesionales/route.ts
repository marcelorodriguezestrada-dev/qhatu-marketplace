import { NextRequest, NextResponse } from 'next/server'
import { sanearCiudad, sanearViajaA } from '@/data/ciudades'
import { cargarCiudadesServidor } from '@/lib/ciudadesServer'
import { getDb } from '@/lib/firebaseAdmin'
import { validarWhatsappPorPais, numeroConCodigoPais } from '@/lib/validarWhatsapp'
import { buscarPais, PAIS_FALLBACK_ID } from '@/data/paises'
import { calcularNuevaVigencia } from '@/lib/planPremium'
import { sanearHistorialLaboral, sanearIdiomas } from '@/lib/cvEstandar'
import { sanearRedes } from '@/lib/redesSociales'
import { sanearReservas, sanearLinkVideollamada } from '@/lib/reservas'
import { esClaveAdmin } from '@/lib/adminAuth'
import { cabeceraCDN, enCache } from '@/lib/cacheLecturas'

export const dynamic = 'force-dynamic'

// GET: público sin filtrar solo los aprobados (para /servicios). Si se
// manda la contraseña de admin, devuelve TODOS sin filtrar — así el
// panel /admin puede ver también las solicitudes pendientes y
// rechazadas, no solo lo que ya está publicado.
export async function GET(req: NextRequest) {
  try {
    const db = getDb()
    const password = req.headers.get('x-admin-password')
    const esAdmin = (await esClaveAdmin(password))
    // Para el público: 1 minuto en memoria y en el CDN (ver /api/productos).
    const fresco = esAdmin || req.nextUrl.searchParams.has('fresco')
    const leer = async () => (await db.collection('profesionales').get()).docs.map((doc) => ({ id: doc.id, ...doc.data() }))
    let profesionales = [...(fresco ? await leer() : await enCache('profesionales', 60_000, leer))] as any[]

    if (!esAdmin) {
      profesionales = profesionales.filter((p) => !p.estado || p.estado === 'aprobado')
      // El link de videollamada se le da solo a quien reserva un turno.
      profesionales = profesionales.map(({ linkVideollamada, ...p }) => p)
    }

    return NextResponse.json({ profesionales }, { headers: fresco || password ? { 'Cache-Control': 'no-store' } : cabeceraCDN(60) })
  } catch (err) {
    console.error('GET /api/profesionales', err)
    return NextResponse.json({ profesionales: [] })
  }
}

// POST: alta directa de un profesional desde /admin — queda aprobado
// de inmediato, porque quien lo carga sos vos mismo. Para que un
// profesional se autopostule y quede pendiente de tu revisión, existe
// el endpoint separado /api/profesionales/solicitud.
export async function POST(req: NextRequest) {
  const password = req.headers.get('x-admin-password')
  if (!(await esClaveAdmin(password))) {
    return NextResponse.json({ error: 'Contraseña de administrador inválida.' }, { status: 401 })
  }
  try {
    const body = await req.json()
    const { nombre, rubro, especialidad, descripcion, dondeTrabaja, educacion, zona, direccion, lat, lng, whatsapp, whatsappPais, instagram, email, icono, plan, imagenUrl, precio, experiencia, servicios, historialLaboral, idiomas, cvPublico, ciudad, atiendePresencial, atiendeOnline, viajaA, redes, reservas, linkVideollamada } = body
    await cargarCiudadesServidor() // ciudades agregadas desde el admin
    const ciudadFinal = sanearCiudad(ciudad)
    if (!nombre || !rubro || !whatsapp) {
      return NextResponse.json({ error: 'Faltan datos obligatorios (nombre, rubro, whatsapp).' }, { status: 400 })
    }

    const paisId = whatsappPais || PAIS_FALLBACK_ID
    const validacionWhatsapp = validarWhatsappPorPais(whatsapp, paisId)
    if (!validacionWhatsapp.valido) {
      return NextResponse.json({ error: validacionWhatsapp.motivo }, { status: 400 })
    }
    const whatsappCompleto = numeroConCodigoPais(whatsapp, buscarPais(paisId).codigo)

    // Lista de servicios concretos (ej: "Instalación de grifería") —
    // misma sanitización que en /api/profesionales/solicitud y en el
    // PATCH de [id], para que da igual por dónde entre el dato.
    const serviciosLimpios = Array.isArray(servicios)
      ? servicios
          .filter((s: unknown) => typeof s === 'string' && s.trim().length > 0)
          .map((s: string) => s.trim().slice(0, 80))
          .slice(0, 6)
      : []

    const db = getDb()
    const ref = await db.collection('profesionales').add({
      nombre,
      rubro,
      // Texto corto y libre para matizar el rubro fijo (ej: rubro
      // "Médico" + especialidad "Médico general - Ecografista"). Si
      // queda vacío, en el perfil se muestra directo el label del rubro.
      especialidad: especialidad || '',
      descripcion: descripcion || '',
      dondeTrabaja: (dondeTrabaja || '').trim().slice(0, 500),
      educacion: (educacion || '').trim().slice(0, 300),
      servicios: serviciosLimpios,
      historialLaboral: sanearHistorialLaboral(historialLaboral),
      idiomas: sanearIdiomas(idiomas),
      // Si el CV descargable se muestra en el perfil público (por defecto sí).
      cvPublico: cvPublico !== false,
      zona: zona || '',
      ciudad: ciudadFinal,
      atiendePresencial: atiendePresencial !== false,
      atiendeOnline: atiendeOnline === true,
      viajaA: sanearViajaA(viajaA, ciudadFinal),
      // Dirección puntual (calle/número), distinta de "zona" (el
      // barrio). Las dos son opcionales y se muestran juntas en el
      // perfil cuando están cargadas.
      direccion: direccion || '',
      lat: lat != null ? Number(lat) : null,
      lng: lng != null ? Number(lng) : null,
      whatsapp: whatsappCompleto,
      whatsappPais: paisId,
      instagram: instagram || '',
      redes: sanearRedes(redes),
      ...(reservas ? { reservas: sanearReservas(reservas) } : {}),
      linkVideollamada: sanearLinkVideollamada(linkVideollamada),
      email: (email || '').trim(),
      icono: icono || rubro || 'otro',
      imagenUrl: imagenUrl || '',
      precio: precio ? Number(precio) : null, // null = "Precio a convenir"
      experiencia: experiencia || '',
      plan: plan === 'premium' ? 'premium' : 'basico',
      planEstadoPago: 'ninguno',
      planVigenciaHasta: plan === 'premium' ? calcularNuevaVigencia(null) : null,
      fotosAdicionales: [],
      estado: 'aprobado',
      ratingPromedio: 0,
      cantidadResenas: 0,
      vistas: 0,
      clicsWhatsapp: 0,
      createdAt: new Date().toISOString(),
    })
    return NextResponse.json({ id: ref.id })
  } catch (err) {
    console.error('POST /api/profesionales', err)
    return NextResponse.json({ error: 'No se pudo crear el profesional.' }, { status: 500 })
  }
}
