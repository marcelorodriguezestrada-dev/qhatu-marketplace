import { NextRequest, NextResponse } from 'next/server'
import { ciudadDe, sanearCiudad, sanearEnvioPropio, sanearVisibleEn } from '@/data/ciudades'
import { cargarCiudadesServidor } from '@/lib/ciudadesServer'
import { getDb } from '@/lib/firebaseAdmin'
import { esPremiumVigente, calcularNuevaVigencia, PRECIO_PREMIUM_BS } from '@/lib/planPremium'
import { esClaveAdmin } from '@/lib/adminAuth'

export const dynamic = 'force-dynamic'

// GET público — devuelve el perfil de tienda completo de un vendedor:
// datos de cobro (para el checkout) y datos de la tienda (para la
// pestaña "Info. Tienda" de cada producto: dirección, mapa, horarios,
// tipos de venta).
//
// Dos campos parecidos pero que significan cosas distintas:
//  - `configurado`: el vendedor YA cargó datos de cobro propios (QR o
//    CBU). Lo usa el checkout para saber si le paga a él directo o cae
//    al QR general de la plataforma.
//  - `aceptaPagoQr`: además de tenerlos cargados, el vendedor tildó
//    explícitamente "Pago con QR" en su tipo de ventas. Tener la foto
//    del QR subida no alcanza — si no lo tildó, no quiere cobrar por
//    ahí, y no hay que ofrecerle esa opción al comprador.
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const db = getDb()
    const doc = await db.collection('vendedores').doc(params.id).get()
    if (!doc.exists) {
      return NextResponse.json({ configurado: false, aceptaPagoQr: false, existe: false })
    }
    const data = doc.data() as any
    const tieneDatosCobro = !!(data.qrImageUrl || data.cbu)
    return NextResponse.json({
      existe: true,
      configurado: tieneDatosCobro,
      aceptaPagoQr: tieneDatosCobro && !!data.tiposVenta?.pagoQr,
      qrImageUrl: data.qrImageUrl || '',
      cbu: data.cbu || '',
      nombreNegocio: data.nombreNegocio || '',
      whatsapp: data.whatsapp || '',
      whatsappPais: data.whatsappPais || '',
      direccion: data.direccion || '',
      lat: data.lat ?? null,
      lng: data.lng ?? null,
      horarios: data.horarios || '',
      tiposVenta: data.tiposVenta || {},
      logoUrl: data.logoUrl || '',
      ciudad: ciudadDe(data),
      envioPropio: sanearEnvioPropio(data.envioPropio, !!data.tiposVenta?.haceEnvios),
      verificado: !!data.verificado,
      visibleEn: Array.isArray(data.visibleEn) ? data.visibleEn : [],
      plan: data.plan === 'premium' ? 'premium' : 'basico',
      planVigenciaHasta: data.planVigenciaHasta || null,
      planEstadoPago: data.planEstadoPago || 'ninguno',
      premiumVigente: esPremiumVigente(data),
    })
  } catch (err) {
    console.error('GET /api/vendedores/[id]', err)
    return NextResponse.json({ configurado: false, aceptaPagoQr: false, existe: false })
  }
}

// PATCH: solo admin — marca (o desmarca) a un vendedor como
// "verificado". A diferencia de otras plataformas donde esto es
// automático, acá es una decisión manual tuya, para que el badge
// signifique algo real.
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const password = req.headers.get('x-admin-password')
  if (!(await esClaveAdmin(password))) {
    return NextResponse.json({ error: 'Contraseña de administrador inválida.' }, { status: 401 })
  }
  try {
    const body = await req.json()
    const { verificado, plan, planVigenciaHasta, planEstadoPago } = body
    const cambios: Record<string, unknown> = {}
    if (verificado !== undefined) cambios.verificado = !!verificado
    if (plan !== undefined) cambios.plan = plan === 'premium' ? 'premium' : 'basico'
    if (planVigenciaHasta !== undefined) cambios.planVigenciaHasta = planVigenciaHasta
    if (planEstadoPago !== undefined) cambios.planEstadoPago = planEstadoPago

    // Mismo criterio que con profesionales: si se activa Premium sin
    // una vigencia explícita (por ejemplo, tildándolo a mano en vez de
    // pasar por "Confirmar pago"), igual lo activamos ya mismo — para
    // que no quede guardado "premium" pero sin efecto real.
    const ref = getDb().collection('vendedores').doc(params.id)
    if (cambios.plan === 'premium' && planVigenciaHasta === undefined) {
      const actual = (await ref.get()).data() || {}
      if (!esPremiumVigente(actual)) {
        cambios.planVigenciaHasta = calcularNuevaVigencia(actual.planVigenciaHasta)
      }
    }

    // Ciudad de la tienda (Admin → Usuarios): se copia a todos sus productos,
    // y con ella el país, la moneda (Bs / $) y dónde aparecen.
    if (body.ciudad !== undefined) {
      await cargarCiudadesServidor().catch(() => null)
      const ciudad = sanearCiudad(body.ciudad)
      const actual = (await ref.get()).data() || {}
      cambios.ciudad = ciudad
      const visibleEn = (Array.isArray(actual.visibleEn) ? actual.visibleEn : []).filter((c: string) => c !== ciudad)
      cambios.visibleEn = visibleEn
      const productos = await getDb().collection('productos').where('vendedorId', '==', params.id).get()
      for (let i = 0; i < productos.docs.length; i += 400) {
        const batch = getDb().batch()
        for (const d of productos.docs.slice(i, i + 400)) batch.update(d.ref, { ciudad, visibleEn })
        await batch.commit()
      }
    }

    // "🌎 También visible en" (Admin → Usuarios): la tienda y todos sus
    // productos aparecen además en esas ciudades (para pruebas).
    if (body.visibleEn !== undefined) {
      await cargarCiudadesServidor().catch(() => null)
      const actual = (await ref.get()).data() || {}
      const visibleEn = sanearVisibleEn(body.visibleEn, ciudadDe(actual))
      cambios.visibleEn = visibleEn
      const productos = await getDb().collection('productos').where('vendedorId', '==', params.id).get()
      for (let i = 0; i < productos.docs.length; i += 400) {
        const batch = getDb().batch()
        for (const d of productos.docs.slice(i, i + 400)) batch.update(d.ref, { visibleEn })
        await batch.commit()
      }
    }

    await ref.set(cambios, { merge: true })

    // Registro contable: solo cuando es un pago real confirmado
    // ("Confirmar pago recibido" manda planEstadoPago:'ninguno' +
    // una vigencia ya calculada) — no cuando se activa a mano sin pago.
    if (cambios.plan === 'premium' && planEstadoPago === 'ninguno' && planVigenciaHasta !== undefined) {
      const vendedorDoc = await ref.get()
      await getDb().collection('pagos_premium').add({
        tipo: 'vendedor',
        vendedorId: params.id,
        vendedorNombre: vendedorDoc.data()?.nombreNegocio || null,
        monto: PRECIO_PREMIUM_BS,
        vigenciaHasta: planVigenciaHasta,
        fecha: new Date().toISOString(),
      })
    }

    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('PATCH /api/vendedores/[id]', err)
    return NextResponse.json({ error: 'No se pudo actualizar.' }, { status: 500 })
  }
}
