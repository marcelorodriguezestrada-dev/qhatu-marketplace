'use client'

import { leerCampana } from '@/lib/campana'
import { buscarPaisMercado, formatoMoneda, paisDeCiudad } from '@/lib/mercado'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/lib/auth'
import MiCuenta from '@/components/MiCuenta'
import { CampoCiudad } from '@/components/SelectorCiudad'
import { useCiudad } from '@/lib/ciudad'
import type { CiudadId } from '@/data/ciudades'
import PreguntasVendedor from '@/components/PreguntasVendedor'
import MarketingVendedor from '@/components/vender/MarketingVendedor'
import EstadisticasUsuario from '@/components/EstadisticasUsuario'
import { useSeccionVendedor, claseSeccion, SidebarVendedor, MenuVendedorCelular, VolverCelular, type SeccionVendedor } from '@/components/vender/NavVendedor'
import { ProductIcon } from '@/components/ProductIcon'
import ModalIASuggestions from '@/components/ModalIASuggestions'
import { gruposDe, nombreRubro } from '@/lib/arbolCategorias'
import { useCategoriasProductos } from '@/lib/useCategoriasProductos'
import { PUBLICOS_PRODUCTO, PUBLICO_PRODUCTO_FALLBACK, labelPublicoProducto } from '@/data/publicoProducto'
import { validarWhatsappBoliviano } from '@/lib/validarWhatsapp'
import { PAISES, PAIS_FALLBACK_ID, buscarPais } from '@/data/paises'
import { PRECIO_PREMIUM_BS, MAX_FOTOS_ADICIONALES_PREMIUM } from '@/lib/planPremium'
import PublicarMasivo from '@/components/PublicarMasivo'
import { buscarMercados } from '@/data/mercadosPotosi'

const QR_PLATAFORMA = process.env.NEXT_PUBLIC_QR_IMAGE_URL || ''
const BANK_NAME = process.env.NEXT_PUBLIC_BANK_NAME || ''
const BANK_ACCOUNT_NAME = process.env.NEXT_PUBLIC_BANK_ACCOUNT_NAME || ''
const BANK_ACCOUNT_NUMBER = process.env.NEXT_PUBLIC_BANK_ACCOUNT_NUMBER || ''

const ICONOS = ['boot', 'sandal', 'shoe', 'sneaker', 'textile', 'sweater', 'hat', 'bag']

// Moneda del país de la tienda (Bs en Bolivia, $ en Argentina…); la
// fija el componente en cada render.
let PAIS_TIENDA = buscarPaisMercado('BO')
function bs(n: number) {
  return formatoMoneda(n, PAIS_TIENDA)
}

const ESTADOS_LABEL: Record<string, { texto: string; color: string }> = {
  pendiente_pago: { texto: 'Esperando pago', color: 'text-inksoft' },
  informado_pago: { texto: 'Pago avisado', color: 'text-ochre' },
  pagado: { texto: 'Pagado', color: 'text-teal' },
  en_preparacion: { texto: 'En preparación', color: 'text-indigo-600' },
  en_entrega: { texto: 'En entrega', color: 'text-amber-600' },
  entregado: { texto: 'Entregado', color: 'text-emerald-600' },
  cancelado: { texto: 'Cancelado', color: 'text-red-600' },
}

export default function VenderPage() {
  const { usuario, cargando, emailVerificado, obtenerToken } = useAuth()
  const router = useRouter()
  const [misProductos, setMisProductos] = useState<any[]>([])
  const [misPedidos, setMisPedidos] = useState<any[]>([])
  const { categorias: categoriasProductos, buscarRubroProducto } = useCategoriasProductos()
  const [nombre, setNombre] = useState('')
  const [categoriaProductoSel, setCategoriaProductoSel] = useState('')
  const [rubro, setRubro] = useState('')
  const [publico, setPublico] = useState<string>(PUBLICO_PRODUCTO_FALLBACK)
  const [precio, setPrecio] = useState('')
  const [precioOriginal, setPrecioOriginal] = useState('')
  const [plan, setPlan] = useState<'basico' | 'premium'>('basico')
  const [icono, setIcono] = useState(ICONOS[0])
  const [descripcionCorta, setDescripcionCorta] = useState('')
  const [descripcionLarga, setDescripcionLarga] = useState('')
  const [tallesTexto, setTallesTexto] = useState('')
  const [coloresTexto, setColoresTexto] = useState('')
  const [materiales, setMateriales] = useState('')
  const [compraMinima, setCompraMinima] = useState('1')
  // Stock en unidades; vacío = sin control de stock (ver src/lib/stock.ts).
  const [stock, setStock] = useState('')
  const [imagenUrl, setImagenUrl] = useState('')
  const [imagenViewerUrl, setImagenViewerUrl] = useState('')
  const [thumbUrl, setThumbUrl] = useState('')
  const [localPreviewUrl, setLocalPreviewUrl] = useState<string | null>(null)
  const [subiendoImagen, setSubiendoImagen] = useState(false)
  // Detección de categoría por la foto (IA con visión). Si el vendedor
  // ya eligió la categoría a mano, no se la pisamos.
  const [categoriaTocada, setCategoriaTocada] = useState(false)
  const [detectandoCategoria, setDetectandoCategoria] = useState(false)
  const [categoriaDetectada, setCategoriaDetectada] = useState('')
  const [publicando, setPublicando] = useState(false)
  const [error, setError] = useState('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [removerFondo, setRemoverFondo] = useState(false)
  const [lastFile, setLastFile] = useState<File | null>(null)
  const [previewProcessedUrl, setPreviewProcessedUrl] = useState<string | null>(null)
  const [processingPreview, setProcessingPreview] = useState(false)
  const [generandoIA, setGenerandoIA] = useState(false)
  const [showModalIA, setShowModalIA] = useState(false)
  const [sugerenciasIA, setSugerenciasIA] = useState<any[]>([])
  const [fetchingSugerencias, setFetchingSugerencias] = useState(false)

  // En cuanto llega el árbol de categorías de producto, arrancamos con
  // la primera categoría y su primer rubro seleccionados (el select no
  // puede quedar vacío).
  useEffect(() => {
    if (categoriasProductos.length === 0 || categoriaProductoSel) return
    setCategoriaProductoSel(categoriasProductos[0].id)
    setRubro(categoriasProductos[0].rubros[0]?.id || '')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categoriasProductos])

  const rubrosDeCategoriaSel = categoriasProductos.find((c) => c.id === categoriaProductoSel)?.rubros || []

  // Perfil de cobro (QR/CBU propio) — con esto, quien te compre paga
  // directo a tu cuenta, no a una cuenta centralizada de la plataforma.
  const [cobroQrUrl, setCobroQrUrl] = useState('')
  const [cobroCbu, setCobroCbu] = useState('')
  const [cobroNegocio, setCobroNegocio] = useState('')
  const { ciudadId: ciudadComprador } = useCiudad()
  const [tiendaCiudad, setTiendaCiudad] = useState<CiudadId | null>(null)
  PAIS_TIENDA = paisDeCiudad(tiendaCiudad || ciudadComprador)
  const [cobroWhatsapp, setCobroWhatsapp] = useState('')
  const [cobroWhatsappPais, setCobroWhatsappPais] = useState(PAIS_FALLBACK_ID)
  const [subiendoQrCobro, setSubiendoQrCobro] = useState(false)
  const [guardandoCobro, setGuardandoCobro] = useState(false)
  const [cobroGuardado, setCobroGuardado] = useState(false)

  // Datos de la tienda — se muestran en la pestaña "Info. Tienda" de
  // cada producto (dirección con mapa, horarios, tipos de venta, logo).
  const [tiendaDireccion, setTiendaDireccion] = useState('')
  const [tiendaLat, setTiendaLat] = useState<number | null>(null)
  const [tiendaLng, setTiendaLng] = useState<number | null>(null)
  const [buscandoUbicacionTienda, setBuscandoUbicacionTienda] = useState(false)
  const [mercadosSugeridos, setMercadosSugeridos] = useState<ReturnType<typeof buscarMercados>>([])
  const [tiendaHorarios, setTiendaHorarios] = useState('')
  const [tiendaLogoUrl, setTiendaLogoUrl] = useState('')
  const [subiendoLogo, setSubiendoLogo] = useState(false)
  const [tiposVenta, setTiposVenta] = useState<Record<string, boolean>>({})
  // Envío propio ("Hace envíos"): costo (vacío = a coordinar), alcance y detalle.
  const [envioCosto, setEnvioCosto] = useState('')
  const [envioAlcance, setEnvioAlcance] = useState<'ciudad' | 'bolivia'>('ciudad')
  const [envioDetalle, setEnvioDetalle] = useState('')

  // Membresía Premium de la tienda (paga, la confirma el admin) — a
  // diferencia de todo lo de arriba, esto no lo puede tocar el vendedor
  // directo, solo "avisar que ya pagó".
  const [planVendedor, setPlanVendedor] = useState('basico')
  const [planVigenciaVendedor, setPlanVigenciaVendedor] = useState<string | null>(null)
  const [planEstadoPagoVendedor, setPlanEstadoPagoVendedor] = useState('ninguno')
  const [premiumVendedorVigente, setPremiumVendedorVigente] = useState(false)
  const [avisandoPago, setAvisandoPago] = useState(false)
  const [pagandoPremium, setPagandoPremium] = useState(false)

  // Galería de fotos extra por producto (Premium) — qué producto tiene
  // abierto su editor de galería ahora mismo.
  // Fotos extra del producto que se está publicando/editando (beneficio
  // Premium). Se suben a ImgBB al elegirlas y se guardan con el producto.
  const [fotosExtra, setFotosExtra] = useState<string[]>([])
  // Confirmación después de publicar/actualizar: "¡Listo! ya está
  // publicado" con botones para verlo, ir al catálogo o publicar otro.
  const [publicadoOk, setPublicadoOk] = useState<{ id: string; nombre: string; editado: boolean } | null>(null)
  const avisoPublicadoRef = useRef<HTMLDivElement | null>(null)
  const [mostrarMasivo, setMostrarMasivo] = useState(false)
  const { seccion, activa, irA, volver } = useSeccionVendedor()
  const [preguntasPendientes, setPreguntasPendientes] = useState(0)
  const [subiendoExtra, setSubiendoExtra] = useState(0)

  useEffect(() => {
    if (cargando) return
    if (!usuario || emailVerificado === false) router.push('/login')
  }, [cargando, usuario, emailVerificado, router])

  useEffect(() => {
    if (usuario) {
      cargarMisProductos()
      cargarMisPedidos()
      cargarMiCobro()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [usuario])

  async function cargarMiCobro() {
    if (!usuario) return
    const res = await fetch(`/api/vendedores/${usuario.uid}`)
    const data = await res.json()
    if (data.existe) {
      setCobroQrUrl(data.qrImageUrl || '')
      setCobroCbu(data.cbu || '')
      setCobroNegocio(data.nombreNegocio || '')
      setTiendaCiudad(data.ciudad || null)
      {
        const paisId = data.whatsappPais || PAIS_FALLBACK_ID
        const codigo = buscarPais(paisId).codigo
        const local = (data.whatsapp || '').startsWith(codigo) ? (data.whatsapp as string).slice(codigo.length) : (data.whatsapp || '')
        setCobroWhatsapp(local)
        setCobroWhatsappPais(paisId)
      }
      setTiendaDireccion(data.direccion || '')
      setTiendaLat(data.lat ?? null)
      setTiendaLng(data.lng ?? null)
      setTiendaHorarios(data.horarios || '')
      setTiendaLogoUrl(data.logoUrl || '')
      setTiposVenta(data.tiposVenta || {})
      setEnvioCosto(data.envioPropio?.costo != null ? String(data.envioPropio.costo) : '')
      setEnvioAlcance(data.envioPropio?.alcance === 'bolivia' ? 'bolivia' : 'ciudad')
      setEnvioDetalle(data.envioPropio?.detalle || '')
      setPlanVendedor(data.plan || 'basico')
      setPlanVigenciaVendedor(data.planVigenciaHasta || null)
      setPlanEstadoPagoVendedor(data.planEstadoPago || 'ninguno')
      setPremiumVendedorVigente(!!data.premiumVigente)
    }
  }

  async function avisarPagoPremium() {
    setAvisandoPago(true)
    try {
      const token = await obtenerToken()
      await fetch('/api/vendedores/informar-pago', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      setPlanEstadoPagoVendedor('informado_pago')
    } finally {
      setAvisandoPago(false)
    }
  }

  function usarMiUbicacionTienda() {
    setBuscandoUbicacionTienda(true)
    if (!navigator.geolocation) {
      setError('Tu navegador no soporta geolocalización.')
      setBuscandoUbicacionTienda(false)
      return
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setTiendaLat(pos.coords.latitude)
        setTiendaLng(pos.coords.longitude)
        setBuscandoUbicacionTienda(false)
      },
      () => {
        setError('No pudimos acceder a tu ubicación.')
        setBuscandoUbicacionTienda(false)
      }
    )
  }

  async function subirLogoTienda(file: File | null) {
    if (!file) return
    setSubiendoLogo(true)
    try {
      const token = await obtenerToken()
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setTiendaLogoUrl(data.url)
    } catch (e) {
      // @ts-ignore
      setError('Error subiendo el logo: ' + (e?.message || e))
    } finally {
      setSubiendoLogo(false)
    }
  }

  async function subirQrCobro(file: File | null) {
    if (!file) return
    setSubiendoQrCobro(true)
    try {
      const token = await obtenerToken()
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setCobroQrUrl(data.url)
    } catch (e) {
      // @ts-ignore
      setError('Error subiendo el QR: ' + (e?.message || e))
    } finally {
      setSubiendoQrCobro(false)
    }
  }

  async function guardarCobro() {
    if (cobroWhatsapp) {
      const validacion = validarWhatsappBoliviano(cobroWhatsapp)
      if (!validacion.valido) {
        setError(validacion.motivo || 'Revisá el número de WhatsApp.')
        return
      }
    }
    setGuardandoCobro(true)
    setCobroGuardado(false)
    try {
      const token = await obtenerToken()
      await fetch('/api/vendedores', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          qrImageUrl: cobroQrUrl, cbu: cobroCbu, nombreNegocio: cobroNegocio, whatsapp: cobroWhatsapp, whatsappPais: cobroWhatsappPais,
          direccion: tiendaDireccion, lat: tiendaLat, lng: tiendaLng,
          horarios: tiendaHorarios, logoUrl: tiendaLogoUrl, tiposVenta,
          envioPropio: { costo: envioCosto, alcance: envioAlcance, detalle: envioDetalle },
          ciudad: tiendaCiudad || ciudadComprador,
        }),
      })
      setCobroGuardado(true)
    } finally {
      setGuardandoCobro(false)
    }
  }

  async function cargarMisProductos() {
    // Solo los de su tienda (antes leía todo el catálogo en cada apertura del panel).
    const res = await fetch(`/api/productos?fresco=1&vendedor=${encodeURIComponent(usuario?.uid || '')}`)
    const data = await res.json()
    const propios = (data.productos || []).filter((p: any) => p.vendedorId === usuario?.uid)
    setMisProductos(propios)
  }

  // Sube varias fotos extra a la vez (hasta completar el máximo).
  async function subirFotosExtra(files: FileList | null) {
    if (!files || files.length === 0) return
    const libres = MAX_FOTOS_ADICIONALES_PREMIUM - fotosExtra.length
    const lista = Array.from(files).slice(0, Math.max(0, libres))
    if (files.length > lista.length) setError(`Podés tener hasta ${MAX_FOTOS_ADICIONALES_PREMIUM} fotos extra — se subieron las primeras ${lista.length}.`)
    if (lista.length === 0) return
    setSubiendoExtra(lista.length)
    try {
      const token = await obtenerToken()
      for (const file of lista) {
        try {
          const comprimido = (await compressImage(file, 1000, 0.75)) || file
          const formData = new FormData()
          formData.append('image', comprimido)
          const res = await fetch('/api/upload-image', { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: formData })
          const data = await res.json()
          if (data.error) throw new Error(data.error)
          setFotosExtra((prev) => (prev.length < MAX_FOTOS_ADICIONALES_PREMIUM ? [...prev, data.url] : prev))
        } catch (e: any) {
          setError(e?.message || 'No se pudo subir una de las fotos.')
        } finally {
          setSubiendoExtra((n) => Math.max(0, n - 1))
        }
      }
    } finally {
      setSubiendoExtra(0)
    }
  }

  function moverFotoExtra(i: number, delta: number) {
    setFotosExtra((prev) => {
      const j = i + delta
      if (j < 0 || j >= prev.length) return prev
      const copia = [...prev]
      ;[copia[i], copia[j]] = [copia[j], copia[i]]
      return copia
    })
  }

  async function cargarMisPedidos() {
    const token = await obtenerToken()
    if (!token) return
    const res = await fetch('/api/pedidos', {
      headers: { Authorization: `Bearer ${token}` },
    })
    const data = await res.json()
    setMisPedidos(data.pedidos || [])
  }

  // Mismo patrón que el resto de la app: subimos el archivo a nuestro
  // propio endpoint /api/upload-image, que a su vez lo reenvía a ImgBB
  // (hosting de imágenes gratuito) y nos devuelve la URL pública.
  async function subirImagen(file: File | null) {
    if (!file) return
    // Comprimir imagen en cliente antes de cualquier procesamiento para
    // acelerar subida y segmentación. Guardamos la versión comprimida
    // en `lastFile` para previsualizar/procesar rápidamente.
    let workingFile = file
    try {
      const isMobile = typeof window !== 'undefined' && /Mobi|Android/i.test(navigator.userAgent)
      const maxDim = isMobile ? 600 : 800
      const quality = isMobile ? 0.6 : 0.7
      const compressed = await compressImage(file, maxDim, quality)
      if (compressed) workingFile = compressed
    } catch (err) {
      console.warn('Compression failed, uploading original', err)
    }
    setLastFile(workingFile)
    // Generar preview pequeño inmediato para mejorar percepción en móviles
    try {
      const isMobile = typeof window !== 'undefined' && /Mobi|Android/i.test(navigator.userAgent)
      const previewDim = isMobile ? 300 : 400
      const previewQuality = isMobile ? 0.6 : 0.7
      const small = await compressImage(file, previewDim, previewQuality)
      if (small) {
        const obj = URL.createObjectURL(small)
        // mostrar preview local hasta que la subida termine
        setLocalPreviewUrl(obj)
        // revoke previo (si existía) al reemplazar después
      }
    } catch (err) {
      console.warn('preview generation failed', err)
    }

    setSubiendoImagen(true)
    setError('')
    try {
      // Procesamiento cliente gratuito: intenta remover fondo en el navegador
      // Sólo si el usuario tiene activada la opción
      let processedFile: File = workingFile
      if (removerFondo) {
        try {
          const processedDataUrl = await removeBgClient(workingFile)
          // Convertir dataURL a File
          const blob = await (await fetch(processedDataUrl)).blob()
          processedFile = new File([blob], workingFile.name, { type: blob.type })
        } catch (err) {
          // Si falla la remoción en cliente, seguimos con el archivo comprimido/original
          console.warn('remove-bg client failed', err)
        }
      }

      // Subimos la versión media en background (la que se mostrará como imagen final)
      const token = await obtenerToken()
      const formData = new FormData()
      // Subimos la versión media
      formData.append('image', processedFile)
      // Generar y subir también la miniatura (small) para usar en listados/CDN
      try {
        const smallFile = await compressImage(workingFile, 300, 0.6)
        if (smallFile) formData.append('thumb', smallFile)
      } catch (err) {
        console.warn('Could not generate thumb', err)
      }

      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      // reemplazar preview local por URL remota
      if (localPreviewUrl) {
        try { URL.revokeObjectURL(localPreviewUrl) } catch (e) {}
        setLocalPreviewUrl(null)
      }
      // data.url = media, data.thumbUrl = thumbnail (si está disponible),
      // data.urlViewer = página de ImgBB con vista previa (para WhatsApp)
      setImagenUrl(data.url)
      setImagenViewerUrl(data.urlViewer || '')
      setThumbUrl(data.thumbUrl || '')
      detectarCategoria(data.url)
    } catch (e) {
      // @ts-ignore
      setError('Error subiendo la imagen: ' + (e?.message || e))
    } finally {
      setSubiendoImagen(false)
    }
  }

  async function detectarCategoria(url: string) {
    if (editingId || categoriaTocada || !url) return
    setDetectandoCategoria(true)
    setCategoriaDetectada('')
    try {
      const token = await obtenerToken()
      const d = await fetch('/api/productos/detectar-categoria', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ imagenUrl: url }),
      }).then((r) => r.json())
      if (!d.rubroId) return
      setCategoriaProductoSel(d.categoriaId)
      setRubro(d.rubroId)
      const info = buscarRubroProducto(d.rubroId)
      setCategoriaDetectada(info ? `${info.categoriaLabel} › ${info.label}` : d.rubroId)
      if (d.nombre) setNombre((n) => n || d.nombre)
    } catch {
      // Opcional: si falla, el vendedor elige a mano.
    } finally {
      setDetectandoCategoria(false)
    }
  }

  async function previewRemoveBg() {
    if (!lastFile) {
      setError('No hay archivo local para procesar. Volvé a seleccionar la imagen.')
      return
    }
    setProcessingPreview(true)
    setError('')
    try {
      const dataUrl = await removeBgClient(lastFile)
      setPreviewProcessedUrl(dataUrl)
    } catch (err) {
      console.error('Preview remove bg failed', err)
      // @ts-ignore
      setError('No se pudo generar la previsualización: ' + (err?.message || err))
    } finally {
      setProcessingPreview(false)
    }
  }

  async function applyPreviewAsImage() {
    if (!previewProcessedUrl) return
    setSubiendoImagen(true)
    setError('')
    try {
      const blob = await (await fetch(previewProcessedUrl)).blob()
      const file = new File([blob], lastFile?.name || 'processed.png', { type: blob.type })
      const token = await obtenerToken()
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setImagenUrl(data.url)
      setImagenViewerUrl(data.urlViewer || '')
      setThumbUrl(data.thumbUrl || '')
      // reemplazamos lastFile con el nuevo file
      setLastFile(file)
      setPreviewProcessedUrl(null)
    } catch (err) {
      // @ts-ignore
      setError('Error subiendo la imagen procesada: ' + (err?.message || err))
    } finally {
      setSubiendoImagen(false)
    }
  }

  // removeBgClient: quita el fondo con la IA (Gemini, en el servidor) y
  // deja el producto sobre blanco. Devuelve la foto como data URL.
  async function removeBgClient(file: File): Promise<string> {
    const token = await obtenerToken()
    const formData = new FormData()
    formData.append('image', file)
    const res = await fetch('/api/productos/quitar-fondo', { method: 'POST', headers: { Authorization: `Bearer ${token}` }, body: formData })
    const data = await res.json().catch(() => ({}))
    if (!res.ok || !data.dataUrl) throw new Error(data.error || 'No se pudo quitar el fondo.')
    return data.dataUrl
  }

  // compressImage: redimensiona la imagen manteniendo proporción y reduce calidad
  async function compressImage(file: File, maxDim = 800, quality = 0.7): Promise<File | null> {
    try {
      const img = document.createElement('img')
      img.src = URL.createObjectURL(file)
      await new Promise((r, rej) => { img.onload = r; img.onerror = rej })
      const w = img.naturalWidth
      const h = img.naturalHeight
      let nw = w
      let nh = h
      if (Math.max(w, h) > maxDim) {
        if (w >= h) {
          nw = maxDim
          nh = Math.round((maxDim * h) / w)
        } else {
          nh = maxDim
          nw = Math.round((maxDim * w) / h)
        }
      }
      const canvas = document.createElement('canvas')
      canvas.width = nw
      canvas.height = nh
      const ctx = canvas.getContext('2d')!
      ctx.drawImage(img, 0, 0, nw, nh)
      // Preferir WebP para mejor compresión en navegadores que lo soporten
      const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/webp', quality))
      // Si WebP no está disponible, caer a jpeg
      const finalBlob = blob || (await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality)))
      URL.revokeObjectURL(img.src)
      if (!finalBlob) return null
      const ext = finalBlob.type === 'image/webp' ? '.webp' : '.jpg'
      return new File([finalBlob], file.name.replace(/\.[^.]+$/, ext), { type: finalBlob.type })
    } catch (err) {
      console.warn('compressImage error', err)
      return null
    }
  }

  async function publicar(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!nombre.trim() || !precio) {
      setError('Completá el nombre y el precio.')
      return
    }
    if (precioOriginal && Number(precioOriginal) <= Number(precio)) {
      setError('El precio anterior tiene que ser mayor al precio actual, o dejalo vacío.')
      return
    }
    setPublicando(true)
    setPublicadoOk(null)
    const nombrePublicado = nombre.trim()
    let idPublicado = editingId || ''
    const fueEdicion = !!editingId
    try {
      const token = await obtenerToken()
      if (editingId) {
        const res = await fetch(`/api/productos/${editingId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            nombre,
            rubro,
            publico,
            precio: Number(precio),
            icono,
            imagenUrl,
            imagenViewerUrl,
              thumbUrl,
            precioOriginal: precioOriginal ? Number(precioOriginal) : null,
            descripcionCorta,
            descripcionLarga,
            talles: tallesTexto.split(',').map((t) => t.trim()).filter(Boolean),
            colores: coloresTexto.split(',').map((c) => c.trim()).filter(Boolean),
            materiales,
            compraMinima: Number(compraMinima) || 1,
            stock: stock.trim() === '' ? null : Number(stock),
            fotosAdicionales: premiumVendedorVigente ? fotosExtra : undefined,
          }),
        })
        const data = await res.json()
        if (data.error) {
          setError(data.error)
          return
        }
        setEditingId(null)
      } else {
        const res = await fetch('/api/productos', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
          body: JSON.stringify({
            ciudad: tiendaCiudad || ciudadComprador,
            campana: leerCampana(),
            nombre,
            rubro,
            publico,
            precio: Number(precio),
            icono,
            imagenUrl,
            imagenViewerUrl,
              thumbUrl,
            precioOriginal: precioOriginal ? Number(precioOriginal) : null,
            plan,
            descripcionCorta,
            descripcionLarga,
            talles: tallesTexto.split(',').map((t) => t.trim()).filter(Boolean),
            colores: coloresTexto.split(',').map((c) => c.trim()).filter(Boolean),
            materiales,
            compraMinima: Number(compraMinima) || 1,
            stock: stock.trim() === '' ? null : Number(stock),
            fotosAdicionales: premiumVendedorVigente ? fotosExtra : undefined,
          }),
        })
        const data = await res.json()
        if (data.error) {
          setError(data.error)
          return
        }
        idPublicado = data.id
      }
      setPublicadoOk({ id: idPublicado, nombre: nombrePublicado, editado: fueEdicion })
      setCategoriaTocada(false)
      setCategoriaDetectada('')
      setTimeout(() => avisoPublicadoRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 50)
      setNombre('')
      setPrecio('')
      setPrecioOriginal('')
      setImagenUrl('')
      setImagenViewerUrl('')
      setIcono(ICONOS[0])
      setPlan('basico')
      setDescripcionCorta('')
      setDescripcionLarga('')
      setTallesTexto('')
      setColoresTexto('')
      setMateriales('')
      setCompraMinima('1')
      setStock('')
      setFotosExtra([])
      await cargarMisProductos()
    } finally {
      setPublicando(false)
    }
  }

  async function borrar(id: string) {
    const token = await obtenerToken()
    await fetch(`/api/productos/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${token}` },
    })
    cargarMisProductos()
  }

  // El vendedor confirma el pago que recibió directo en su propio QR/CBU,
  // y después va avanzando el estado de preparación/entrega — todo sin
  // necesitar la contraseña de admin, porque es su propia venta.
  async function avanzarEstadoPedido(id: string, estado: string) {
    const token = await obtenerToken()
    await fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ estado }),
    })
    cargarMisPedidos()
  }

  if (cargando || !usuario) {
    return <div className="px-5 py-16 text-center font-body text-sm text-inksoft">Cargando...</div>
  }

  const preguntasBadge = preguntasPendientes || undefined
  const ventasPendientes = misPedidos.filter((p) => ['pendiente_pago', 'informado_pago', 'pagado', 'en_preparacion', 'en_entrega'].includes(p.estado)).length
  const sinStock = misProductos.filter((p) => typeof p.stock === 'number' && p.stock <= 0).length
  const badges = { preguntas: preguntasBadge, ventas: ventasPendientes || undefined, publicaciones: sinStock ? `${sinStock} sin stock` : undefined, tienda: !cobroQrUrl || !cobroWhatsapp ? '!' : undefined }
  const tareas = [
    preguntasPendientes > 0 && { s: 'preguntas' as SeccionVendedor, t: `💬 ${preguntasPendientes} pregunta${preguntasPendientes === 1 ? '' : 's'} sin responder`, d: 'Responder rápido ayuda a vender.' },
    ventasPendientes > 0 && { s: 'ventas' as SeccionVendedor, t: `🧾 ${ventasPendientes} venta${ventasPendientes === 1 ? '' : 's'} en curso`, d: 'Confirmá pagos y avanzá las entregas.' },
    sinStock > 0 && { s: 'publicaciones' as SeccionVendedor, t: `📦 ${sinStock} producto${sinStock === 1 ? '' : 's'} sin stock`, d: 'Cargá unidades para volver a vender.' },
    !cobroQrUrl && { s: 'tienda' as SeccionVendedor, t: '🏪 Te falta subir tu QR de cobro', d: 'Sin QR, el comprador no sabe cómo pagarte.' },
    !cobroWhatsapp && { s: 'tienda' as SeccionVendedor, t: '📱 Cargá el WhatsApp de tu tienda', d: 'Así los compradores te pueden consultar.' },
    misProductos.length === 0 && { s: 'publicar' as SeccionVendedor, t: '➕ Publicá tu primer producto', d: 'Con foto, precio y talles.' },
  ].filter(Boolean) as { s: SeccionVendedor; t: string; d: string }[]

  return (
    <div className="max-w-6xl mx-auto px-5 py-6">
      <div className="hidden md:flex items-center justify-between gap-4 mb-5 pb-4 border-b border-line">
        <div>
          <div className="font-display text-xl font-bold text-ink">Central de vendedores</div>
          <div className="font-body text-[13px] text-inksoft">{cobroNegocio || 'Mi tienda'} · {usuario.email}</div>
        </div>
        <div className="flex items-center gap-4 font-body text-sm">
          <Link href={`/tienda/${usuario.uid}`} className="text-teal underline">Ver mi tienda</Link>
          <Link href="/" className="text-inksoft underline">Ir a comprar</Link>
          <button type="button" onClick={() => irA('publicar')} className="px-4 py-2 rounded-lg border-none bg-maroon text-white font-semibold">➕ Publicar</button>
        </div>
      </div>

      <MenuVendedorCelular visible={!seccion} irA={irA} badges={badges} tienda={cobroNegocio} email={usuario.email || ''} />

      <div className="md:flex md:gap-6 md:items-start">
        <SidebarVendedor activa={activa} irA={irA} badges={badges} />
        <main className="flex-1 min-w-0 max-w-[760px]">
          <VolverCelular seccion={seccion} volver={volver} />

          <section className={claseSeccion('resumen', seccion)}>
            <div className="font-display text-lg font-bold text-ink mb-3">Hola 👋 {cobroNegocio ? `así va ${cobroNegocio}` : 'así va tu tienda'}</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
              {[
                { s: 'publicaciones' as SeccionVendedor, n: misProductos.length, l: 'Publicaciones' },
                { s: 'ventas' as SeccionVendedor, n: ventasPendientes, l: 'Ventas en curso' },
                { s: 'preguntas' as SeccionVendedor, n: preguntasPendientes, l: 'Preguntas sin responder' },
                { s: 'publicaciones' as SeccionVendedor, n: sinStock, l: 'Sin stock' },
              ].map((c) => (
                <button key={c.l} type="button" onClick={() => irA(c.s)} className="bg-panel border border-line rounded-xl p-3.5 text-left hover:border-maroon">
                  <div className={`font-display text-2xl font-bold ${c.n > 0 && c.l !== 'Publicaciones' ? 'text-maroon' : 'text-ink'}`}>{c.n}</div>
                  <div className="font-body text-[11px] text-inksoft">{c.l}</div>
                </button>
              ))}
            </div>
            <div className="bg-panel border border-line rounded-xl p-4 mb-5">
              <div className="font-body text-sm font-semibold text-ink mb-2">Para hacer</div>
              {tareas.length === 0 ? (
                <div className="font-body text-sm text-teal">✓ Todo al día. ¡Buen trabajo!</div>
              ) : (
                <div className="grid gap-2">
                  {tareas.map((t) => (
                    <button key={t.t} type="button" onClick={() => irA(t.s)} className="flex items-center gap-3 text-left px-3 py-2.5 rounded-lg bg-panelalt hover:bg-ochre/10">
                      <span className="flex-1 min-w-0">
                        <span className="block font-body text-sm text-ink font-medium">{t.t}</span>
                        <span className="block font-body text-[11px] text-inksoft">{t.d}</span>
                      </span>
                      <span className="text-inksoft">›</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => irA('publicar')} className="px-4 py-2.5 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold">➕ Publicar producto</button>
              <button type="button" onClick={() => { setMostrarMasivo(true); irA('publicar') }} className="px-4 py-2.5 rounded-lg border border-teal bg-tealsoft text-teal font-body text-sm font-semibold">📊 Publicar con Excel</button>
              <button type="button" onClick={() => irA('estadisticas')} className="px-4 py-2.5 rounded-lg border border-line bg-panel text-ink font-body text-sm">📊 Ver estadísticas</button>
              <button type="button" onClick={() => irA('marketing')} className="px-4 py-2.5 rounded-lg border border-indigo-200 bg-indigo-50 text-indigo-700 font-body text-sm font-semibold">📣 Crear publicación para redes</button>
              <Link href={`/tienda/${usuario.uid}`} className="px-4 py-2.5 rounded-lg border border-line bg-panel text-ink font-body text-sm">🛍️ Ver mi tienda</Link>
            </div>
          </section>

          <section className={claseSeccion('publicar', seccion)}>
      {editingId && (
        <div className="mb-4 p-3 rounded-lg bg-ochre/10 border border-ochre text-ink font-body text-sm">
          Estás editando el producto <strong>{editingId}</strong>. Hacé los cambios y presioná "Actualizar producto" o "Cancelar".
        </div>
      )}


      {publicadoOk && (
        <div ref={avisoPublicadoRef} className="bg-tealsoft border-2 border-teal rounded-xl p-5 mb-4">
          <div className="font-display text-lg font-bold text-ink mb-1">
            ✅ ¡Listo! {publicadoOk.editado ? 'Guardaste los cambios de' : 'Ya está publicado'} “{publicadoOk.nombre}”
          </div>
          <div className="font-body text-sm text-inksoft mb-3">
            {publicadoOk.editado ? 'Los cambios ya se ven en el catálogo.' : 'Ya aparece en el catálogo y los compradores lo pueden ver y comprar.'}
          </div>
          <div className="flex flex-wrap gap-2">
            {publicadoOk.id && (
              <Link href={`/producto/${publicadoOk.id}`} className="px-4 py-2 rounded-lg bg-teal text-white font-body text-sm font-semibold">
                👀 Ver cómo quedó
              </Link>
            )}
            <Link href={usuario ? `/tienda/${usuario.uid}` : '/'} className="px-4 py-2 rounded-lg border border-teal bg-panel text-teal font-body text-sm font-semibold">
              🛍️ Ver mi catálogo
            </Link>
            <button
              type="button"
              onClick={() => { setPublicadoOk(null); document.getElementById('form-producto')?.scrollIntoView({ behavior: 'smooth' }) }}
              className="px-4 py-2 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold"
            >
              ➕ Publicar otro
            </button>
          </div>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-2 bg-panel border border-line rounded-xl px-4 py-3 mb-4">
        <div className="font-body text-sm text-ink">
          <span className="font-semibold">¿Tenés muchos productos?</span>{' '}
          <span className="text-inksoft">Publicalos todos juntos con una planilla Excel.</span>
        </div>
        <button type="button" onClick={() => setMostrarMasivo((v) => !v)} className="px-3.5 py-2 rounded-lg border border-teal bg-tealsoft text-teal font-body text-sm font-semibold">
          📊 {mostrarMasivo ? 'Cerrar' : 'Publicar con Excel'}
        </button>
      </div>
      {mostrarMasivo && <PublicarMasivo misProductos={misProductos} alTerminar={() => cargarMisProductos()} />}

      <form id="form-producto" onSubmit={publicar} className="bg-panel border border-line rounded-xl p-5 mb-8">
        <div className="font-body text-sm font-semibold text-ink mb-3">Nuevo producto</div>
        <input
          value={nombre}
          onChange={(e) => setNombre(e.target.value)}
          placeholder="Nombre del producto"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
        />
        <input
          value={descripcionCorta}
          onChange={(e) => setDescripcionCorta(e.target.value)}
          placeholder="Descripción corta (ej: Botines de cuero, talle 38)"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
        />
        <div className="flex gap-2 mb-3">
          <button
            type="button"
            onClick={async () => {
              setError('')
              setFetchingSugerencias(true)
              try {
                const res = await fetch('/api/generate-description', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ nombre, categoria: nombreRubro(buscarRubroProducto(rubro)) || rubro, precio, imagenUrl, descripcionLarga, variantes: 3 }),
                })
                const j = await res.json()
                if (j.error) throw new Error(j.error)
                const list = j.suggestions || (j.title ? [{ title: j.title, short: j.short, long: j.long }] : [])
                if (list.length === 0) throw new Error('No hay sugerencias')
                setSugerenciasIA(list)
                setShowModalIA(true)
              } catch (err) {
                // @ts-ignore
                setError('Error generando con IA: ' + (err?.message || err))
              } finally {
                setFetchingSugerencias(false)
              }
            }}
            className="px-3 py-2 rounded-md border font-body text-sm"
            disabled={fetchingSugerencias}
          >
            {fetchingSugerencias ? 'Generando...' : 'Generar con IA (ver 3 sugerencias)'}
          </button>
          <div className="font-body text-[12px] text-inksoft self-center">Usa IA para proponer título, descripción corta y detallada.</div>
        </div>

        <ModalIASuggestions
          open={showModalIA}
          onClose={() => setShowModalIA(false)}
          suggestions={sugerenciasIA}
          onApply={(s) => {
            if (s.title) setNombre(s.title)
            if (s.short) setDescripcionCorta(s.short)
            if (s.long) setDescripcionLarga(s.long)
            setShowModalIA(false)
          }}
        />
        <div className="mb-3">
          <select
            value={publico}
            onChange={(e) => setPublico(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
          >
            {PUBLICOS_PRODUCTO.map((p) => (
              <option key={p.id} value={p.id}>{p.label}</option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <select
            value={categoriaProductoSel}
            onChange={(e) => {
              const catId = e.target.value
              setCategoriaProductoSel(catId)
              setCategoriaTocada(true)
              setCategoriaDetectada('')
              const cat = categoriasProductos.find((c) => c.id === catId)
              setRubro(cat?.rubros[0]?.id || '')
            }}
            className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
          >
            {categoriasProductos.map((c) => (
              <option key={c.id} value={c.id}>{c.label}</option>
            ))}
          </select>
          <select
            value={rubro}
            onChange={(e) => { setRubro(e.target.value); setCategoriaTocada(true); setCategoriaDetectada('') }}
            className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
          >
            {/* Rubros sueltos de la categoría y, debajo, cada subcategoría con los suyos. */}
            {rubrosDeCategoriaSel.filter((r) => !r.grupoId).map((r) => (
              <option key={r.id} value={r.id}>{r.label}</option>
            ))}
            {gruposDe({ id: '', label: '', rubros: rubrosDeCategoriaSel }).map((g) => (
              <optgroup key={g.id} label={g.label}>
                {g.rubros.map((r) => (
                  <option key={r.id} value={r.id}>{r.label}{r.label === 'Otros' ? ` (${g.label})` : ''}</option>
                ))}
              </optgroup>
            ))}
          </select>
        </div>
        {(detectandoCategoria || categoriaDetectada) && (
          <div className="font-body text-[12px] -mt-1.5 mb-3 text-teal">
            {detectandoCategoria ? '🔎 Mirando la foto para elegir la categoría...' : `✨ Categoría detectada por la foto: ${categoriaDetectada}. Si no es, cambiala arriba.`}
          </div>
        )}
        <div className="mb-3">
          <input
            type="number"
            value={precio}
            onChange={(e) => setPrecio(e.target.value)}
            placeholder={`Precio en ${PAIS_TIENDA.simboloMoneda}`}
            className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
          />
        </div>
        <div className="font-body text-[11px] text-inksoft -mt-2 mb-3">
          ¿No está el rubro que buscás? Agregalo desde /admin → pestaña &quot;Categorías de productos&quot; y va a aparecer acá.
        </div>
        <div className="mb-3">
          <input
            type="number"
            value={precioOriginal}
            onChange={(e) => setPrecioOriginal(e.target.value)}
            placeholder="Precio anterior (opcional, para mostrar descuento)"
            className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
          />
          <div className="font-body text-[11px] text-inksoft mt-1.5">
            Dejalo vacío si no tenés descuento. Si lo completás, tiene que ser mayor al precio actual.
          </div>
        </div>
        <div className="mb-3">
          <div className="font-body text-xs text-inksoft mb-1.5">Descripción detallada</div>
          <textarea
            value={descripcionLarga}
            onChange={(e) => setDescripcionLarga(e.target.value)}
            placeholder="Detalles: material, estado, envío, medidas, etc."
            className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm min-h-[100px]"
          />
        </div>

        <div className="grid grid-cols-2 gap-3 mb-3">
          <div>
            <div className="font-body text-xs text-inksoft mb-1.5">Talles (opcional)</div>
            <input
              value={tallesTexto}
              onChange={(e) => setTallesTexto(e.target.value)}
              placeholder="36, 37, 38, 39"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
            />
          </div>
          <div>
            <div className="font-body text-xs text-inksoft mb-1.5">Colores (opcional)</div>
            <input
              value={coloresTexto}
              onChange={(e) => setColoresTexto(e.target.value)}
              placeholder="Marrón, Negro"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
            />
          </div>
        </div>
        <div className="font-body text-[11px] text-inksoft mb-3 -mt-2">Separá cada uno con comas.</div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <div className="font-body text-xs text-inksoft mb-1.5">Materiales (opcional)</div>
            <input
              value={materiales}
              onChange={(e) => setMateriales(e.target.value)}
              placeholder="Cuero"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
            />
          </div>
          <div>
            <div className="font-body text-xs text-inksoft mb-1.5">Compra mínima</div>
            <input
              type="number"
              min={1}
              value={compraMinima}
              onChange={(e) => setCompraMinima(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
            />
          </div>
          <div>
            <div className="font-body text-xs text-inksoft mb-1.5">Stock (unidades)</div>
            <input
              type="number"
              min={0}
              value={stock}
              onChange={(e) => setStock(e.target.value)}
              placeholder="Sin control"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
            />
            <div className="font-body text-[10px] text-inksoft mt-1">Se descuenta solo con cada venta. Vacío = no se controla.</div>
          </div>
        </div>
        <div className="mb-4">
          <div className="font-body text-xs text-inksoft mb-1.5">Plan del vendedor</div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setPlan('basico')}
              className={`px-3 py-2 rounded-lg border font-body text-sm ${plan === 'basico' ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line text-inksoft'}`}
            >
              Básico
            </button>
            <button
              type="button"
              onClick={() => setPlan('premium')}
              className={`px-3 py-2 rounded-lg border font-body text-sm ${plan === 'premium' ? 'border-ochre bg-ochresoft text-ochre' : 'border-line text-inksoft'}`}
            >
              Premium
            </button>
          </div>
          <div className="font-body text-[11px] text-inksoft mt-1.5">
            {plan === 'premium'
              ? 'Tu producto aparece destacado y arriba del catálogo.'
              : 'Tu producto se publica como estándar.'}
          </div>
        </div>

        <div className="mb-4">
          <div className="font-body text-xs text-inksoft mb-1.5">Foto del producto</div>
          <div className="flex items-center gap-3 flex-wrap">
            {(localPreviewUrl || imagenUrl) && (
              <img
                src={localPreviewUrl || imagenUrl}
                alt="Vista previa"
                loading="lazy"
                decoding="async"
                className="w-14 h-14 object-cover rounded-lg border border-line"
                onError={(e) => { (e.currentTarget as HTMLImageElement).style.display = 'none' }}
              />
            )}
            <div>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => subirImagen(e.target.files?.[0] || null)}
                disabled={subiendoImagen}
                className="font-body text-xs"
              />
              {subiendoImagen && <div className="font-body text-xs text-maroon mt-1">Subiendo imagen...</div>}
              {detectandoCategoria && <div className="font-body text-xs text-teal mt-1">🔎 Detectando la categoría por la foto...</div>}
              {!detectandoCategoria && categoriaDetectada && <div className="font-body text-xs text-teal mt-1">✨ Categoría elegida: {categoriaDetectada} (podés cambiarla arriba)</div>}
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={previewRemoveBg}
                disabled={!lastFile || processingPreview}
                className="px-3 py-1 rounded-md border font-body text-xs"
              >
                {processingPreview ? '🪄 Quitando el fondo…' : '🪄 Quitar fondo con IA (ver antes)'}
              </button>
            </div>
          </div>
          <div className="flex items-center gap-3 mt-2">
            <label className="font-body text-[13px] flex items-center gap-2">
              <input type="checkbox" checked={removerFondo} onChange={(e) => setRemoverFondo(e.target.checked)} />
              <span className="font-body text-[11px] text-inksoft">Quitar el fondo con IA al subir (fondo blanco)</span>
            </label>
          </div>
          <div className="font-body text-[11px] text-inksoft mt-1.5">
            Opcional — si no subís foto, se usa el ícono que elijas abajo. Si la remoción falla, se sube la imagen original.
          </div>
        </div>

        {/* Fotos extra — beneficio Premium de la tienda */}
        <div className="mb-4">
          <div className="flex items-center gap-2 mb-1.5">
            <div className="font-body text-xs text-inksoft">Más fotos del producto</div>
            <span className="font-body text-[9px] font-bold text-white bg-ochre px-1.5 py-0.5 rounded-full">PREMIUM</span>
          </div>
          {premiumVendedorVigente ? (
            <>
              <div className="flex gap-2 flex-wrap mb-2">
                {fotosExtra.map((url, i) => (
                  <div key={url} className="relative w-20 h-20">
                    <img src={url} alt={`Foto extra ${i + 1}`} className="w-20 h-20 object-cover rounded-lg border border-line" />
                    <button
                      type="button"
                      onClick={() => setFotosExtra((prev) => prev.filter((f) => f !== url))}
                      aria-label="Quitar foto"
                      className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-black/70 text-white text-[10px] border-none"
                    >
                      ✕
                    </button>
                    <div className="absolute bottom-0.5 inset-x-0.5 flex justify-between">
                      <button type="button" onClick={() => moverFotoExtra(i, -1)} disabled={i === 0} aria-label="Mover a la izquierda" className="w-5 h-5 rounded bg-white/85 text-[10px] disabled:opacity-0">◀</button>
                      <button type="button" onClick={() => moverFotoExtra(i, 1)} disabled={i === fotosExtra.length - 1} aria-label="Mover a la derecha" className="w-5 h-5 rounded bg-white/85 text-[10px] disabled:opacity-0">▶</button>
                    </div>
                  </div>
                ))}
                {Array.from({ length: subiendoExtra }).map((_, i) => (
                  <div key={`subiendo-${i}`} className="w-20 h-20 rounded-lg border border-dashed border-line bg-panelalt flex items-center justify-center font-body text-[10px] text-inksoft">
                    Subiendo...
                  </div>
                ))}
                {fotosExtra.length + subiendoExtra < MAX_FOTOS_ADICIONALES_PREMIUM && (
                  <label className="w-20 h-20 rounded-lg border-2 border-dashed border-teal bg-tealsoft flex flex-col items-center justify-center font-body text-[10px] text-teal font-semibold cursor-pointer text-center">
                    <span className="text-xl leading-none">＋</span>
                    Agregar fotos
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={(e) => { subirFotosExtra(e.target.files); e.target.value = '' }}
                    />
                  </label>
                )}
              </div>
              <div className="font-body text-[11px] text-inksoft">
                Hasta {MAX_FOTOS_ADICIONALES_PREMIUM} fotos además de la principal. Podés elegir varias a la vez y ordenarlas con ◀ ▶. Se guardan al {editingId ? 'actualizar' : 'publicar'} el producto.
              </div>
            </>
          ) : (
            <div className="font-body text-[11px] text-inksoft bg-panelalt border border-line rounded-lg px-3 py-2">
              Con la membresía Premium de tu tienda podés sumar hasta {MAX_FOTOS_ADICIONALES_PREMIUM} fotos más por producto (distintos ángulos, detalles, puesto). Mirá más abajo cómo activarla.
            </div>
          )}
        </div>

        {previewProcessedUrl && (
          <div className="mt-3 p-3 border rounded-lg bg-white/50">
            <div className="font-body text-sm font-semibold mb-2">Previsualización sin fondo</div>
            <div className="flex items-center gap-3">
              <img src={previewProcessedUrl} alt="Preview sin fondo" loading="lazy" decoding="async" className="w-20 h-20 object-contain rounded-md border" />
              <div className="flex flex-col gap-2">
                <button onClick={applyPreviewAsImage} className="px-3 py-1 rounded-md bg-maroon text-white text-sm">Usar esta imagen</button>
                <button onClick={() => setPreviewProcessedUrl(null)} className="px-3 py-1 rounded-md border text-sm">Cerrar</button>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-2 mb-4 flex-wrap">
          {ICONOS.map((i) => (
            <button
              key={i}
              type="button"
              onClick={() => setIcono(i)}
              className={`w-11 h-11 rounded-lg border flex items-center justify-center ${
                icono === i ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line text-inksoft'
              }`}
            >
              <ProductIcon kind={i} size={20} />
            </button>
          ))}
        </div>
        {error && <div className="font-body text-xs text-maroon mb-3">{error}</div>}
        <div className="flex gap-2">
          <button
            type="submit"
            disabled={publicando || subiendoImagen}
            className="flex-1 py-2.5 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold disabled:opacity-60"
          >
            {publicando ? (editingId ? 'Actualizando...' : 'Publicando...') : (editingId ? 'Actualizar producto' : 'Publicar producto')}
          </button>
          {editingId && (
            <button
              type="button"
              onClick={() => {
                setEditingId(null)
                setCategoriaTocada(false)
                setCategoriaDetectada('')
                setFotosExtra([])
                setNombre('')
                setCategoriaProductoSel(categoriasProductos[0]?.id || '')
                setRubro(categoriasProductos[0]?.rubros[0]?.id || '')
                setPublico(PUBLICO_PRODUCTO_FALLBACK)
                setPrecio('')
                setPrecioOriginal('')
                setIcono(ICONOS[0])
                setImagenUrl('')
                setImagenViewerUrl('')
                setPlan('basico')
              }}
              className="px-4 py-2.5 rounded-lg border border-line font-body text-sm"
            >
              Cancelar
            </button>
          )}
        </div>
      </form>
          </section>
          <section className={claseSeccion('publicaciones', seccion)}>
      <div className="font-body text-sm font-semibold text-ink mb-3">Mis productos ({misProductos.length})</div>
      {misProductos.length === 0 && (
        <div className="font-body text-sm text-inksoft">Todavía no publicaste ningún producto.</div>
      )}
      {misProductos.map((p) => (
        <div key={p.id} className="bg-panel border border-line rounded-lg p-3.5 mb-2.5 flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-panelalt flex items-center justify-center text-maroon shrink-0 overflow-hidden">
            {(p.thumbUrl || p.imagenUrl) ? (
              <img src={p.thumbUrl || p.imagenUrl} alt={p.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
            ) : (
              <ProductIcon kind={p.icono} size={20} />
            )}
          </div>
          <div className="flex-1">
            <div className="font-body text-sm font-medium text-ink">{p.nombre}</div>
            <div className="font-body text-xs text-inksoft">
              {labelPublicoProducto(p.publico)} · {nombreRubro(buscarRubroProducto(p.rubro)) || p.categoria || 'Sin rubro'} · {p.precioOriginal ? (
                <>
                  <span className="line-through">{bs(p.precioOriginal)}</span> {bs(p.precio)}
                </>
              ) : (
                bs(p.precio)
              )}
            </div>
            {typeof p.stock === 'number' && (
              <div className={`font-body text-[11px] font-semibold mt-0.5 ${p.stock <= 0 ? 'text-maroon' : p.stock <= 3 ? 'text-ochre' : 'text-teal'}`}>
                {p.stock <= 0 ? 'Agotado — cargá más stock para volver a venderlo' : `Stock: ${p.stock} unidad${p.stock === 1 ? '' : 'es'}`}
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                // Prefill form for editing
                setEditingId(p.id)
                setNombre(p.nombre || '')
                {
                  const info = buscarRubroProducto(p.rubro)
                  setCategoriaProductoSel(info?.categoriaId || categoriasProductos[0]?.id || '')
                  setRubro(p.rubro || categoriasProductos[0]?.rubros[0]?.id || '')
                  setPublico(p.publico || PUBLICO_PRODUCTO_FALLBACK)
                }
                setPrecio(String(p.precio || ''))
                setPrecioOriginal(p.precioOriginal ? String(p.precioOriginal) : '')
                setIcono(p.icono || ICONOS[0])
                setImagenUrl(p.imagenUrl || '')
                setImagenViewerUrl(p.imagenViewerUrl || '')
                setDescripcionCorta(p.descripcionCorta || '')
                setDescripcionLarga(p.descripcionLarga || '')
                setTallesTexto((p.talles || []).join(', '))
                setColoresTexto((p.colores || []).join(', '))
                setMateriales(p.materiales || '')
                setCompraMinima(String(p.compraMinima || 1))
                setStock(typeof p.stock === 'number' ? String(p.stock) : '')
                setFotosExtra(Array.isArray(p.fotosAdicionales) ? p.fotosAdicionales : [])
                setPlan(p.plan || 'basico')
                irA('publicar')
                window.scrollTo({ top: 0, behavior: 'smooth' })
              }}
              className="font-body text-xs text-ink underline"
            >
              Editar
            </button>
            <button
              onClick={() => borrar(p.id)}
              className="font-body text-xs text-maroon underline shrink-0"
            >
              Borrar
            </button>
          </div>
        </div>
      ))}
          </section>
          <section className={claseSeccion('estadisticas', seccion)}>
            <div className="font-display text-lg font-bold text-ink mb-3">📊 Estadísticas de tus productos</div>
            {activa === 'estadisticas' && <EstadisticasUsuario solo="productos" />}
          </section>
          <section className={claseSeccion('preguntas', seccion)}>
      <PreguntasVendedor onPendientes={setPreguntasPendientes} />
          </section>
          <section className={claseSeccion('marketing', seccion)}>
            <MarketingVendedor misProductos={misProductos} tienda={cobroNegocio} irA={irA} ciudadTienda={tiendaCiudad || ciudadComprador} />
          </section>
          <section className={claseSeccion('ventas', seccion)}>
      <div className="bg-panel border border-line rounded-xl p-4 mb-8">
        <div className="font-body text-sm font-semibold text-ink mb-3">Mis pedidos ({misPedidos.length})</div>
        {misPedidos.length === 0 && (
          <div className="font-body text-sm text-inksoft">Todavía no tenés pedidos para tus productos.</div>
        )}
        {misPedidos.map((p) => {
          const estado = ESTADOS_LABEL[p.estado] || { texto: p.estado, color: 'text-inksoft' }
          const itemsVendidos = (p.items || []).filter((it: any) => it.vendedorId === usuario.uid || it.vendedor === usuario.email)
          const siguienteAccion: Record<string, { estado: string; texto: string }> = {
            pendiente_pago: { estado: 'pagado', texto: 'Confirmar pago recibido' },
            informado_pago: { estado: 'pagado', texto: 'Confirmar pago recibido' },
            pagado: { estado: 'en_preparacion', texto: 'Marcar en preparación' },
            en_preparacion: { estado: 'en_entrega', texto: 'Marcar en camino' },
            en_entrega: { estado: 'entregado', texto: 'Marcar entregado' },
          }
          const accion = siguienteAccion[p.estado]
          return (
            <div key={p.id} className="border border-line rounded-lg p-3 mb-2.5 bg-white/40">
              <div className="flex items-center justify-between gap-3 mb-1.5">
                <div className="font-body text-xs text-inksoft">Pedido #{p.id.slice(0, 6)}</div>
                <div className={`font-body text-[11px] font-semibold ${estado.color}`}>{estado.texto}</div>
              </div>
              <div className="font-body text-xs font-semibold text-ink">👤 {p.nombreComprador || 'Sin nombre cargado'}</div>
              <div className="font-body text-[11px] text-inksoft mb-2">{p.comprador || 'Sin email'}</div>
              {p.metodoEntrega === 'vendedor' && (
                <div className="font-body text-[11px] text-ink bg-tealsoft border border-teal rounded-md px-2 py-1.5 mb-2">
                  🚚 Lo enviás vos a: {p.direccion || 'sin dirección'}{p.referenciaAdicional ? ` (${p.referenciaAdicional})` : ''}{p.whatsappComprador ? ` · WhatsApp ${p.whatsappComprador}` : ''}
                </div>
              )}
              {p.metodoEntrega === 'retiro' && <div className="font-body text-[11px] text-inksoft mb-2">🏬 Retira en tu tienda</div>}

              <div className="flex flex-col gap-2 mb-2">
                {itemsVendidos.map((it: any, i: number) => (
                  <div key={i} className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-md bg-panelalt flex items-center justify-center overflow-hidden shrink-0">
                      {(it.thumbUrl || it.imagenUrl) ? (
                        <img src={it.thumbUrl || it.imagenUrl} alt={it.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-body text-[8px] text-inksoft">IMG</span>
                      )}
                    </div>
                    <div className="font-body text-xs text-ink flex-1 min-w-0 truncate">
                      {it.cantidad} × {it.nombre}
                      {(it.tallaElegida || it.colorElegida) && (
                        <span className="text-inksoft"> ({[it.tallaElegida, it.colorElegida].filter(Boolean).join(' · ')})</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <div className="font-body text-sm font-semibold text-ink mb-2">Total: {bs(p.total)}</div>
              {accion && (
                <button
                  onClick={() => avanzarEstadoPedido(p.id, accion.estado)}
                  className="px-3 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                >
                  {accion.texto}
                </button>
              )}
            </div>
          )
        })}
      </div>

          </section>
          <section className={claseSeccion('tienda', seccion)}>
      <div className="bg-panel border border-line rounded-xl p-5 mb-8">
        <div className="font-body text-sm font-semibold text-ink mb-1">Mi tienda</div>
        <p className="font-body text-[12px] text-inksoft mb-3">
          Esto se muestra en la pestaña "Info. Tienda" de cada producto tuyo, y define a qué cuenta te paga directo quien te compre.
        </p>
        <input
          value={cobroNegocio}
          onChange={(e) => setCobroNegocio(e.target.value)}
          placeholder="Nombre de tu negocio (opcional)"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
        />
        <CampoCiudad
          value={tiendaCiudad || ciudadComprador}
          onChange={setTiendaCiudad}
          etiqueta="📍 Ciudad de tu tienda (tus productos aparecen en esta ciudad)"
          className="mb-3"
        />

        <div className="flex gap-2 items-center mb-1">
          <select
            value={cobroWhatsappPais}
            onChange={(e) => setCobroWhatsappPais(e.target.value)}
            className="px-3 py-2.5 rounded-lg border border-line font-body text-sm bg-panel shrink-0"
            title="País del número"
          >
            {PAISES.map((p) => (
              <option key={p.id} value={p.id}>{p.bandera} {p.nombre} (+{p.codigo})</option>
            ))}
          </select>
          <input
            value={cobroWhatsapp}
            onChange={(e) => setCobroWhatsapp(e.target.value)}
            placeholder="Tu WhatsApp para que te contacten (opcional, ej: 71234567)"
            className="flex-1 px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
          />
        </div>
        <p className="font-body text-[11px] text-inksoft mb-3">
          Si lo cargás, en cada producto tuyo va a aparecer un botón "Contactar" que abre WhatsApp directo con vos.
        </p>

        <div className="mb-3">
          <div className="font-body text-xs text-inksoft mb-1.5">Logo de tu negocio (opcional)</div>
          <div className="flex items-center gap-3 flex-wrap">
            {tiendaLogoUrl && (
              <img src={tiendaLogoUrl} alt="Tu logo" loading="lazy" decoding="async" className="w-14 h-14 object-cover rounded-lg border border-line" />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirLogoTienda(e.target.files?.[0] || null)}
              disabled={subiendoLogo}
              className="font-body text-xs"
            />
          </div>
          {subiendoLogo && <div className="font-body text-xs text-maroon mt-1">Subiendo...</div>}
        </div>

        <div className="relative mb-2">
          <input
            value={tiendaDireccion}
            onChange={(e) => {
              const v = e.target.value
              setTiendaDireccion(v)
              setMercadosSugeridos(buscarMercados(v))
            }}
            onBlur={() => setTimeout(() => setMercadosSugeridos([]), 150)}
            placeholder="Dirección de tu local (ej: Calle Bolívar 123, o el mercado donde tenés tu puesto)"
            className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
          />
          {mercadosSugeridos.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-panel border border-line rounded-lg shadow-lg z-10 overflow-hidden">
              {mercadosSugeridos.map((m) => (
                <button
                  key={m.nombre}
                  type="button"
                  onClick={() => {
                    setTiendaDireccion(m.nombre)
                    setTiendaLat(m.lat)
                    setTiendaLng(m.lng)
                    setMercadosSugeridos([])
                  }}
                  className="w-full text-left px-3.5 py-2.5 font-body text-sm text-ink hover:bg-panelalt border-b border-line last:border-b-0"
                >
                  📍 {m.nombre} <span className="text-inksoft text-xs">— ubicación exacta confirmada</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={usarMiUbicacionTienda}
          disabled={buscandoUbicacionTienda}
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm text-ink bg-panelalt mb-3"
        >
          📍 {buscandoUbicacionTienda ? 'Buscando tu ubicación...' : tiendaLat != null ? 'Ubicación capturada ✓' : 'Usar mi ubicación actual'}
        </button>

        <input
          value={tiendaHorarios}
          onChange={(e) => setTiendaHorarios(e.target.value)}
          placeholder="Horarios (ej: Lunes a sábado, 9:00 a 18:00)"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
        />

        <div className="mb-3">
          <div className="font-body text-xs text-inksoft mb-2">Tipo de ventas</div>
          <div className="grid grid-cols-2 gap-2">
            {[
              ['mayorista', 'Mayorista'],
              ['minorista', 'Minorista'],
              ['haceEnvios', 'Hace envíos'],
              ['aceptaCambios', 'Acepta cambios'],
              ['permiteProbar', 'Permite probar'],
              ['pagoQr', 'Pago con QR'],
              ['videollamada', 'Hace videollamada'],
              ['pagoTarjeta', 'Pago con tarjeta'],
            ].map(([clave, label]) => (
              <label key={clave} className="flex items-center gap-2 font-body text-xs text-ink">
                <input
                  type="checkbox"
                  checked={!!tiposVenta[clave]}
                  onChange={(e) => setTiposVenta((prev) => ({ ...prev, [clave]: e.target.checked }))}
                />
                {label}
              </label>
            ))}
          </div>
          {tiposVenta.haceEnvios && (
            <div className="mt-3 bg-panelalt border border-line rounded-lg p-3">
              <div className="font-body text-xs font-semibold text-ink mb-1">🚚 Tus envíos</div>
              <div className="font-body text-[11px] text-inksoft mb-2">
                En el checkout le aparece al comprador “Envío del vendedor”: te paga a vos (tu QR o como acuerden) y vos coordinás la entrega.
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <label className="font-body text-[11px] text-inksoft">
                  Costo del envío ({PAIS_TIENDA.simboloMoneda})
                  <input
                    value={envioCosto}
                    onChange={(e) => setEnvioCosto(e.target.value.replace(/[^\d]/g, ''))}
                    inputMode="numeric"
                    placeholder="Vacío = a coordinar"
                    className="w-full mt-1 px-3 py-2 rounded-lg border border-line font-body text-sm bg-panel"
                  />
                </label>
                <label className="font-body text-[11px] text-inksoft">
                  ¿A dónde enviás?
                  <select value={envioAlcance} onChange={(e) => setEnvioAlcance(e.target.value as 'ciudad' | 'bolivia')} className="w-full mt-1 px-3 py-2 rounded-lg border border-line font-body text-sm bg-panel">
                    <option value="ciudad">Solo dentro de mi ciudad</option>
                    <option value="bolivia">A todo {PAIS_TIENDA.nombre}</option>
                  </select>
                </label>
              </div>
              <input
                value={envioDetalle}
                onChange={(e) => setEnvioDetalle(e.target.value.slice(0, 120))}
                placeholder="Detalle (opcional): ej. entrego en 24 h, envío por flota a otras ciudades"
                className="w-full mt-2 px-3 py-2 rounded-lg border border-line font-body text-sm bg-panel"
              />
            </div>
          )}
        </div>

        <div className="font-body text-xs text-inksoft mb-1.5 mt-4">Foto de tu QR de cobro</div>
        <div className="mb-3">
          <div className="flex items-center gap-3 flex-wrap">
            {cobroQrUrl && (
              <img src={cobroQrUrl} alt="Tu QR" loading="lazy" decoding="async" className="w-16 h-16 object-cover rounded-lg border border-line" />
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirQrCobro(e.target.files?.[0] || null)}
              disabled={subiendoQrCobro}
              className="font-body text-xs"
            />
          </div>
          {subiendoQrCobro && <div className="font-body text-xs text-maroon mt-1">Subiendo...</div>}
        </div>
        <input
          value={cobroCbu}
          onChange={(e) => setCobroCbu(e.target.value)}
          placeholder="CBU / número de cuenta (opcional, alternativa al QR)"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
        />
        <button
          type="button"
          onClick={guardarCobro}
          disabled={guardandoCobro || subiendoQrCobro || subiendoLogo}
          className="px-4 py-2 rounded-lg border-none bg-ink text-white font-body text-sm font-semibold disabled:opacity-60"
        >
          {guardandoCobro ? 'Guardando...' : 'Guardar datos de mi tienda'}
        </button>
        {cobroGuardado && <span className="font-body text-xs text-teal ml-3">Guardado ✓</span>}
      </div>

          </section>
          <section className={claseSeccion('premium', seccion)}>
      <div className="bg-panel border border-line rounded-xl p-5 mb-8">
        <div className="flex items-center justify-between mb-1">
          <div className="font-body text-sm font-semibold text-ink">Membresía Premium de tu tienda</div>
          {premiumVendedorVigente && (
            <span className="font-body text-[10px] font-bold text-white bg-ochre px-2 py-0.5 rounded-full">PREMIUM</span>
          )}
        </div>
        <p className="font-body text-[12px] text-inksoft mb-3">
          Con Premium, cada uno de tus productos puede tener hasta 4 fotos extra en su galería (además de la principal).
        </p>

        {premiumVendedorVigente ? (
          <div className="font-body text-xs text-teal">
            Vigente hasta {planVigenciaVendedor ? new Date(planVigenciaVendedor).toLocaleDateString('es-BO') : '—'}.
          </div>
        ) : planEstadoPagoVendedor === 'informado_pago' ? (
          <div className="font-body text-xs text-ochre bg-ochresoft rounded-md px-3 py-2">
            Avisaste que ya pagaste — estamos confirmando tu pago, se activa solo en cuanto lo revisemos.
          </div>
        ) : pagandoPremium ? (
          <div className="text-center pt-2">
            {QR_PLATAFORMA ? (
              <img src={QR_PLATAFORMA} alt="Código QR de pago" className="mx-auto w-44 rounded-lg border border-line mb-3" />
            ) : (
              <div className="text-left bg-panelalt border border-line rounded-lg p-3 font-body text-xs text-ink mb-3">
                {BANK_ACCOUNT_NUMBER ? <div><strong>Cuenta / CBU:</strong> {BANK_ACCOUNT_NUMBER}</div> : null}
                {BANK_NAME && <div><strong>Banco:</strong> {BANK_NAME}</div>}
                {BANK_ACCOUNT_NAME && <div><strong>Titular:</strong> {BANK_ACCOUNT_NAME}</div>}
              </div>
            )}
            <div className="font-display text-xl font-bold text-ink mb-3">Bs {PRECIO_PREMIUM_BS}</div>
            <button
              onClick={avisarPagoPremium}
              disabled={avisandoPago}
              className="w-full py-2.5 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold disabled:opacity-60"
            >
              {avisandoPago ? 'Avisando...' : 'Ya pagué'}
            </button>
            <button
              onClick={() => setPagandoPremium(false)}
              className="w-full mt-2 py-2 rounded-lg border border-line font-body text-xs text-inksoft"
            >
              Cancelar
            </button>
          </div>
        ) : (
          <button
            onClick={() => setPagandoPremium(true)}
            className="w-full py-2.5 rounded-lg border-none bg-ochre text-white font-body text-sm font-semibold"
          >
            Hacerme Premium — Bs {PRECIO_PREMIUM_BS}/mes
          </button>
        )}
      </div>

          </section>
          <section className={claseSeccion('cuenta', seccion)}>
      <MiCuenta abiertoInicial />
          </section>
        </main>
      </div>
    </div>
  )
}
