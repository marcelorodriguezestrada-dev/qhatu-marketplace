'use client'

import { nombreRubro } from '@/lib/arbolCategorias'
import { useTodasLasCiudades } from '@/lib/ciudad'
import { buscarPaisMercado, formatoMoneda, paisDeCiudad } from '@/lib/mercado'
import { PAISES } from '@/data/paises'
import { banderaDe } from '@/data/paisesMercado'
import { useEffect, useMemo, useState } from 'react'
import { ServiceIcon } from '@/components/ServiceIcon'
import { GraficoBarras } from '@/components/GraficoBarras'
import { useCategorias } from '@/lib/useCategorias'
import { useCategoriasProductos } from '@/lib/useCategoriasProductos'
import { labelPublicoProducto } from '@/data/publicoProducto'
import { DIAS_SEMANA, INTERVALOS_TURNO, BloqueHorario } from '@/data/turnos'
import { calcularNuevaVigencia } from '@/lib/planPremium'
import { calcularFranja, ordenarPorCercania, DEPOSITO } from '@/lib/reparto'
import { labelTipoAnuncio } from '@/data/anuncios'
import { parsearAnunciosWhatsapp, AnuncioParseado, mensajeInvitacionAnuncio } from '@/lib/parsearAnunciosWhatsapp'
import { extraerTextoDeArchivo } from '@/lib/leerArchivoTexto'
import EditorCV, { PuestoBorrador, aBorradores, deBorradores } from '@/components/EditorCV'
import type { Idioma } from '@/lib/cvEstandar'
import AdminCupones from '@/components/admin/AdminCupones'
import AdminCiudades from '@/components/admin/AdminCiudades'
import EtiquetasBusquedaIA from '@/components/admin/EtiquetasBusquedaIA'
import ProductosDeTienda from '@/components/admin/ProductosDeTienda'
import BotWhatsapp from '@/components/admin/BotWhatsapp'
import ConsumoBase from '@/components/admin/ConsumoBase'
import BaseDatos from '@/components/admin/BaseDatos'
import EdicionRapidaProductos from '@/components/admin/EdicionRapidaProductos'
import AdminCaptacion from '@/components/admin/AdminCaptacion'
import AdminFinanzas from '@/components/admin/AdminFinanzas'
import AdminFueraHorario from '@/components/admin/AdminFueraHorario'
import AdminPortada from '@/components/admin/AdminPortada'
import AdminZonasEnvio from '@/components/admin/AdminZonasEnvio'
import AdminMarketing from '@/components/admin/AdminMarketing'
import AdminLanzamiento from '@/components/admin/AdminLanzamiento'
import AdminContenido from '@/components/admin/AdminContenido'
import AdminReporteMarketing from '@/components/admin/AdminReporteMarketing'
import { buscarCiudad, ciudadDe } from '@/data/ciudades'
import AdminAnalitica from '@/components/admin/AdminAnalitica'
import AdminRecuperacion from '@/components/admin/AdminRecuperacion'
import AlarmaPedidos from '@/components/admin/AlarmaPedidos'
import PublicacionFacebook from '@/components/admin/PublicacionFacebook'
import CrearUsuario, { mensajeAcceso, abrirWhatsapp, generarPassword } from '@/components/admin/CrearUsuario'
import CrearUsuarioPrueba from '@/components/admin/CrearUsuarioPrueba'
import PedirProductosIA from '@/components/admin/PedirProductosIA'
import { CampoRedes } from '@/components/profesional/RedesSociales'
import CampoReservas from '@/components/profesional/CampoReservas'
import { reservasDe, type ReservasProfesional } from '@/lib/reservas'
import { entrarComoUsuario } from '@/lib/modoAdmin'
import { useSeccionHash, SidebarSecciones, MenuCelularSecciones, VolverCelularSecciones, type ItemSeccion } from '@/components/NavSecciones'
import FiltrosLista, { aplicarFiltros, FILTROS_INICIALES, type Filtros } from '@/components/admin/FiltrosLista'

function bs(n: number, pais?: string) {
  // Pedidos de otro país (ej. Argentina): en su moneda.
  return formatoMoneda(n, buscarPaisMercado(pais))
}

const ESTADOS_LABEL: Record<string, { texto: string; color: string }> = {
  verificando_stock: { texto: 'Verificando stock con el vendedor', color: 'text-ochre' },
  pendiente_pago: { texto: 'Esperando que pague', color: 'text-inksoft' },
  informado_pago: { texto: 'Dice que ya pagó — revisar', color: 'text-ochre' },
  pagado: { texto: 'Pagado', color: 'text-teal' },
  en_preparacion: { texto: 'En preparación', color: 'text-indigo-600' },
  en_entrega: { texto: 'En entrega', color: 'text-amber-600' },
  entregado: { texto: 'Entregado', color: 'text-emerald-600' },
  cancelado: { texto: 'Cancelado', color: 'text-red-600' },
}

const ICONOS_SERVICIO = ['abogado', 'contador', 'electricista', 'enfermera', 'estilista', 'ingeniero', 'manicurista', 'medico', 'odontologo', 'oftalmologo', 'pintor', 'plomero', 'profesor', 'otro']

// Qué números se pueden graficar en la línea de tiempo de Métricas, y
// cómo mostrar cada uno (etiqueta corta para el selector, color de la
// barra, y si es plata para formatear en Bs en vez de un número pelado).
const CAMPOS_METRICAS = {
  visitas: { label: 'Visitas al sitio', color: '#1a7f6e' },
  vistasProductos: { label: 'Vistas de productos', color: '#8a5a2f' },
  vistasProfesionales: { label: 'Vistas de profesionales', color: '#8a5a2f' },
  vistasAnuncios: { label: 'Vistas de anuncios', color: '#8a5a2f' },
  clicsWhatsapp: { label: 'Clics a WhatsApp', color: '#25a244' },
  busquedasProductos: { label: 'Búsquedas de productos', color: '#b08900' },
  busquedasServicios: { label: 'Búsquedas de servicios', color: '#b08900' },
  pedidos: { label: 'Pedidos', color: '#7a1f2b' },
  facturado: { label: 'Facturado (Bs)', color: '#7a1f2b', esPlata: true },
  productosPublicados: { label: 'Productos publicados', color: '#3a5a8a' },
  profesionalesPublicados: { label: 'Profesionales publicados', color: '#3a5a8a' },
  anunciosPublicados: { label: 'Anuncios publicados', color: '#3a5a8a' },
} as const

function BadgeRiesgoIA({ moderacionIA }: { moderacionIA: { riesgo: string; motivo: string } | null | undefined }) {
  if (!moderacionIA) return null
  const estilos: Record<string, string> = {
    alto: 'bg-maroonsoft text-maroon border-maroon',
    medio: 'bg-ochresoft text-ochre border-ochre',
    bajo: 'bg-tealsoft text-teal border-teal',
  }
  const clase = estilos[moderacionIA.riesgo] || 'bg-panelalt text-inksoft border-line'
  return (
    <div className={`inline-flex items-center gap-1 border rounded-full px-2 py-0.5 text-[10px] font-semibold font-body mt-1 ${clase}`} title={moderacionIA.motivo}>
      IA: riesgo {moderacionIA.riesgo}
    </div>
  )
}

// Prioridad de invitación que calculó la IA (profesionales y anuncios).
function BadgePrioridad({ pr }: { pr: { puntaje: number; motivo?: string } }) {
  const estilo = pr.puntaje >= 70 ? 'text-teal bg-tealsoft border-teal' : pr.puntaje >= 40 ? 'text-indigo-700 bg-indigo-50 border-indigo-200' : 'text-inksoft bg-panelalt border-line'
  return (
    <div className={`font-body text-[11px] border rounded-md px-2.5 py-1.5 my-1.5 ${estilo}`}>
      <span className="font-semibold">
        {pr.puntaje >= 70 ? '🔥' : pr.puntaje >= 40 ? '👍' : '💤'} Prioridad de invitación: {pr.puntaje}/100
      </span>
      {pr.motivo && <> — {pr.motivo}</>}
    </div>
  )
}

type TabAdmin = 'inicio' | 'pedidos' | 'productos' | 'servicios' | 'anuncios' | 'usuarios' | 'reparto' | 'banners' | 'categorias' | 'categorias-productos' | 'metricas' | 'cupones' | 'analitica' | 'marketing' | 'zonas' | 'captacion' | 'finanzas' | 'consumo' | 'base'

const SECCIONES_ADMIN: ItemSeccion<TabAdmin>[] = [
  { id: 'inicio', icono: '🏠', label: 'Inicio', ayuda: 'Resumen y QR de cobro', grupo: 'General' },
  { id: 'pedidos', icono: '🧾', label: 'Pedidos', ayuda: 'Pagos, preparación y entregas', grupo: 'Ventas' },
  { id: 'reparto', icono: '🛵', label: 'Reparto', ayuda: 'Entregas del día por zona', grupo: 'Ventas' },
  { id: 'cupones', icono: '🎟️', label: 'Cupones', ayuda: 'Promos y campañas', grupo: 'Ventas' },
  { id: 'marketing', icono: '📣', label: 'Marketing', ayuda: 'Campañas, mensajes y volantes', grupo: 'Ventas' },
  { id: 'captacion', icono: '🎯', label: 'Captar tiendas', ayuda: 'Mapa de tiendas, prospectos y estrategia', grupo: 'Ventas' },
  { id: 'productos', icono: '📦', label: 'Productos', ayuda: 'Moderación y vendedores', grupo: 'Contenido' },
  { id: 'servicios', icono: '🧑‍🔧', label: 'Servicios profesionales', ayuda: 'Solicitudes e invitaciones', grupo: 'Contenido' },
  { id: 'anuncios', icono: '📢', label: 'Anuncios', ayuda: 'Clasificados, importar y Facebook', grupo: 'Contenido' },
  { id: 'banners', icono: '🖼️', label: 'Banners y portada', ayuda: 'Qué se ve en la portada', grupo: 'Contenido' },
  { id: 'usuarios', icono: '👥', label: 'Usuarios', ayuda: 'Crear, editar, contraseñas', grupo: 'Personas' },
  { id: 'categorias', icono: '🗂️', label: 'Categorías', ayuda: 'Rubros de servicios', grupo: 'Configuración' },
  { id: 'categorias-productos', icono: '🏷️', label: 'Categorías de productos', ayuda: 'Rubros de productos', grupo: 'Configuración' },
  { id: 'zonas', icono: '📍', label: 'Envíos y checkout', ayuda: 'Opciones del checkout, zonas y mapa de costos', grupo: 'Configuración' },
  { id: 'base', icono: '🗄️', label: 'Base de datos', ayuda: 'Ver, editar y eliminar datos (con papelera)', grupo: 'Configuración' },
  { id: 'finanzas', icono: '💰', label: 'Finanzas', ayuda: 'Ingresos, gastos y reporte', grupo: 'Números' },
  { id: 'metricas', icono: '📊', label: 'Métricas', ayuda: 'Números del sitio', grupo: 'Números' },
  { id: 'analitica', icono: '📈', label: 'Analítica', ayuda: 'Eventos y recuperación de compras', grupo: 'Números' },
  { id: 'consumo', icono: '🔋', label: 'Consumo de la base', ayuda: 'Qué gasta las lecturas gratis y pausar', grupo: 'Números' },
]
const IDS_ADMIN = SECCIONES_ADMIN.map((s) => s.id)

export default function AdminPage() {
  const [password, setPassword] = useState('')
  const [autenticado, setAutenticado] = useState(false)
  const [solicitudes, setSolicitudes] = useState<any[]>([])
  const [cargandoSolicitudes, setCargandoSolicitudes] = useState(false)
  const [error, setError] = useState('')
  const [cargando, setCargando] = useState(false)
  // Sección del panel (va en el hash: /admin#usuarios). Sin sección, en
  // computadora se ve "Inicio" y en el celular el menú de opciones.
  const { seccion: seccionAdmin, irA: irASeccionAdmin, volver: volverAdmin } = useSeccionHash(IDS_ADMIN)
  const tab: TabAdmin = seccionAdmin ?? 'inicio'
  const setTab = (t: TabAdmin) => irASeccionAdmin(t)
  const { categorias, buscarRubro, recargar: recargarCategorias } = useCategorias()
  const { categorias: categoriasProductos, buscarRubroProducto, recargar: recargarCategoriasProductos } = useCategoriasProductos()

  const [pedidos, setPedidos] = useState<any[]>([])
  const [subiendoFotoEntregaId, setSubiendoFotoEntregaId] = useState<string | null>(null)
  const [productos, setProductos] = useState<any[]>([])
  // Productos → "🏪 Productos por tienda": la tienda elegida ('' = todas) filtra toda la pestaña.
  const [tiendaProductos, setTiendaProductos] = useState('')
  const productosVista = useMemo(() => (tiendaProductos ? productos.filter((p) => p.vendedorId === tiendaProductos) : productos), [productos, tiendaProductos])
  const [categoriaProductoExpandida, setCategoriaProductoExpandida] = useState<string | null>(null)
  const [profesionales, setProfesionales] = useState<any[]>([])
  const [usuarios, setUsuarios] = useState<any[]>([])
  const ciudadesTodas = useTodasLasCiudades()
  const [anuncios, setAnuncios] = useState<any[]>([])
  const [banners, setBanners] = useState<any[]>([])
  const [subiendoBanner, setSubiendoBanner] = useState(false)
  const [bannerLinkNuevo, setBannerLinkNuevo] = useState('')
  const [macheos, setMacheos] = useState<any>(null)
  const [cargandoMacheos, setCargandoMacheos] = useState(false)

  // Análisis con IA de los anuncios que el macheo exacto por rubro no
  // resolvió, y envío puntual de la sugerencia a ambas partes.
  const [sugerenciasIA, setSugerenciasIA] = useState<any[] | null>(null)
  const [analizandoIA, setAnalizandoIA] = useState(false)
  const [mensajeAnalisisIA, setMensajeAnalisisIA] = useState('')
  const [enviandoSugerenciaId, setEnviandoSugerenciaId] = useState<string | null>(null)
  const [sugerenciasEnviadas, setSugerenciasEnviadas] = useState<Set<string>>(new Set())

  async function analizarMatcheosIA() {
    setAnalizandoIA(true)
    setMensajeAnalisisIA('')
    try {
      const res = await fetch('/api/admin/macheos/analizar-ia', {
        method: 'POST',
        headers: { 'x-admin-password': password },
      })
      const data = await res.json()
      if (data.error) {
        setMensajeAnalisisIA(data.error)
        setSugerenciasIA([])
        return
      }
      setSugerenciasIA(data.sugerencias || [])
      setMensajeAnalisisIA(data.mensaje || (data.sugerencias?.length ? '' : 'La IA no encontró ninguna coincidencia razonable por ahora.'))
    } finally {
      setAnalizandoIA(false)
    }
  }

  async function sugerirAAmbasPartes(s: any) {
    const clave = `${s.anuncioId}:${s.profesionalId}`
    setEnviandoSugerenciaId(clave)
    try {
      const res = await fetch('/api/admin/macheos/sugerir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ anuncioId: s.anuncioId, profesionalId: s.profesionalId, motivo: s.motivo }),
      })
      const data = await res.json()
      if (!data.error) {
        setSugerenciasEnviadas((prev) => new Set(prev).add(clave))
      }
    } finally {
      setEnviandoSugerenciaId(null)
    }
  }
  const [anuncioExpandido, setAnuncioExpandido] = useState<string | null>(null)
  const [cargandoUsuarios, setCargandoUsuarios] = useState(false)
  // uid del usuario cuya fila está desplegada mostrando el detalle de
  // sus productos y perfiles profesionales (null = ninguna abierta).
  const [usuarioExpandidoId, setUsuarioExpandidoId] = useState<string | null>(null)
  const [buscarUsuario, setBuscarUsuario] = useState('')
  const [metricas, setMetricas] = useState<any>(null)
  const [cargandoMetricas, setCargandoMetricas] = useState(false)
  // Línea de tiempo de la pestaña Métricas: qué período se ve
  // (día/mes/año) y qué número se está graficando.
  const [periodoMetricas, setPeriodoMetricas] = useState<'dia' | 'mes' | 'anio'>('dia')
  const [campoMetricas, setCampoMetricas] = useState<keyof typeof CAMPOS_METRICAS>('visitas')

  const resumen = {
    pedidosTotal: pedidos.length,
    pedidosPagados: pedidos.filter((p) => p.estado === 'pagado' || p.estado === 'en_preparacion' || p.estado === 'en_entrega' || p.estado === 'entregado').length,
    productosActivos: productos.filter((p) => p.estado === 'activo').length,
    productosPremium: productos.filter((p) => p.plan === 'premium').length,
    profesionalesTotal: profesionales.length,
  }

  // Formulario de alta de profesional
  const [nombre, setNombre] = useState('')
  const [emailProfesional, setEmailProfesional] = useState('')
  // Id de la solicitud para la que se está escribiendo la nota de "pedir
  // más info" en este momento (null = ninguna abierta), y el texto que
  // se va tipeando ahí.
  const [pidiendoInfoId, setPidiendoInfoId] = useState<string | null>(null)
  const [priorizandoIA, setPriorizandoIA] = useState(false)
  const [errorPriorizarIA, setErrorPriorizarIA] = useState('')
  const [notaPidiendoInfo, setNotaPidiendoInfo] = useState('')
  const [rubro, setRubro] = useState('')
  const [categoriaSel, setCategoriaSel] = useState('')
  const [especialidad, setEspecialidad] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [dondeTrabaja, setDondeTrabaja] = useState('')
  const [educacion, setEducacion] = useState('')
  const [servicios, setServicios] = useState<string[]>([])
  const [nuevoServicio, setNuevoServicio] = useState('')
  // CV estandarizado (historial laboral + idiomas) — mismo editor que
  // en /mi-perfil, ver src/components/EditorCV.tsx.
  const [historialCV, setHistorialCV] = useState<PuestoBorrador[]>([])
  const [idiomasCV, setIdiomasCV] = useState<Idioma[]>([])
  const [cvPublico, setCvPublico] = useState(true)
  const [zona, setZona] = useState('')
  // Ciudad (y con ella el país) del profesional que se carga a mano.
  const [ciudadPf, setCiudadPf] = useState('potosi')
  const [direccion, setDireccion] = useState('')
  const [lat, setLat] = useState('')
  const [lng, setLng] = useState('')
  const [whatsapp, setWhatsapp] = useState('')
  const [instagram, setInstagram] = useState('')
  const [redesPf, setRedesPf] = useState<string[]>([''])
  const [reservasPf, setReservasPf] = useState<ReservasProfesional>({ consultorio: false, videollamada: false })
  const [linkVideoPf, setLinkVideoPf] = useState('')
  const [icono, setIcono] = useState(ICONOS_SERVICIO[0])
  const [imagenUrl, setImagenUrl] = useState('')
  const [subiendoImagen, setSubiendoImagen] = useState(false)
  const [precio, setPrecio] = useState('')
  const [experiencia, setExperiencia] = useState('')
  const [plan, setPlan] = useState<'basico' | 'premium'>('basico')
  // Subir CV del profesional: la IA propone nombre/especialidad/
  // experiencia/descripción y los precarga directo en los campos de
  // arriba — el propio formulario (con su botón "Guardar cambios") ya
  // hace de paso de revisión, así que acá no hace falta una vista previa
  // aparte como en /mi-perfil.
  const [leyendoCVAdmin, setLeyendoCVAdmin] = useState(false)
  const [rubroSugeridoCV, setRubroSugeridoCV] = useState<string | null>(null)
  const [publicando, setPublicando] = useState(false)
  const [errorForm, setErrorForm] = useState('')
  // null = formulario en modo "publicar nuevo". Con un id, el mismo
  // formulario pasa a modo edición de ese profesional ya existente.
  const [profesionalEditandoId, setProfesionalEditandoId] = useState<string | null>(null)
  // Admin → Servicios en pestañas, para no scrollear todo.
  const [vistaServ, setVistaServ] = useState<'publicados' | 'pendientes' | 'form' | 'importar'>('publicados')
  const [buscarServ, setBuscarServ] = useState('')
  const [filtroCiudadServ, setFiltroCiudadServ] = useState('')
  const [filtroPlanServ, setFiltroPlanServ] = useState<'' | 'premium' | 'basico'>('')
  const [ordenServ, setOrdenServ] = useState<'contactos' | 'vistas' | 'recientes' | 'nombre'>('contactos')
  const [limiteServ, setLimiteServ] = useState(40)
  const [editHorarioBloques, setEditHorarioBloques] = useState<BloqueHorario[]>([])
  const [editNuevoBloqueDias, setEditNuevoBloqueDias] = useState<number[]>([])
  const [editNuevoBloqueDesde, setEditNuevoBloqueDesde] = useState('09:00')
  const [editNuevoBloqueHasta, setEditNuevoBloqueHasta] = useState('18:00')
  const [editNuevoBloqueIntervalo, setEditNuevoBloqueIntervalo] = useState(60)
  const [editNuevoBloqueTodoElDia, setEditNuevoBloqueTodoElDia] = useState(false)
  const [guardandoHorarioAdmin, setGuardandoHorarioAdmin] = useState(false)
  const [horarioAdminGuardado, setHorarioAdminGuardado] = useState(false)

  // Pestaña "Categorías": alta de categoría nueva, alta de rubro dentro
  // de una categoría, y reubicar un rubro existente a otra categoría.
  const [nuevaCategoriaLabel, setNuevaCategoriaLabel] = useState('')
  const [guardandoCategoria, setGuardandoCategoria] = useState(false)
  const [errorCategorias, setErrorCategorias] = useState('')
  const [categoriaAbierta, setCategoriaAbierta] = useState<string | null>(null)
  const [nuevoRubroLabel, setNuevoRubroLabel] = useState('')
  const [guardandoRubro, setGuardandoRubro] = useState(false)
  const [renombrandoCategoriaId, setRenombrandoCategoriaId] = useState<string | null>(null)
  const [nuevoNombreCategoria, setNuevoNombreCategoria] = useState('')

  // Pestaña "Categorías de productos": mismo esquema que la de
  // servicios de arriba, pero contra /api/categorias-productos.
  const [nuevaCategoriaProductoLabel, setNuevaCategoriaProductoLabel] = useState('')
  const [guardandoCategoriaProducto, setGuardandoCategoriaProducto] = useState(false)
  const [errorCategoriasProductos, setErrorCategoriasProductos] = useState('')
  const [categoriaProductoAbierta, setCategoriaProductoAbierta] = useState<string | null>(null)
  const [nuevoRubroProductoLabel, setNuevoRubroProductoLabel] = useState('')
  const [guardandoRubroProducto, setGuardandoRubroProducto] = useState(false)
  const [renombrandoCategoriaProductoId, setRenombrandoCategoriaProductoId] = useState<string | null>(null)
  const [nuevoNombreCategoriaProducto, setNuevoNombreCategoriaProducto] = useState('')

  useEffect(() => {
    if (categorias.length === 0 || categoriaSel) return
    setCategoriaSel(categorias[0].id)
    setRubro(categorias[0].rubros[0]?.id || 'otro')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categorias])

  useEffect(() => {
    const guardada = typeof window !== 'undefined' ? localStorage.getItem('clasiclick_admin_pw') : null
    if (guardada) {
      setPassword(guardada)
      entrar(guardada)
    }
  }, [])

  function entrar(pw: string) {
    setCargando(true)
    fetch('/api/pedidos', { headers: { 'x-admin-password': pw } })
      .then(async (r) => {
        const d = await r.json().catch(() => ({}))
        if (!r.ok && !d.sinCuota) throw new Error(d.error || 'Contraseña incorrecta.')
        return d
      })
      .then((data) => {
        setPedidos(data.pedidos || [])
        setAutenticado(true)
        setError(data.sinCuota ? data.error : '')
        if (data.sinCuota) setTab('consumo')
        localStorage.setItem('clasiclick_admin_pw', pw)
        // Importante: le pasamos "pw" explícito acá, no dependemos del
        // estado "password" — en el login automático (contraseña
        // guardada en localStorage), el estado todavía no se actualizó
        // en este mismo instante, y usar la versión vieja hacía que
        // estos pedidos salieran sin contraseña válida (mostrando la
        // vista pública filtrada en vez de la completa).
        cargarProfesionales(pw)
        cargarProductos(pw)
        cargarAnuncios(pw)
        cargarBanners(pw)
        cargarMacheos(pw)
        cargarConfigPagos()
      })
      .catch((e) => {
        setError(e.message)
        setAutenticado(false)
      })
      .finally(() => setCargando(false))
  }

  // QR de cobro para pedidos con envío (se paga acá, nunca directo al
  // vendedor — ver la explicación en checkout/page.tsx).
  const [qrPagoUrl, setQrPagoUrl] = useState('')
  const [cbuPago, setCbuPago] = useState('')
  const [bancoPago, setBancoPago] = useState('')
  const [titularPago, setTitularPago] = useState('')
  const [whatsappPago, setWhatsappPago] = useState('')
  const [subiendoQrPago, setSubiendoQrPago] = useState(false)
  const [guardandoConfigPago, setGuardandoConfigPago] = useState(false)
  const [configPagoGuardada, setConfigPagoGuardada] = useState(false)

  function cargarConfigPagos() {
    fetch('/api/configuracion/pagos')
      .then((r) => r.json())
      .then((data) => {
        setQrPagoUrl(data.qrImageUrl || '')
        setCbuPago(data.cbu || '')
        setBancoPago(data.banco || '')
        setTitularPago(data.titular || '')
        setWhatsappPago(data.whatsapp || '')
      })
  }

  async function subirQrPago(file: File | null) {
    if (!file) return
    setSubiendoQrPago(true)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setQrPagoUrl(data.url)
    } catch (e: any) {
      setError('Error subiendo el QR: ' + e.message)
    } finally {
      setSubiendoQrPago(false)
    }
  }

  async function guardarConfigPagos() {
    setGuardandoConfigPago(true)
    setConfigPagoGuardada(false)
    try {
      await fetch('/api/configuracion/pagos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ qrImageUrl: qrPagoUrl, cbu: cbuPago, banco: bancoPago, titular: titularPago, whatsapp: whatsappPago }),
      })
      setConfigPagoGuardada(true)
    } finally {
      setGuardandoConfigPago(false)
    }
  }

  function cargarProfesionales(pw?: string) {
    fetch('/api/profesionales?admin=1', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setProfesionales(data.profesionales || []))
  }

  // "Ordenar por prioridad con IA" en las solicitudes pendientes: la IA
  // puntúa a quién conviene invitar primero (ver
  // /api/admin/profesionales/priorizar) y la lista se ordena por eso.
  async function priorizarPendientesConIA() {
    setPriorizandoIA(true)
    setErrorPriorizarIA('')
    try {
      const res = await fetch('/api/admin/profesionales/priorizar', {
        method: 'POST',
        headers: { 'x-admin-password': password },
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      const porId = new Map<string, any>((data.prioridades || []).map((pr: any) => [pr.id, pr]))
      setProfesionales((lista) =>
        lista.map((p) => {
          const pr = porId.get(p.id)
          return pr ? { ...p, prioridadInvitacionIA: { puntaje: pr.puntaje, motivo: pr.motivo, evaluadoEn: pr.evaluadoEn } } : p
        })
      )
    } catch (e: any) {
      setErrorPriorizarIA(e?.message || 'No se pudo priorizar con IA.')
    } finally {
      setPriorizandoIA(false)
    }
  }

  function cargarMetricas(pw?: string) {
    setCargandoMetricas(true)
    fetch('/api/admin/metricas', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setMetricas(data))
      .finally(() => setCargandoMetricas(false))
  }

  function cargarProductos(pw?: string) {
    fetch('/api/productos?admin=1', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setProductos(data.productos || []))
  }

  function cargarAnuncios(pw?: string) {
    fetch('/api/anuncios?admin=1', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setAnuncios(data.anuncios || []))
  }

  function cargarBanners(pw?: string) {
    fetch('/api/banners', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setBanners(data.banners || []))
  }

  async function subirBanner(file: File | null) {
    if (!file) return
    setSubiendoBanner(true)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const resSubida = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const dataSubida = await resSubida.json()
      if (dataSubida.error) throw new Error(dataSubida.error)

      await fetch('/api/banners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ imagenUrl: dataSubida.url, link: bannerLinkNuevo || null, orden: banners.length }),
      })
      setBannerLinkNuevo('')
      cargarBanners()
    } catch (e: any) {
      alert('Error subiendo el banner: ' + e.message)
    } finally {
      setSubiendoBanner(false)
    }
  }

  function toggleBanner(id: string, activo: boolean) {
    fetch(`/api/banners/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ activo }),
    }).then(() => cargarBanners())
  }

  function eliminarBanner(id: string) {
    if (!confirm('¿Eliminar este banner?')) return
    fetch(`/api/banners/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarBanners())
  }

  function cargarMacheos(pw?: string) {
    setCargandoMacheos(true)
    fetch('/api/admin/macheos', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setMacheos(data))
      .finally(() => setCargandoMacheos(false))
  }

  function cambiarEstadoAnuncio(id: string, estado: 'aprobado' | 'rechazado') {
    fetch(`/api/anuncios/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => {
      cargarAnuncios()
      cargarMacheos()
    })
  }

  function cambiarEstadoAnuncioConNota(id: string, estado: string, notaAdmin: string) {
    fetch(`/api/anuncios/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado, notaAdmin }),
    }).then(() => cargarAnuncios())
  }

  function eliminarAnuncio(id: string) {
    if (!confirm('¿Eliminar este anuncio? No se puede deshacer.')) return
    fetch(`/api/anuncios/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarAnuncios())
  }

  // Importación en lote de anuncios (pegar texto de un canal de WhatsApp)
  const [textoImportarAnuncios, setTextoImportarAnuncios] = useState('')
  const [parseadosAnuncios, setParseadosAnuncios] = useState<(AnuncioParseado & { incluir: boolean })[]>([])
  const [importandoAnuncios, setImportandoAnuncios] = useState(false)
  const [resultadoImportacion, setResultadoImportacion] = useState<{ creados: number; errores: string[] } | null>(null)

  // Importación en lote de profesionales/servicios — mismo mecanismo que
  // arriba (mismo formato de texto, mismo parser), pero el resultado
  // SIEMPRE queda pendiente de revisión: acá no hay atajo de "completo
  // = se aprueba solo", porque un rubro y una zona reales no salen de
  // un texto de WhatsApp.
  const [textoImportarServicios, setTextoImportarServicios] = useState('')
  const [parseadosServicios, setParseadosServicios] = useState<(AnuncioParseado & { incluir: boolean })[]>([])
  const [importandoServicios, setImportandoServicios] = useState(false)
  const [resultadoImportacionServicios, setResultadoImportacionServicios] = useState<{ creados: number; errores: string[] } | null>(null)

  function parsearTextoServicios() {
    const parseados = parsearAnunciosWhatsapp(textoImportarServicios)
    setParseadosServicios(parseados.map((p) => ({ ...p, incluir: true })))
    setResultadoImportacionServicios(null)
  }

  function actualizarParseadoServicio(i: number, cambios: Partial<AnuncioParseado & { incluir: boolean }>) {
    setParseadosServicios((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...cambios } : p)))
  }

  async function importarServiciosSeleccionados() {
    const seleccionados = parseadosServicios.filter((p) => p.incluir)
    if (seleccionados.length === 0) return
    setImportandoServicios(true)
    try {
      const res = await fetch('/api/admin/profesionales/importar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({
          profesionales: seleccionados.map((p) => ({
            nombre: p.titulo,
            descripcion: p.descripcion,
            telefono: p.telefono,
            notaAdmin: p.incompleto ? 'Además, el texto quedó cortado — pedile al contacto la descripción completa.' : null,
          })),
        }),
      })
      const data = await res.json()
      setResultadoImportacionServicios({ creados: data.creados || 0, errores: data.errores || [] })
      setParseadosServicios((prev) => prev.filter((p) => !p.incluir))
      cargarProfesionales()
    } finally {
      setImportandoServicios(false)
    }
  }

  function parsearTextoAnuncios() {
    const parseados = parsearAnunciosWhatsapp(textoImportarAnuncios)
    setParseadosAnuncios(parseados.map((p) => ({ ...p, incluir: true })))
    setResultadoImportacion(null)
  }

  function actualizarParseado(i: number, cambios: Partial<AnuncioParseado & { incluir: boolean }>) {
    setParseadosAnuncios((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...cambios } : p)))
  }

  async function importarAnunciosSeleccionados() {
    const seleccionados = parseadosAnuncios.filter((p) => p.incluir)
    if (seleccionados.length === 0) return
    setImportandoAnuncios(true)
    try {
      const res = await fetch('/api/admin/anuncios/importar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({
          anuncios: seleccionados.map((p) => ({
            titulo: p.titulo,
            descripcion: p.descripcion,
            telefono: p.telefono,
            tipo: 'busqueda',
            estado: p.incompleto ? 'info_solicitada' : 'aprobado',
            notaAdmin: p.incompleto ? 'Importado desde WhatsApp con el texto cortado — falta pedirle al contacto la descripción completa.' : null,
          })),
        }),
      })
      const data = await res.json()
      setResultadoImportacion({ creados: data.creados || 0, errores: data.errores || [] })
      setParseadosAnuncios((prev) => prev.filter((p) => !p.incluir))
      cargarAnuncios()
    } finally {
      setImportandoAnuncios(false)
    }
  }

  function cargarUsuarios(pw?: string) {
    setCargandoUsuarios(true)
    fetch('/api/admin/usuarios', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setUsuarios(data.usuarios || []))
      .finally(() => setCargandoUsuarios(false))
  }

  function pausarUsuario(uid: string, pausado: boolean) {
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ pausado }),
    }).then(() => cargarUsuarios())
  }

  // No le llegó el código de 6 dígitos: se da por verificado desde acá.
  function verificarUsuario(uid: string, email: string) {
    if (!confirm(`¿Dar por verificado el email ${email}? Va a poder comprar y vender sin poner el código.`)) return
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'verificar' }),
    }).then(() => cargarUsuarios())
  }

  // Ciudad que ve el usuario ('' = automática: por la IP o la que elija).
  function asignarCiudadUsuario(uid: string, ciudad: string) {
    setUsuarios((prev) => prev.map((u) => (u.uid === uid ? { ...u, ciudadAsignada: ciudad || null } : u)))
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ ciudadAsignada: ciudad || null }),
    }).then(() => cargarUsuarios())
    // "Ve X" solo cambia lo que ve. Si tiene tienda en otra ciudad, se
    // ofrece moverla también (si no, sus productos siguen con la moneda vieja).
    const tienda = vendedoresAdmin.find((v) => v.id === uid)
    if (ciudad && tienda && ciudadDe(tienda) !== ciudad) {
      const n = productos.filter((p) => p.vendedorId === uid).length
      if (confirm(`Su tienda está en ${buscarCiudad(ciudadDe(tienda)).nombre}. ¿Mover también la tienda y sus ${n} producto(s) a ${buscarCiudad(ciudad).nombre}? (precios en ${paisDeCiudad(ciudad).simboloMoneda})`)) cambiarCiudadTienda(uid, ciudad, false)
    }
  }

  // Ciudad de la tienda: se copia a todos sus productos (país, moneda y dónde aparecen).
  function cambiarCiudadTienda(uid: string, ciudad: string, preguntar = true) {
    const tienda = vendedoresAdmin.find((v) => v.id === uid)
    if (!tienda || !ciudad || ciudadDe(tienda) === ciudad) return
    const n = productos.filter((p) => p.vendedorId === uid).length
    if (preguntar && !confirm(`¿Mover la tienda y sus ${n} producto(s) a ${buscarCiudad(ciudad).nombre}? Los precios pasan a ${paisDeCiudad(ciudad).simboloMoneda} (los números no cambian).`)) return
    setVendedoresAdmin((prev) => prev.map((v) => (v.id === uid ? { ...v, ciudad } : v)))
    fetch(`/api/vendedores/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ ciudad }),
    }).then(() => { cargarVendedoresAdmin(); cargarProductos() })
  }

  // "🌎 También visible en": la tienda (y sus productos) aparece además en
  // otras ciudades — ej. tiendas de Potosí en Buenos Aires para probar.
  function cambiarVisibleEn(uid: string, visibleEn: string[]) {
    setVendedoresAdmin((prev) => prev.map((v) => (v.id === uid ? { ...v, visibleEn } : v)))
    fetch(`/api/vendedores/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ visibleEn }),
    }).then(() => { cargarVendedoresAdmin(); cargarProductos() })
  }

  function marcarUsuarioPrueba(uid: string, esPrueba: boolean) {
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ esPrueba }),
    }).then(() => cargarUsuarios())
  }

  const [vendedorParaCargar, setVendedorParaCargar] = useState('')
  const [edicionUsuario, setEdicionUsuario] = useState<{ uid: string; email: string; nombre: string; whatsapp: string; whatsappPais: string; nombreNegocio: string; tieneTienda: boolean } | null>(null)
  const [guardandoUsuario, setGuardandoUsuario] = useState(false)
  // Poner / cambiar contraseña de un usuario desde el admin.
  // Admins delegados (solo los ve y maneja el admin principal; null = no sos el principal).
  const [administradores, setAdministradores] = useState<any[] | null>(null)
  const [pedirProductosUid, setPedirProductosUid] = useState<string | null>(null)
  const [claveAdminNueva, setClaveAdminNueva] = useState<{ uid: string; clave: string; email: string; whatsapp?: string } | null>(null)

  function cargarAdministradores() {
    fetch('/api/admin/administradores', { headers: { 'x-admin-password': password } })
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => setAdministradores(d ? d.administradores || [] : null))
      .catch(() => setAdministradores(null))
  }

  async function hacerAdmin(u: any) {
    if (!confirm(`¿Darle permisos de administrador a ${u.email || u.nombre}? Va a poder ver y cambiar todo el panel (pedidos, usuarios, pagos…), menos crear o quitar otros admins.`)) return
    const res = await fetch('/api/admin/administradores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ uid: u.uid, email: u.email, nombre: u.nombre }),
    })
    const d = await res.json()
    if (!res.ok) { alert(d.error || 'No se pudo.'); return }
    setClaveAdminNueva({ uid: u.uid, clave: d.clave, email: u.email || '', whatsapp: u.whatsapp })
    cargarAdministradores()
  }

  async function quitarAdmin(id: string, quien: string) {
    if (!confirm(`¿Quitarle el acceso de administrador a ${quien}? Su clave deja de funcionar enseguida.`)) return
    await fetch(`/api/admin/administradores?id=${id}`, { method: 'DELETE', headers: { 'x-admin-password': password } })
    setClaveAdminNueva(null)
    cargarAdministradores()
  }

  const [passwordUsuario, setPasswordUsuario] = useState<{ uid: string; valor: string; guardada: boolean; error: string; guardando: boolean } | null>(null)

  async function guardarPasswordUsuario() {
    if (!passwordUsuario) return
    const { uid, valor } = passwordUsuario
    if (valor.length < 6) { setPasswordUsuario({ ...passwordUsuario, error: 'Mínimo 6 caracteres.' }); return }
    setPasswordUsuario({ ...passwordUsuario, guardando: true, error: '' })
    try {
      const d = await fetch(`/api/admin/usuarios/${uid}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'password', password: valor }),
      }).then((r) => r.json())
      if (d.error) throw new Error(d.error)
      setPasswordUsuario((p) => (p ? { ...p, guardada: true, guardando: false } : p))
    } catch (err: any) {
      setPasswordUsuario((p) => (p ? { ...p, guardando: false, error: err?.message || 'No se pudo cambiar.' } : p))
    }
  }
  const [errorEdicionUsuario, setErrorEdicionUsuario] = useState('')

  function abrirEdicionUsuario(u: any) {
    const vendedor = vendedoresAdmin.find((v) => v.id === u.uid)
    const w = String(u.whatsapp || vendedor?.whatsapp || '')
    // País del número: el guardado, o el que dice su código (54 = Argentina).
    const whatsappPais = vendedor?.whatsappPais === 'AR' || u.whatsappPais === 'AR' || (/^54/.test(w) && w.length >= 12) ? 'AR' : 'BO'
    setErrorEdicionUsuario('')
    setEdicionUsuario({
      uid: u.uid,
      email: u.email || '',
      nombre: u.nombre || '',
      whatsapp: whatsappPais === 'AR' ? w.replace(/^549?/, '') : w.startsWith('591') ? w.slice(3) : w,
      whatsappPais,
      nombreNegocio: vendedor?.nombreNegocio || '',
      tieneTienda: !!vendedor,
    })
  }

  async function guardarEdicionUsuario(e: React.FormEvent) {
    e.preventDefault()
    if (!edicionUsuario) return
    setGuardandoUsuario(true)
    setErrorEdicionUsuario('')
    try {
      const { uid, tieneTienda, ...datos } = edicionUsuario
      const d = await fetch(`/api/admin/usuarios/${uid}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'editar', ...datos }),
      }).then((r) => r.json())
      if (d.error) throw new Error(d.error)
      setEdicionUsuario(null)
      cargarUsuarios()
      cargarVendedoresAdmin()
    } catch (err: any) {
      setErrorEdicionUsuario(err?.message || 'No se pudo guardar.')
    } finally {
      setGuardandoUsuario(false)
    }
  }
  async function cargarProductosComo(uid: string) {
    if (!uid) return
    if (!confirm('Vas a entrar a la cuenta de este vendedor en esta pestaña para cargarle la tienda y los productos (quedan marcados como "cargado por admin"). Si tenías tu propia sesión abierta en el sitio, se cierra. ¿Seguir?')) return
    try {
      await entrarComoUsuario(uid, password)
    } catch (err: any) {
      alert(err?.message || 'No se pudo entrar como ese usuario.')
    }
  }

  // Link nuevo para elegir contraseña (el anterior vence a la hora) y
  // WhatsApp con el mensaje de acceso.
  async function enviarAccesoUsuario(u: any) {
    const ventana = window.open('', '_blank')
    try {
      const d = await fetch(`/api/admin/usuarios/${u.uid}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'link' }),
      }).then((r) => r.json())
      if (d.error) throw new Error(d.error)
      const vendedor = vendedoresAdmin.find((v) => v.id === u.uid)
      const texto = mensajeAcceso({ nombre: u.nombre, negocio: vendedor?.nombreNegocio, email: u.email, link: d.link })
      const numero = String(u.whatsapp || vendedor?.whatsapp || '').replace(/\D/g, '')
      const url = numero ? `https://wa.me/${numero}?text=${encodeURIComponent(texto)}` : `https://wa.me/?text=${encodeURIComponent(texto)}`
      if (ventana) ventana.location.href = url
      else abrirWhatsapp(numero, texto)
    } catch (err: any) {
      ventana?.close()
      alert(err?.message || 'No se pudo generar el link.')
    }
  }

  function eliminarUsuario(uid: string) {
    if (!confirm('¿Eliminar esta cuenta definitivamente? El usuario no va a poder volver a entrar con este login. Esta acción no se puede deshacer.')) return
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarUsuarios())
  }

  function cambiarEstadoProducto(id: string, estado: 'activo' | 'pendiente' | 'rechazado' | 'oculto') {
    fetch(`/api/productos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => cargarProductos(password))
  }

  function cambiarEstadoPedido(id: string, estado: 'pendiente_pago' | 'pagado' | 'en_preparacion' | 'en_entrega' | 'entregado' | 'cancelado') {
    fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => entrar(password))
  }

  // La moto saca una foto del producto entregado (en la puerta, o en
  // manos de quien lo recibió) al marcar el pedido como entregado — es
  // más simple que pedir una firma física, y ya alcanza como
  // comprobante de que el reparto se hizo bien.
  async function marcarEntregadoConFoto(id: string, file: File) {
    setSubiendoFotoEntregaId(id)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const resSubida = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const dataSubida = await resSubida.json()
      if (dataSubida.error) throw new Error(dataSubida.error)

      await fetch(`/api/pedidos/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ estado: 'entregado', fotoEntregaUrl: dataSubida.url }),
      })
      entrar(password)
    } catch (e: any) {
      alert('No se pudo subir la foto: ' + e.message)
    } finally {
      setSubiendoFotoEntregaId(null)
    }
  }

  function confirmarPago(id: string) {
    cambiarEstadoPedido(id, 'pagado')
  }

  function pagarAlVendedor(id: string, medio: 'efectivo' | 'qr') {
    fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ pagoVendedorMedio: medio }),
    }).then(() => entrar(password))
  }

  function eliminarPedido(id: string) {
    if (!confirm('¿Eliminar este pedido? Esta acción no se puede deshacer.')) return
    fetch(`/api/pedidos/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => entrar(password))
  }

  // Mismo endpoint que usan los vendedores en /vender, pero acá nos
  // autenticamos con la contraseña de admin en vez de un login de
  // Firebase (este panel no usa ese sistema de cuentas).
  async function subirImagenProfesional(file: File | null) {
    if (!file) return
    setSubiendoImagen(true)
    setErrorForm('')
    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setImagenUrl(data.url)
    } catch (e: any) {
      setErrorForm('Error subiendo la imagen: ' + e.message)
    } finally {
      setSubiendoImagen(false)
    }
  }

  // Lee el CV (PDF o foto/escaneo) que subís desde acá, y precarga
  // nombre/especialidad/experiencia/descripción con lo que propone la
  // IA — vos los revisás y corregís en el formulario de siempre antes de
  // tocar "Publicar profesional" / "Guardar cambios", igual que con
  // cualquier otro dato que cargás a mano.
  // Lista de servicios concretos del profesional (ej: "Instalación de
  // grifería") — misma mecánica que en /publicar-servicio y /mi-perfil,
  // hasta 6 items.
  function agregarServicio() {
    const texto = nuevoServicio.trim()
    if (!texto || servicios.length >= 6) return
    if (servicios.some((s) => s.toLowerCase() === texto.toLowerCase())) {
      setNuevoServicio('')
      return
    }
    setServicios((s) => [...s, texto.slice(0, 80)])
    setNuevoServicio('')
  }

  function quitarServicio(i: number) {
    setServicios((s) => s.filter((_, idx) => idx !== i))
  }

  async function mejorarPuestoConIAAdmin(p: PuestoBorrador) {
    const res = await fetch('/api/profesionales/mejorar-puesto', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ cargo: p.cargo, empresa: p.empresa, texto: p.logrosTexto, especialidad }),
    })
    const data = await res.json()
    if (data.error) throw new Error(data.error)
    return data as { logros: string[]; stack: string[] }
  }

  async function leerCVAdmin(file: File | null) {
    if (!file) return
    setLeyendoCVAdmin(true)
    setErrorForm('')
    setRubroSugeridoCV(null)
    try {
      const { texto } = await extraerTextoDeArchivo(file)
      if (!texto || texto.trim().length < 30) {
        throw new Error('No pudimos leer suficiente texto de ese archivo. Probá con un PDF con texto real o una foto más clara y derecha.')
      }
      const res = await fetch('/api/profesionales/extraer-cv', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ texto }),
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      const datos = data.datos
      if (datos.nombre) setNombre(datos.nombre)
      if (datos.especialidad) setEspecialidad(datos.especialidad)
      if (datos.experiencia) setExperiencia(datos.experiencia)
      if (datos.descripcion) setDescripcion(datos.descripcion)
      if (datos.dondeTrabaja) setDondeTrabaja(datos.dondeTrabaja)
      if (datos.educacion) setEducacion(datos.educacion)
      if (datos.direccion) setDireccion(datos.direccion)
      if (datos.email) setEmailProfesional(datos.email)
      if (datos.servicios && datos.servicios.length > 0) setServicios(datos.servicios)
      if (datos.historialLaboral && datos.historialLaboral.length > 0) setHistorialCV(aBorradores(datos.historialLaboral))
      if (datos.idiomas && datos.idiomas.length > 0) setIdiomasCV(datos.idiomas)

      // El teléfono del CV puede traer código de país, espacios o
      // guiones — lo dejamos solo en dígitos y, si trae el 591 adelante,
      // se lo sacamos porque el campo espera el número local (igual que
      // el resto del formulario).
      if (datos.telefono && !whatsapp.trim()) {
        let digitos = String(datos.telefono).replace(/\D/g, '')
        if (digitos.startsWith('591') && digitos.length > 8) digitos = digitos.slice(3)
        if (digitos) setWhatsapp(digitos)
      }

      // Acá sí aplicamos directo la categoría/rubro sugeridos (a
      // diferencia de /mi-perfil, acá quien revisa y publica es el
      // admin, así que no hace falta el paso extra de "avisale al
      // admin" — de última lo corrige él mismo antes de publicar).
      if (datos.rubroSugerido) {
        setRubroSugeridoCV(datos.rubroSugerido)
        const encontrado = buscarRubro(datos.rubroSugerido)
        if (encontrado) {
          setCategoriaSel(encontrado.categoriaId)
          setRubro(encontrado.id)
        }
      }
    } catch (e: any) {
      setErrorForm(e?.message || 'No se pudo leer el CV.')
    } finally {
      setLeyendoCVAdmin(false)
    }
  }

  async function publicarProfesional(e: React.FormEvent) {
    e.preventDefault()
    setErrorForm('')
    if (!nombre.trim() || !whatsapp.trim()) {
      setErrorForm('Completá al menos el nombre y el WhatsApp.')
      return
    }
    setPublicando(true)
    try {
      const datos = {
        nombre, rubro, especialidad, descripcion, dondeTrabaja, educacion, servicios, zona, direccion,
        lat: lat || null, lng: lng || null,
        whatsapp, whatsappPais: buscarCiudad(ciudadPf).pais, ciudad: ciudadPf,
        instagram: '', redes: redesPf.filter((r) => r.trim()), reservas: reservasPf, linkVideollamada: linkVideoPf,
        email: emailProfesional, icono, plan, imagenUrl,
        precio: precio || null,
        experiencia,
        historialLaboral: deBorradores(historialCV),
        idiomas: idiomasCV,
        cvPublico,
        // La agenda (Premium) también se guarda con "Guardar cambios".
        ...(profesionalEditandoId && plan === 'premium' ? { horarioTurnos: { bloques: bloquesConPendienteAdmin() } } : {}),
      }
      const editando = !!profesionalEditandoId
      const res = await fetch(
        editando ? `/api/profesionales/${profesionalEditandoId}` : '/api/profesionales',
        {
          method: editando ? 'PATCH' : 'POST',
          headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
          body: JSON.stringify(datos),
        }
      )
      const data = await res.json()
      if (data.error) {
        setErrorForm(data.error)
        return
      }
      setNombre(''); setDescripcion(''); setServicios([]); setDondeTrabaja(''); setZona(''); setDireccion(''); setLat(''); setLng(''); setWhatsapp('')
      setImagenUrl(''); setPrecio(''); setExperiencia(''); setInstagram(''); setEmailProfesional(''); setEspecialidad(''); setRubroSugeridoCV(null); setEducacion('')
      setHistorialCV([]); setIdiomasCV([]); setCvPublico(true)
      setRedesPf(['']); setReservasPf({ consultorio: false, videollamada: false }); setLinkVideoPf('')
      setProfesionalEditandoId(null)
      setVistaServ('publicados')
      cargarProfesionales()
    } finally {
      setPublicando(false)
    }
  }

  // Carga los datos de un profesional ya existente en el mismo
  // formulario de arriba (que pasa a modo "edición"), para poder
  // corregir cualquier dato sin tener que borrarlo y volver a cargarlo.
  function abrirEditarProfesional(p: any) {
    setProfesionalEditandoId(p.id)
    setVistaServ('form')
    window.scrollTo({ top: 0 })
    setNombre(p.nombre || '')
    const rubroInfo = buscarRubro(p.rubro)
    setCategoriaSel(rubroInfo?.categoriaId || categorias[0]?.id || '')
    setRubro(p.rubro || '')
    setEspecialidad(p.especialidad || '')
    setDescripcion(p.descripcion || '')
    setServicios(p.servicios || [])
    setDondeTrabaja(p.dondeTrabaja || '')
    setEducacion(p.educacion || '')
    setZona(p.zona || '')
    setCiudadPf(ciudadDe(p))
    setDireccion(p.direccion || '')
    setLat(p.lat != null ? String(p.lat) : '')
    setLng(p.lng != null ? String(p.lng) : '')
    setWhatsapp(p.whatsapp || '')
    setInstagram(p.instagram || '')
    const redesGuardadas = [...(Array.isArray(p.redes) ? p.redes : []), ...(p.instagram ? [p.instagram] : [])].slice(0, 5)
    setRedesPf(redesGuardadas.length ? redesGuardadas : [''])
    setReservasPf(reservasDe(p))
    setLinkVideoPf(p.linkVideollamada || '')
    setEmailProfesional(p.email || '')
    setIcono(p.icono || ICONOS_SERVICIO[0])
    setImagenUrl(p.imagenUrl || '')
    setPrecio(p.precio != null ? String(p.precio) : '')
    setExperiencia(p.experiencia || '')
    setHistorialCV(aBorradores(p.historialLaboral))
    setIdiomasCV(p.idiomas || [])
    setCvPublico(p.cvPublico !== false)
    setPlan(p.plan === 'premium' ? 'premium' : 'basico')
    setEditHorarioBloques(p.horarioTurnos?.bloques || [])
    setErrorForm('')
    if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function cancelarEdicionProfesional() {
    setProfesionalEditandoId(null)
    setVistaServ('publicados')
    setNombre(''); setDescripcion(''); setZona(''); setDireccion(''); setLat(''); setLng(''); setWhatsapp('')
    setImagenUrl(''); setPrecio(''); setExperiencia(''); setInstagram(''); setEmailProfesional(''); setEspecialidad(''); setRubroSugeridoCV(null)
    setCiudadPf('potosi')
    setEditHorarioBloques([]); setEditNuevoBloqueDias([]); setEditNuevoBloqueTodoElDia(false)
    setHistorialCV([]); setIdiomasCV([]); setCvPublico(true)
    setRedesPf(['']); setReservasPf({ consultorio: false, videollamada: false }); setLinkVideoPf('')
    setErrorForm('')
  }

  function toggleDiaNuevoBloqueAdmin(diaId: number) {
    setEditNuevoBloqueDias((dias) => (dias.includes(diaId) ? dias.filter((d) => d !== diaId) : [...dias, diaId].sort()))
  }

  // Los bloques ya agregados + el que está a medio cargar (días elegidos
  // pero sin tocar "+ Agregar bloque"), para no perderlo al guardar.
  function bloquesConPendienteAdmin(): BloqueHorario[] {
    if (editNuevoBloqueDias.length === 0) return editHorarioBloques
    const desde = editNuevoBloqueTodoElDia ? '00:00' : editNuevoBloqueDesde
    const hasta = editNuevoBloqueTodoElDia ? '23:30' : editNuevoBloqueHasta
    if (hasta <= desde) return editHorarioBloques
    return [...editHorarioBloques, { id: `b${Date.now()}`, dias: editNuevoBloqueDias, desde, hasta, intervaloMin: editNuevoBloqueIntervalo }]
  }

  function agregarBloqueAdmin() {
    if (editNuevoBloqueDias.length === 0) return
    const desde = editNuevoBloqueTodoElDia ? '00:00' : editNuevoBloqueDesde
    const hasta = editNuevoBloqueTodoElDia ? '23:30' : editNuevoBloqueHasta
    if (hasta <= desde) return
    const nuevo: BloqueHorario = { id: `b${Date.now()}`, dias: editNuevoBloqueDias, desde, hasta, intervaloMin: editNuevoBloqueIntervalo }
    setEditHorarioBloques((b) => [...b, nuevo])
    setEditNuevoBloqueDias([])
    setEditNuevoBloqueTodoElDia(false)
  }

  function quitarBloqueAdmin(id: string) {
    setEditHorarioBloques((b) => b.filter((x) => x.id !== id))
  }

  async function guardarHorarioAdmin() {
    if (!profesionalEditandoId) return
    setGuardandoHorarioAdmin(true)
    setHorarioAdminGuardado(false)
    try {
      const res = await fetch(`/api/profesionales/${profesionalEditandoId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ horarioTurnos: { bloques: bloquesConPendienteAdmin() } }),
      })
      const data = await res.json()
      if (data.error) { setErrorForm(data.error); return }
      setEditHorarioBloques(bloquesConPendienteAdmin()); setEditNuevoBloqueDias([]); setEditNuevoBloqueTodoElDia(false)
      setHorarioAdminGuardado(true)
      cargarProfesionales()
    } finally {
      setGuardandoHorarioAdmin(false)
    }
  }

  function borrarProfesional(id: string, nombre?: string) {
    if (!confirm(`¿Borrar ${nombre || 'este profesional'}? No se puede deshacer.`)) return
    fetch(`/api/profesionales/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarProfesionales())
  }

  async function crearCategoria(e: React.FormEvent) {
    e.preventDefault()
    if (!nuevaCategoriaLabel.trim()) return
    setGuardandoCategoria(true)
    setErrorCategorias('')
    try {
      const res = await fetch('/api/categorias', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_categoria', label: nuevaCategoriaLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategorias(data.error); return }
      setNuevaCategoriaLabel('')
      recargarCategorias()
    } finally {
      setGuardandoCategoria(false)
    }
  }

  async function crearRubro(categoriaId: string) {
    if (!nuevoRubroLabel.trim()) return
    setGuardandoRubro(true)
    setErrorCategorias('')
    try {
      const res = await fetch('/api/categorias', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_rubro', categoriaId, label: nuevoRubroLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategorias(data.error); return }
      setNuevoRubroLabel('')
      setCategoriaAbierta(null)
      recargarCategorias()
    } finally {
      setGuardandoRubro(false)
    }
  }

  async function moverRubro(rubroId: string, categoriaId: string) {
    setErrorCategorias('')
    const res = await fetch('/api/categorias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'mover_rubro', rubroId, categoriaId }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategorias(data.error); return }
    recargarCategorias()
  }

  async function renombrarCategoria(categoriaId: string) {
    if (!nuevoNombreCategoria.trim()) return
    setErrorCategorias('')
    const res = await fetch('/api/categorias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'renombrar_categoria', categoriaId, label: nuevoNombreCategoria.trim() }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategorias(data.error); return }
    setRenombrandoCategoriaId(null)
    setNuevoNombreCategoria('')
    recargarCategorias()
  }

  async function crearCategoriaProducto(e: React.FormEvent) {
    e.preventDefault()
    if (!nuevaCategoriaProductoLabel.trim()) return
    setGuardandoCategoriaProducto(true)
    setErrorCategoriasProductos('')
    try {
      const res = await fetch('/api/categorias-productos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_categoria', label: nuevaCategoriaProductoLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategoriasProductos(data.error); return }
      setNuevaCategoriaProductoLabel('')
      recargarCategoriasProductos()
    } finally {
      setGuardandoCategoriaProducto(false)
    }
  }

  async function crearRubroProducto(categoriaId: string) {
    if (!nuevoRubroProductoLabel.trim()) return
    setGuardandoRubroProducto(true)
    setErrorCategoriasProductos('')
    try {
      const res = await fetch('/api/categorias-productos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_rubro', categoriaId, label: nuevoRubroProductoLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategoriasProductos(data.error); return }
      setNuevoRubroProductoLabel('')
      setCategoriaProductoAbierta(null)
      recargarCategoriasProductos()
    } finally {
      setGuardandoRubroProducto(false)
    }
  }

  async function moverRubroProducto(rubroId: string, categoriaId: string) {
    setErrorCategoriasProductos('')
    const res = await fetch('/api/categorias-productos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'mover_rubro', rubroId, categoriaId }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategoriasProductos(data.error); return }
    recargarCategoriasProductos()
  }

  async function renombrarCategoriaProducto(categoriaId: string) {
    if (!nuevoNombreCategoriaProducto.trim()) return
    setErrorCategoriasProductos('')
    const res = await fetch('/api/categorias-productos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'renombrar_categoria', categoriaId, label: nuevoNombreCategoriaProducto.trim() }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategoriasProductos(data.error); return }
    setRenombrandoCategoriaProductoId(null)
    setNuevoNombreCategoriaProducto('')
    recargarCategoriasProductos()
  }

  function cambiarEstadoProfesional(
    id: string,
    estado: 'aprobado' | 'rechazado' | 'info_solicitada' | 'pendiente_revision',
    notaAdmin?: string
  ) {
    fetch(`/api/profesionales/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify(notaAdmin !== undefined ? { estado, notaAdmin } : { estado }),
    }).then(() => cargarProfesionales())
  }

  // Invitaciones por WhatsApp: en los profesionales ya cargados se guarda
  // en su documento (invitadoEn / invitaciones); en los avisos pegados de
  // WhatsApp que todavía no se importaron, en este navegador, por número.
  function soloNumero(t: string) {
    return String(t || '').replace(/\D/g, '').slice(-8)
  }
  const [invitadosLocal, setInvitadosLocal] = useState<Record<string, string>>({})
  const [filtrosPros, setFiltrosPros] = useState<Filtros>(FILTROS_INICIALES)
  const [filtrosAnuncios, setFiltrosAnuncios] = useState<Filtros>(FILTROS_INICIALES)
  const [verHistorialAnuncios, setVerHistorialAnuncios] = useState(false)
  const [verPublicacionFacebook, setVerPublicacionFacebook] = useState(false)
  const [priorizandoAnunciosIA, setPriorizandoAnunciosIA] = useState(false)
  const [errorPriorizarAnunciosIA, setErrorPriorizarAnunciosIA] = useState('')
  useEffect(() => {
    try { setInvitadosLocal(JSON.parse(localStorage.getItem('clasiclick_invitados') || '{}')) } catch {}
  }, [])
  function marcarInvitadoLocal(telefono: string) {
    const clave = soloNumero(telefono)
    if (!clave) return
    setInvitadosLocal((prev) => {
      const nuevo = { ...prev, [clave]: new Date().toISOString() }
      try { localStorage.setItem('clasiclick_invitados', JSON.stringify(nuevo)) } catch {}
      return nuevo
    })
  }
  function invitarProfesional(p: any) {
    marcarInvitadoLocal(p.whatsapp)
    // Se marca al toque en pantalla y queda guardado en el perfil.
    setProfesionales((lista) => lista.map((x) => (x.id === p.id ? { ...x, invitadoEn: new Date().toISOString(), invitaciones: (x.invitaciones || 0) + 1, estado: 'info_solicitada' } : x)))
    fetch(`/api/profesionales/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ registrarInvitacion: true, estado: 'info_solicitada', notaAdmin: p.notaAdmin || 'Se le mandó la invitación por WhatsApp.' }),
    }).then(() => cargarProfesionales())
  }
  function invitarAnuncio(a: any) {
    marcarInvitadoLocal(a.whatsapp || a.telefonoOriginal)
    setAnuncios((lista) => lista.map((x) => (x.id === a.id ? { ...x, invitadoEn: new Date().toISOString(), invitaciones: (x.invitaciones || 0) + 1, estado: 'info_solicitada' } : x)))
    fetch(`/api/anuncios/${a.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ registrarInvitacion: true, estado: 'info_solicitada', notaAdmin: a.notaAdmin || 'Se le mandó la invitación por WhatsApp.' }),
    }).then(() => cargarAnuncios())
  }

  async function priorizarAnunciosConIA() {
    setPriorizandoAnunciosIA(true)
    setErrorPriorizarAnunciosIA('')
    try {
      const res = await fetch('/api/admin/anuncios/priorizar', { method: 'POST', headers: { 'x-admin-password': password } })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      const porId = new Map<string, any>((data.prioridades || []).map((pr: any) => [pr.id, pr]))
      setAnuncios((lista) => lista.map((a) => (porId.has(a.id) ? { ...a, prioridadInvitacionIA: porId.get(a.id) } : a)))
      setFiltrosAnuncios((f) => ({ ...f, orden: 'ia' }))
    } catch (e: any) {
      setErrorPriorizarAnunciosIA(e?.message || 'No se pudo priorizar con IA.')
    } finally {
      setPriorizandoAnunciosIA(false)
    }
  }

  // Filtros de las listas largas (ver components/admin/FiltrosLista.tsx).
  const rubroLabelAnuncio = (id?: string) => (id ? buscarRubro(id)?.label : undefined)
  function rubrosDe(lista: any[]) {
    const ids = Array.from(new Set(lista.map((x) => x.rubro).filter(Boolean))) as string[]
    return ids.map((id) => ({ id, label: buscarRubro(id)?.label || id })).sort((a, b) => a.label.localeCompare(b.label))
  }
  function filtrarPros(lista: any[]) {
    return aplicarFiltros(lista, filtrosPros, {
      texto: (p) => [p.nombre, p.especialidad, p.descripcion, p.whatsapp, p.zona, p.email, buscarRubro(p.rubro)?.label].filter(Boolean).join(' '),
      rubro: (p) => p.rubro,
      fecha: (p) => p.createdAt,
      invitado: (p) => !!(p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)]),
      puntaje: (p) => p.prioridadInvitacionIA?.puntaje,
    })
  }
  function filtrarAnuncios(lista: any[]) {
    return aplicarFiltros(lista, filtrosAnuncios, {
      texto: (a) => [a.titulo, a.descripcion, a.whatsapp, a.telefonoOriginal, buscarRubro(a.rubro)?.label].filter(Boolean).join(' '),
      rubro: (a) => a.rubro,
      fecha: (a) => a.createdAt,
      invitado: (a) => !!(a.invitadoEn || invitadosLocal[soloNumero(a.whatsapp || a.telefonoOriginal)]),
      puntaje: (a) => a.prioridadInvitacionIA?.puntaje,
    })
  }

  function fechaInvitacion(iso?: string) {
    return iso ? new Date(iso).toLocaleString('es-BO', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }) : ''
  }

  // Confirma que el pago de la membresía Premium realmente llegó (lo
  // revisás vos a mano contra el banco/QR, como con los pedidos de
  // productos) — activa Premium y extiende la vigencia 30 días desde
  // hoy, o desde la vigencia actual si todavía no había vencido.
  function confirmarPagoPremium(p: { id: string; planVigenciaHasta?: string | null }) {
    fetch(`/api/profesionales/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({
        plan: 'premium',
        planEstadoPago: 'ninguno',
        planVigenciaHasta: calcularNuevaVigencia(p.planVigenciaHasta),
      }),
    }).then(() => cargarProfesionales())
  }

  function rechazarPagoPremium(id: string) {
    fetch(`/api/profesionales/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ planEstadoPago: 'ninguno' }),
    }).then(() => cargarProfesionales())
  }

  const [vendedoresAdmin, setVendedoresAdmin] = useState<any[]>([])

  function cargarVendedoresAdmin(pw?: string) {
    fetch('/api/admin/vendedores', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setVendedoresAdmin(data.vendedores || []))
  }

  function confirmarPagoPremiumVendedor(v: { id: string; planVigenciaHasta?: string | null }) {
    fetch(`/api/vendedores/${v.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({
        plan: 'premium',
        planEstadoPago: 'ninguno',
        planVigenciaHasta: calcularNuevaVigencia(v.planVigenciaHasta),
      }),
    }).then(() => cargarVendedoresAdmin())
  }

  function rechazarPagoPremiumVendedor(id: string) {
    fetch(`/api/vendedores/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ planEstadoPago: 'ninguno' }),
    }).then(() => cargarVendedoresAdmin())
  }

  // Al abrir una sección, cargar lo que necesita (antes lo hacía el
  // botón de la pestaña).
  useEffect(() => {
    if (!autenticado) return
    if ((tab === 'productos' || tab === 'usuarios') && vendedoresAdmin.length === 0) cargarVendedoresAdmin()
    if (tab === 'usuarios' && usuarios.length === 0) cargarUsuarios()
    if (tab === 'usuarios' && administradores === null) cargarAdministradores()
    if (tab === 'metricas' && !metricas) cargarMetricas()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab, autenticado])

  if (!autenticado) {
    return (
      <div className="max-w-[360px] mx-auto px-5 py-20">
        <div className="font-display text-xl font-bold text-ink mb-4">Panel de administración</div>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Contraseña de administrador"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
          onKeyDown={(e) => e.key === 'Enter' && entrar(password)}
        />
        <button
          onClick={() => entrar(password)}
          disabled={cargando}
          className="w-full py-2.5 rounded-lg border-none bg-ink text-white font-body text-sm font-semibold"
        >
          {cargando ? 'Entrando...' : 'Entrar'}
        </button>
        {error && <div className="font-body text-xs text-maroon mt-3">{error}</div>}
      </div>
    )
  }


  async function cargarSolicitudes() {
    setCargandoSolicitudes(true)
    try {
      const res = await fetch('/api/solicitud-ayuda', {
        headers: { 'x-admin-password': password }
      })
      const data = await res.json()
      setSolicitudes(data.solicitudes || [])
    } finally { setCargandoSolicitudes(false) }
  }

  async function marcarSolicitud(id: string, estado: string) {
    await fetch('/api/solicitud-ayuda', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ id, estado }),
    })
    setSolicitudes(prev => prev.map(s => s.id === id ? { ...s, estado } : s))
  }


  const pedidosPorRevisar = pedidos.filter((p) => p.estado === 'informado_pago').length
  const badgesAdmin: Record<string, number | undefined> = {
    pedidos: pedidosPorRevisar || undefined,
    servicios: profesionales.filter((p) => p.estado === 'pendiente_revision').length || undefined,
    anuncios: anuncios.filter((a) => a.estado === 'pendiente_revision').length || undefined,
  }

  return (
    <div className="max-w-7xl mx-auto px-5 py-6">
      <div className="hidden md:flex items-center justify-between gap-4 mb-5 pb-4 border-b border-line">
        <div>
          <div className="font-display text-xl font-bold text-ink">Panel de administración</div>
          <div className="font-body text-[13px] text-inksoft">Clasi Click</div>
        </div>
        <a href="/" className="font-body text-sm text-inksoft underline">Ir al sitio</a>
      </div>

      <AlarmaPedidos
        password={password}
        pedidosIniciales={pedidos}
        onCambios={(cambiados) =>
          setPedidos((prev) => {
            const porId = new Map(prev.map((p: any) => [p.id, p]))
            for (const c of cambiados) porId.set(c.id, { ...(porId.get(c.id) || {}), ...c })
            return Array.from(porId.values()).sort((a: any, b: any) => (b.createdAt || '').localeCompare(a.createdAt || ''))
          })
        }
      />


      <MenuCelularSecciones
        items={SECCIONES_ADMIN}
        visible={!seccionAdmin}
        irA={irASeccionAdmin}
        badges={badgesAdmin}
        encabezado={
          <div className="bg-maroon text-white px-5 py-5 mb-1">
            <div className="font-display text-lg font-bold">Panel de administración</div>
            <div className="font-body text-sm text-white/80">Clasi Click · elegí una sección</div>
          </div>
        }
      />

      <div className="md:flex md:gap-6 md:items-start">
        <SidebarSecciones items={SECCIONES_ADMIN} activa={tab} irA={irASeccionAdmin} badges={badgesAdmin} />
        <main className={`flex-1 min-w-0 max-w-[900px] ${seccionAdmin ? '' : 'hidden md:block'}`}>
          <VolverCelularSecciones items={SECCIONES_ADMIN} seccion={seccionAdmin} volver={volverAdmin} />

      {tab === 'inicio' && (
        <div>
          <AdminCiudades password={password} />
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Pedidos</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.pedidosTotal}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">En proceso</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.pedidosPagados}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Productos activos</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.productosActivos}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Premium</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.productosPremium}</div>
        </div>
      </div>

      <div className="bg-panel border border-line rounded-xl p-4 mb-6">
        <div className="font-body text-sm font-semibold text-ink mb-1">Mi QR de cobro (pedidos con envío)</div>
        <div className="font-body text-[11px] text-inksoft mb-3">
          Cuando un comprador elige "envío" en el checkout, siempre paga a ESTE QR (nunca directo al vendedor) — recién se le libera la plata al vendedor cuando confirmás la entrega. Con "retiro en tienda" sí se paga al QR propio del vendedor.
        </div>
        <div className="flex items-start gap-4 flex-wrap">
          <div className="shrink-0">
            {qrPagoUrl ? (
              <img src={qrPagoUrl} alt="QR de cobro" className="w-28 h-28 object-cover rounded-lg border border-line" />
            ) : (
              <div className="w-28 h-28 rounded-lg border border-dashed border-line flex items-center justify-center font-body text-[10px] text-inksoft text-center px-2">
                Sin QR cargado
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirQrPago(e.target.files?.[0] || null)}
              disabled={subiendoQrPago}
              className="font-body text-[10px] mt-1.5 w-28"
            />
            {subiendoQrPago && <div className="font-body text-[10px] text-maroon mt-1">Subiendo...</div>}
          </div>
          <div className="flex-1 min-w-[220px]">
            <input
              value={cbuPago}
              onChange={(e) => setCbuPago(e.target.value)}
              placeholder="Cuenta / CBU (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={bancoPago}
              onChange={(e) => setBancoPago(e.target.value)}
              placeholder="Banco (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={titularPago}
              onChange={(e) => setTitularPago(e.target.value)}
              placeholder="Titular de la cuenta (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={whatsappPago}
              onChange={(e) => setWhatsappPago(e.target.value)}
              placeholder="Tu WhatsApp para recibir comprobantes (ej: 59171234567)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <div className="font-body text-[10px] text-inksoft mb-2 -mt-1">
              A este número te va a llegar el comprobante de los pedidos con envío (esos siempre se pagan a tu cuenta, nunca directo al vendedor).
            </div>
            <button
              onClick={guardarConfigPagos}
              disabled={guardandoConfigPago}
              className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-60"
            >
              {guardandoConfigPago ? 'Guardando...' : 'Guardar'}
            </button>
            {configPagoGuardada && <span className="font-body text-[11px] text-teal ml-2">Guardado ✓</span>}
          </div>
        </div>
      </div>

        </div>
      )}


      {tab === 'cupones' && <AdminCupones password={password} />}
      {tab === 'marketing' && <MarketingConPestanas password={password} />}
      {tab === 'captacion' && <AdminCaptacion password={password} />}
      {tab === 'finanzas' && <AdminFinanzas password={password} />}
      {tab === 'analitica' && (
        <>
          <AdminRecuperacion password={password} />
          <AdminAnalitica password={password} />
        </>
      )}

      {tab === 'pedidos' && (
        <div>
          <AdminFueraHorario password={password} />
          {pedidos.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay pedidos.</div>}
          {pedidos.map((p) => {
            const estado = ESTADOS_LABEL[p.estado] || { texto: p.estado, color: 'text-inksoft' }
            return (
              <div key={p.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-body text-sm font-medium text-ink">Pedido #{p.id.slice(0, 6)}</div>
                    <div className="font-body text-xs font-semibold text-ink mt-0.5">
                      👤 {p.nombreComprador || 'Sin nombre cargado'}
                    </div>
                    <div className="font-body text-[11px] text-inksoft">{p.comprador || 'Sin email'}</div>
                    <div className="font-body text-[11px] text-inksoft mt-1">
                      🏪 {p.vendedorNombre || 'Clasi Click'}
                      {p.createdAt && ` · ${new Date(p.createdAt).toLocaleString('es-BO', { dateStyle: 'short', timeStyle: 'short' })}`}
                    </div>
                    <div className="font-body text-[11px] text-inksoft mt-1">
                      {p.metodoEntrega === 'retiro' ? '🏬 Retiro en tienda' : p.metodoEntrega === 'vendedor' ? '🚚 Envío del vendedor' : `🛵 ${p.zonaEntrega || 'Sin zona'}`} · {p.direccion ? `Entrega: ${p.direccion}` : 'Sin dirección'}
                      {p.entreCalles && ` (${p.entreCalles})`}
                      {p.referenciaAdicional && ` — ${p.referenciaAdicional}`}
                      {p.validacionZona?.coincide === false && (
                        <span className="ml-1 px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold" title={`Escribió “${p.validacionZona.escrita}” pero su ubicación queda en ${p.validacionZona.cercanaAlPunto || '?'}${p.validacionZona.distanciaKm != null ? ` (la zona escrita está a ${p.validacionZona.distanciaKm} km)` : ''}. Confirmá la dirección por WhatsApp.`}>⚠ zona dudosa: el mapa dice {p.validacionZona.cercanaAlPunto}</span>
                      )}
                      {p.validacionZona && !p.validacionZona.enLista && p.metodoEntrega === 'envio' && <span className="ml-1 px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700">🆕 zona nueva</span>}
                    </div>
                    <div className={`font-body text-xs font-semibold ${estado.color}`}>{estado.texto}</div>
                  </div>
                  {p.estado !== 'pagado' && p.estado !== 'en_preparacion' && p.estado !== 'en_entrega' && p.estado !== 'entregado' && p.estado !== 'cancelado' && (
                    <button
                      onClick={() => confirmarPago(p.id)}
                      className="px-3.5 py-2 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                    >
                      Confirmar pago
                    </button>
                  )}
                  {p.estado === 'pagado' && p.whatsappComprador && (
                    <a
                      href={`https://wa.me/${p.whatsappComprador.replace(/\D/g, '')}?text=${encodeURIComponent(`¡Felicitaciones ${p.nombreComprador || ''}! 🎉 Tu pedido #${p.id.slice(0, 6)} quedó confirmado. En cuanto esté listo te avisamos por acá.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 rounded-md border border-teal text-teal font-body text-xs font-semibold shrink-0"
                    >
                      🎉 Mandar felicitaciones
                    </a>
                  )}
                </div>

                {(p.reemplazadoPor || p.reemplazaA?.length > 0) && (
                  <div className="mt-2 font-body text-[11px] text-indigo-700">
                    {p.reemplazadoPor && <>↪ Anulado y rehecho como el pedido #{String(p.reemplazadoPor).slice(0, 6)} (el comprador cambió algo o aplicó un cupón en el pago).</>}
                    {p.reemplazaA?.length > 0 && <>↩ Rehace {p.reemplazaA.length === 1 ? 'el pedido' : 'los pedidos'} {p.reemplazaA.map((x: string) => `#${x.slice(0, 6)}`).join(', ')} (anulado{p.reemplazaA.length === 1 ? '' : 's'}): sus intentos de pago están acá abajo.</>}
                  </div>
                )}
                {p.comprobantesRechazados?.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-line">
                    <div className="font-body text-[11px] font-semibold text-ink mb-0.5">
                      🧾 Intentos de pago: {p.comprobantesRechazados.length + (p.comprobanteUrl ? 1 : 0)}
                      <span className="font-normal text-maroon"> · {p.comprobantesRechazados.length} rechazado{p.comprobantesRechazados.length === 1 ? '' : 's'} automáticamente</span>
                      {p.comprobanteUrl && <span className="font-normal text-teal"> · 1 enviado</span>}
                    </div>
                    {p.canceladoMotivo && <div className="font-body text-[11px] text-maroon mb-1.5">{p.canceladoMotivo}</div>}
                    <div className="font-body text-[10px] text-inksoft mb-1.5">En orden, del primero al último (tocá la imagen para verla en grande).</div>
                    <div className="flex flex-col gap-1.5">
                      {p.comprobantesRechazados.map((c: any, i: number) => (
                        <div key={i} className="flex items-center gap-2">
                          {c.url ? (
                            <a href={c.url} target="_blank" rel="noopener noreferrer" className="shrink-0">
                              <img src={c.url} alt={`Rechazado ${i + 1}`} className="w-10 h-10 rounded-md object-cover border border-maroon/40" />
                            </a>
                          ) : (
                            <div className="w-10 h-10 rounded-md bg-panelalt border border-line shrink-0" />
                          )}
                          <div className="font-body text-[11px] text-inksoft">
                            <b className="text-maroon">{i + 1}. ❌ Rechazado</b> — {c.motivo}
                            {typeof c.montoLeido === 'number' && <> · leído {bs(c.montoLeido, p.pais)}</>}
                            <span className="block text-[10px]">
                              {c.fecha && new Date(c.fecha).toLocaleString('es-BO')}
                              {c.pedidoId && c.pedidoId !== p.id && <> · en el pedido anterior #{String(c.pedidoId).slice(0, 6)} (lo rehízo al cambiar algo o aplicar un cupón)</>}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {p.comprobanteUrl && (
                  <div className="mt-3 pt-3 border-t border-line">
                    <div className="font-body text-[11px] text-inksoft mb-1.5">
                      {p.comprobantesRechazados?.length > 0 ? <b className="text-teal">{p.comprobantesRechazados.length + 1}. ✓ Comprobante final enviado por el comprador</b> : 'Comprobante enviado por el comprador'}
                      {p.informadoPagoAt && <span className="text-[10px]"> · {new Date(p.informadoPagoAt).toLocaleString('es-BO')}</span>}
                    </div>
                    <div className="flex items-start gap-2.5">
                      <a href={p.comprobanteUrl} target="_blank" rel="noopener noreferrer" className="shrink-0">
                        <img src={p.comprobanteUrl} alt="Comprobante" className="w-16 h-16 rounded-lg object-cover border border-line" />
                      </a>
                      <div className="flex-1 min-w-0">
                        {p.ocrPareceComprobante === false && (
                          <div className="font-body text-[11px] font-semibold text-maroon bg-maroonsoft border border-maroon rounded-md px-2 py-1 mb-1">
                            ⚠ La imagen no parece un comprobante de pago. Revisala antes de confirmar.
                          </div>
                        )}
                        {p.ocrCoincide === true && p.ocrPareceComprobante !== false && (
                          <div className="font-body text-[11px] text-teal mb-0.5">
                            ✓ Lectura automática: {bs(p.ocrMonto)} — coincide con el total
                          </div>
                        )}
                        {p.ocrCoincide === false && (
                          <div className="font-body text-[11px] text-maroon mb-0.5">
                            ⚠ Lectura automática: {bs(p.ocrMonto, p.pais)} — no coincide con {bs(p.total, p.pais)}. Revisá la imagen.
                          </div>
                        )}
                        {p.ocrCoincide == null && p.ocrPareceComprobante !== false && (
                          <div className="font-body text-[11px] text-inksoft mb-0.5">
                            No se pudo leer el monto automáticamente — revisá la imagen a mano.
                          </div>
                        )}
                        <a href={p.comprobanteUrl} target="_blank" rel="noopener noreferrer" className="font-body text-[11px] text-maroon underline">
                          Ver comprobante en grande
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-3 pt-3 border-t border-line flex flex-col gap-2">
                  {(p.items || []).map((it: any, i: number) => (
                    <div key={i} className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-md bg-panelalt flex items-center justify-center overflow-hidden shrink-0">
                        {(it.thumbUrl || it.imagenUrl) ? (
                          <img src={it.thumbUrl || it.imagenUrl} alt={it.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
                        ) : (
                          <span className="font-body text-[8px] text-inksoft">IMG</span>
                        )}
                      </div>
                      <div className="font-body text-xs text-ink flex-1 min-w-0 truncate">
                        {it.cantidad} × {it.nombre}
                        {(it.tallaElegida || it.colorElegida) && (
                          <span className="text-inksoft"> ({[it.tallaElegida, it.colorElegida].filter(Boolean).join(' · ')})</span>
                        )}
                      </div>
                      <div className="font-body text-xs text-inksoft shrink-0">{bs(it.precio * it.cantidad)}</div>
                    </div>
                  ))}
                  {p.esPrueba && (
                    <div className="font-body text-[11px] font-semibold text-indigo-700 text-right">🧪 Pedido de prueba</div>
                  )}
                  {p.cupon && (
                    <div className="font-body text-[11px] text-teal text-right">
                      🎟️ Cupón {p.cupon.codigo}
                      {p.cupon.descuentoProductos > 0 && ` · −${bs(p.cupon.descuentoProductos)} en productos`}
                      {p.cupon.descuentoEnvio > 0 && ` · −${bs(p.cupon.descuentoEnvio)} de envío`}
                      {' '}(lo absorbe Clasi Click)
                    </div>
                  )}
                  <div className="font-body text-xs font-semibold text-ink text-right">Total: {bs(p.total, p.pais)}{p.pais && p.pais !== 'BO' ? ` ${banderaDe(p.pais)}` : ''}</div>
                </div>

                {p.estado === 'verificando_stock' && (
                  <div className="mt-3">
                    {p.vendedorWhatsapp && (
                      <a
                        href={`https://wa.me/${p.vendedorWhatsapp}?text=${encodeURIComponent(
                          `Hola ${p.vendedorNombre}! Te escribo de Clasi Click — llegó un pedido nuevo (${p.items?.length || 0} producto(s), ${bs(p.total, p.pais)}). ¿Podés confirmarme si tenés stock disponible?`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block mb-2 px-2.5 py-1.5 rounded-md border border-teal text-teal font-body text-[11px] font-semibold"
                      >
                        💬 Contactar al vendedor para verificar stock
                      </a>
                    )}
                    <div className="flex flex-wrap gap-2">
                      <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'pendiente_pago')} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-[11px] font-semibold">Confirmar stock disponible</button>
                      <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Sin stock / cancelar</button>
                    </div>
                  </div>
                )}

                {p.metodoEntrega === 'envio' && ['pagado', 'en_preparacion', 'en_entrega', 'entregado'].includes(p.estado) && (
                  <div className="mt-3">
                    {p.pagoVendedorHecho ? (
                      <div className="font-body text-[11px] text-teal">
                        ✓ Pagado al vendedor por {p.pagoVendedorMedio === 'efectivo' ? 'efectivo' : 'QR'}{p.pagoVendedorAt && ` el ${new Date(p.pagoVendedorAt).toLocaleDateString('es-BO')}`}
                      </div>
                    ) : (
                      <div className="bg-panelalt border border-line rounded-lg p-2.5">
                        <div className="font-body text-[11px] text-inksoft mb-1.5">
                          Este pedido cobró por QR de la plataforma — todavía falta pagarle al vendedor su parte:
                        </div>
                        <div className="flex gap-2">
                          <button type="button" onClick={() => pagarAlVendedor(p.id, 'efectivo')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] font-semibold">Ya le pagué en efectivo</button>
                          <button type="button" onClick={() => pagarAlVendedor(p.id, 'qr')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] font-semibold">Ya le pagué por QR</button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {p.estado === 'pagado' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_preparacion')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">En preparación</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_entrega')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">En entrega</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'entregado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Entregado</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Cancelar</button>
                  </div>
                )}

                {p.estado === 'en_preparacion' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_entrega')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Enviar</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Cancelar</button>
                  </div>
                )}

                {p.estado === 'en_entrega' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'entregado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Marcar entregado</button>
                  </div>
                )}

                <div className="mt-3 pt-3 border-t border-line text-right">
                  <button
                    type="button"
                    onClick={() => eliminarPedido(p.id)}
                    className="font-body text-[11px] text-maroon underline"
                  >
                    Eliminar pedido
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {tab === 'productos' && (
        <div>
          {vendedoresAdmin.filter((v) => v.planEstadoPago === 'informado_pago').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-teal mb-3">
                💳 Pagos de membresía Premium de vendedores por confirmar ({vendedoresAdmin.filter((v) => v.planEstadoPago === 'informado_pago').length})
              </div>
              {vendedoresAdmin
                .filter((v) => v.planEstadoPago === 'informado_pago')
                .map((v) => (
                <div key={v.id} className="bg-panel border border-teal rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{v.nombreNegocio || v.email || v.id}</div>
                  <div className="font-body text-xs text-inksoft mb-3">
                    WhatsApp: {v.whatsapp || 'sin cargar'}
                    {v.planVigenciaHasta && new Date(v.planVigenciaHasta).getTime() > Date.now() && (
                      <> · Ya tiene Premium vigente hasta {new Date(v.planVigenciaHasta).toLocaleDateString('es-BO')} — confirmar esto se lo extiende 30 días más desde esa fecha</>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => confirmarPagoPremiumVendedor(v)}
                      className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                    >
                      Confirmar pago recibido
                    </button>
                    <button
                      onClick={() => rechazarPagoPremiumVendedor(v.id)}
                      className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                    >
                      No llegó / rechazar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <ProductosDeTienda
            password={password}
            productos={productos}
            tiendas={vendedoresAdmin}
            categorias={categoriasProductos}
            rubroLabel={(id) => nombreRubro(buscarRubroProducto(id)) || undefined}
            tiendaId={tiendaProductos}
            onTienda={(id) => { setTiendaProductos(id); if (id) setVendedorParaCargar(id) }}
            onCambio={() => cargarProductos()}
            onEntrarComo={(id) => cargarProductosComo(id)}
          />

          {!tiendaProductos && (
          <div className="bg-panel border border-indigo-200 rounded-xl p-3.5 mb-5">
            <div className="font-body text-sm font-semibold text-ink mb-1">➕ Publicar productos para un vendedor</div>
            <div className="font-body text-[11px] text-inksoft mb-2">
              Entrás a su cuenta y cargás como él (formulario o Excel); los productos quedan a su nombre y marcados “🛠️ cargado por admin”. ¿No tiene cuenta? Creala en la pestaña Usuarios.
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              <select
                value={vendedorParaCargar}
                onFocus={() => { if (usuarios.length === 0) cargarUsuarios() }}
                onChange={(e) => setVendedorParaCargar(e.target.value)}
                aria-label="Vendedor"
                className="flex-1 min-w-[200px] px-2 py-1.5 rounded-lg border border-line bg-panel font-body text-xs text-ink"
              >
                <option value="">{usuarios.length === 0 ? (cargandoUsuarios ? 'Cargando usuarios...' : 'Elegí el vendedor (tocá para cargar)') : 'Elegí el vendedor'}</option>
                {[...usuarios]
                  .filter((u) => !u.pausado)
                  .sort((a, b) => (b.productosCount || 0) - (a.productosCount || 0) || String(a.email).localeCompare(String(b.email)))
                  .map((u) => {
                    const tienda = vendedoresAdmin.find((v) => v.id === u.uid)?.nombreNegocio
                    return (
                      <option key={u.uid} value={u.uid}>
                        {tienda ? `${tienda} — ` : ''}{u.email || u.nombre || u.uid}{u.productosCount ? ` (${u.productosCount} productos)` : ''}
                      </option>
                    )
                  })}
              </select>
              <button
                type="button"
                onClick={() => cargarProductosComo(vendedorParaCargar)}
                disabled={!vendedorParaCargar}
                className="px-3 py-1.5 rounded-lg border-none bg-indigo-600 text-white font-body text-xs font-semibold disabled:opacity-50"
              >
                🛍️ Cargar productos como este vendedor
              </button>
            </div>
          </div>
          )}

          <BotWhatsapp password={password} />

          <EtiquetasBusquedaIA password={password} />

          <EdicionRapidaProductos
            password={password}
            productos={productosVista}
            categorias={categoriasProductos}
            rubroLabel={(id) => nombreRubro(buscarRubroProducto(id)) || undefined}
            onGuardado={() => cargarProductos()}
            vendedoresCuentas={vendedoresAdmin
              .map((v) => ({ id: v.id, nombre: v.nombreNegocio ? `${v.nombreNegocio}${v.email ? ` (${v.email})` : ''}` : v.email || v.id }))
              .sort((a, b) => a.nombre.localeCompare(b.nombre, 'es'))}
            onVendedorCreado={() => { cargarVendedoresAdmin(); cargarUsuarios() }}
          />

          <div className="font-body text-sm font-semibold text-ink mb-3">Moderación de productos{tiendaProductos ? ' (de la tienda elegida)' : ''}</div>
          {productosVista.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay productos.</div>}
          {[...productosVista]
            .sort((a, b) => {
              const orden: Record<string, number> = { alto: 0, medio: 1, bajo: 2 }
              const oa = orden[a.moderacionIA?.riesgo] ?? 3
              const ob = orden[b.moderacionIA?.riesgo] ?? 3
              return oa - ob
            })
            .map((p) => (
            <div key={p.id} className="bg-panel border border-line rounded-lg p-3.5 mb-3 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-panelalt flex items-center justify-center overflow-hidden shrink-0">
                {p.thumbUrl || p.imagenUrl ? <img src={p.thumbUrl || p.imagenUrl} alt={p.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" /> : <span className="font-body text-[10px] text-inksoft">IMG</span>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-body text-sm font-medium text-ink truncate">{p.nombre}</div>
                <div className="font-body text-xs text-inksoft">{ciudadDe(p) !== 'potosi' && `📍 ${buscarCiudad(ciudadDe(p)).nombre} · `}{p.vendedor || 'Vendedor'} · {labelPublicoProducto(p.publico)} · {nombreRubro(buscarRubroProducto(p.rubro)) || p.categoria || 'Sin rubro'} · Bs {Number(p.precio || 0).toLocaleString('es-BO')}</div>
                <div className="font-body text-[11px] text-inksoft mt-1">
                  Estado: {p.estado || 'activo'}
                  {p.cargadoPorAdmin && <span className="ml-2 inline-block bg-tealsoft text-teal border border-teal text-[10px] font-bold px-1.5 py-0.5 rounded-full">🛠️ Cargado por admin</span>}
                </div>
                <BadgeRiesgoIA moderacionIA={p.moderacionIA} />
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'activo')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Activo</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'pendiente')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Pendiente</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'oculto')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Ocultar</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'rechazado')} className="px-2 py-1 rounded-md border border-line font-body text-[11px] text-maroon">Rechazar</button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!confirm('¿Borrar este producto definitivamente?')) return
                      fetch(`/api/productos/${p.id}`, {
                        method: 'DELETE',
                        headers: { 'x-admin-password': password },
                      }).then(() => cargarProductos())
                    }}
                    className="px-2 py-1 rounded-md border border-line font-body text-[11px] text-maroon"
                  >
                    Borrar
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const nuevoNombre = prompt('Nuevo nombre', p.nombre || '')
                      if (nuevoNombre === null) return
                      const nuevoPrecio = prompt('Nuevo precio (Bs)', String(p.precio || ''))
                      if (nuevoPrecio === null) return
                      fetch(`/api/productos/${p.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
                        body: JSON.stringify({ nombre: nuevoNombre, precio: Number(nuevoPrecio) }),
                      }).then(() => cargarProductos())
                    }}
                    className="px-2 py-1 rounded-md border border-line font-body text-[11px]"
                  >
                    Editar
                  </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'servicios' && (
        <div>
          {(() => {
            const pendientes = profesionales.filter((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada').length + profesionales.filter((p) => p.planEstadoPago === 'informado_pago').length
            const publicados = profesionales.filter((p) => !p.estado || p.estado === 'aprobado').length
            const pestañas: { id: typeof vistaServ; label: string; badge?: number }[] = [
              { id: 'publicados', label: `📋 Publicados (${publicados})` },
              { id: 'pendientes', label: '⏳ Pendientes', badge: pendientes },
              { id: 'form', label: profesionalEditandoId ? `✏️ Editando: ${nombre || '...'}` : '➕ Nuevo' },
              { id: 'importar', label: '📥 Importar' },
            ]
            return (
              <div className="sticky top-0 z-20 -mx-1 px-1 py-2 mb-4 bg-bg/95 backdrop-blur flex gap-1.5 overflow-x-auto border-b border-line">
                {pestañas.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => setVistaServ(t.id)}
                    className={`shrink-0 px-3 py-1.5 rounded-full border font-body text-xs font-semibold whitespace-nowrap max-w-[260px] truncate ${vistaServ === t.id ? 'bg-ink text-white border-ink' : 'bg-panel text-ink border-line'}`}
                  >
                    {t.label}
                    {!!t.badge && <span className="ml-1.5 bg-maroon text-white rounded-full px-1.5 text-[10px]">{t.badge}</span>}
                  </button>
                ))}
              </div>
            )
          })()}
          <form onSubmit={publicarProfesional} className={`${vistaServ === 'form' ? '' : 'hidden '}bg-panel border border-line rounded-xl p-5 mb-8`}>
            <div className="flex items-center justify-between mb-3">
              <div className="font-body text-sm font-semibold text-ink">
                {profesionalEditandoId ? 'Editando profesional' : 'Nuevo profesional'}
              </div>
              {profesionalEditandoId && (
                <button
                  type="button"
                  onClick={cancelarEdicionProfesional}
                  className="font-body text-xs text-inksoft underline"
                >
                  Cancelar edición
                </button>
              )}
            </div>
            <input
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              placeholder="Nombre o nombre del negocio"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <div className="grid grid-cols-2 gap-3 mb-3">
              <select
                value={categoriaSel}
                onChange={(e) => {
                  const nuevaCategoria = e.target.value
                  setCategoriaSel(nuevaCategoria)
                  const cat = categorias.find((c) => c.id === nuevaCategoria)
                  setRubro(cat?.rubros[0]?.id || 'otro')
                }}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                {categorias.map((c) => (
                  <option key={c.id} value={c.id}>{c.label}</option>
                ))}
              </select>
              <select
                value={rubro}
                onChange={(e) => setRubro(e.target.value)}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                {(categorias.find((c) => c.id === categoriaSel)?.rubros || []).map((r) => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>
            <div className="font-body text-[11px] text-inksoft mb-3 -mt-2">
              ¿No está el rubro que buscás? Agregalo desde la pestaña "Categorías" y va a aparecer acá.
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <select
                value={plan}
                onChange={(e) => setPlan(e.target.value as 'basico' | 'premium')}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                <option value="basico">Plan básico</option>
                <option value="premium">Plan premium (destacado)</option>
              </select>
            </div>
            <input
              value={especialidad}
              onChange={(e) => setEspecialidad(e.target.value)}
              placeholder="Especialidad (opcional, ej: Médico general - Ecografista)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <textarea
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              placeholder="Descripción breve"
              rows={2}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />

            <div className="mb-3">
              <div className="font-body text-xs font-semibold text-ink mb-1">Servicios (qué hace concretamente)</div>
              <div className="font-body text-[11px] text-inksoft mb-2">
                Hasta 6 puntos concretos, ej: "Instalación de grifería", "Reparación de fugas". Se muestran en el perfil público.
              </div>
              {servicios.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {servicios.map((s, i) => (
                    <span key={i} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-panelalt border border-line font-body text-xs text-ink">
                      {s}
                      <button type="button" onClick={() => quitarServicio(i)} className="text-inksoft hover:text-maroon leading-none">✕</button>
                    </span>
                  ))}
                </div>
              )}
              {servicios.length < 6 && (
                <div className="flex gap-2">
                  <input
                    value={nuevoServicio}
                    onChange={(e) => setNuevoServicio(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') { e.preventDefault(); agregarServicio() }
                    }}
                    placeholder="Ej: Instalación de grifería"
                    className="flex-1 px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
                  />
                  <button
                    type="button"
                    onClick={agregarServicio}
                    className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm text-ink bg-panelalt"
                  >
                    Agregar
                  </button>
                </div>
              )}
            </div>

            <div className="mb-3">
              <div className="font-body text-xs text-inksoft mb-1.5">Foto (opcional)</div>
              <div className="flex items-center gap-3 flex-wrap">
                {imagenUrl && (
                  <img
                    src={imagenUrl}
                    alt="Vista previa"
                    className="w-14 h-14 object-cover rounded-lg border border-line"
                  />
                )}
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => subirImagenProfesional(e.target.files?.[0] || null)}
                    disabled={subiendoImagen}
                    className="font-body text-xs"
                  />
                  {subiendoImagen && <div className="font-body text-xs text-maroon mt-1">Subiendo imagen...</div>}
                </div>
              </div>
            </div>

            <div className="bg-panelalt rounded-lg p-3 mb-3">
              <div className="font-body text-xs font-semibold text-ink mb-1">Armar con IA a partir de un CV (opcional)</div>
              <div className="font-body text-[11px] text-inksoft mb-2">
                Subí el CV del profesional (PDF, Word .docx, foto o escaneo) y la IA precarga nombre, especialidad, experiencia y descripción acá arriba — revisalos y corregilos antes de publicar, igual que cualquier otro dato.
              </div>
              <input
                type="file"
                accept="application/pdf,.pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,.docx,image/*"
                onChange={(e) => leerCVAdmin(e.target.files?.[0] || null)}
                disabled={leyendoCVAdmin}
                className="font-body text-xs"
              />
              {leyendoCVAdmin && <div className="font-body text-xs text-maroon mt-1">Leyendo el CV...</div>}
              {rubroSugeridoCV && rubroSugeridoCV !== rubro && (
                <div className="font-body text-[11px] text-teal mt-2">
                  💡 Por el CV, este profesional podría encajar mejor en el rubro &quot;{categorias.flatMap((c) => c.rubros).find((r) => r.id === rubroSugeridoCV)?.label || rubroSugeridoCV}&quot;. Cambialo arriba en el selector de rubro si te parece correcto.
                </div>
              )}
            </div>

            <div className="border border-line rounded-lg p-3 mb-3">
              <div className="flex items-start justify-between gap-3 mb-1">
                <div className="font-body text-xs font-semibold text-ink">CV estandarizado (opcional)</div>
                {profesionalEditandoId && (
                  <a href={`/servicios/${profesionalEditandoId}/cv`} target="_blank" rel="noopener noreferrer" className="font-body text-[11px] text-teal underline shrink-0">
                    📄 Ver CV guardado
                  </a>
                )}
              </div>
              <div className="font-body text-[11px] text-inksoft mb-2.5">
                Historial laboral e idiomas — con esto y el resto del formulario se arma su CV oficial descargable en PDF. Si subiste un CV arriba, ya viene precargado.
              </div>
              <label className="flex items-center gap-2 font-body text-xs text-ink mb-2.5 cursor-pointer">
                <input type="checkbox" checked={cvPublico} onChange={(e) => setCvPublico(e.target.checked)} className="accent-teal" />
                Mostrar el CV para descargar en su perfil público
              </label>
              <EditorCV
                historial={historialCV}
                onHistorialChange={setHistorialCV}
                idiomas={idiomasCV}
                onIdiomasChange={setIdiomasCV}
                mejorarConIA={mejorarPuestoConIAAdmin}
              />
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <input
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
                type="number"
                placeholder="Precio en Bs (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
              <input
                value={experiencia}
                onChange={(e) => setExperiencia(e.target.value)}
                placeholder="Experiencia (ej: 20 años)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
            </div>
            <div className="font-body text-[11px] text-inksoft mb-3 -mt-2">
              Si dejás el precio vacío, no se muestra ningún precio (hasta que el profesional lo pase por WhatsApp).
            </div>

            <label className="block font-body text-xs text-ink mb-3">
              <span className="block font-semibold mb-1">📍 País y ciudad</span>
              <select
                value={ciudadPf}
                onChange={(e) => setCiudadPf(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                {Array.from(new Set(ciudadesTodas.map((c) => c.pais))).map((pais) => (
                  <optgroup key={pais} label={`${banderaDe(pais)} ${buscarPaisMercado(pais).nombre}`}>
                    {ciudadesTodas.filter((c) => c.pais === pais).map((c) => (
                      <option key={c.id} value={c.id}>{banderaDe(c.pais)} {c.nombre}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </label>
            <input
              value={zona}
              onChange={(e) => setZona(e.target.value)}
              placeholder={buscarCiudad(ciudadPf).pais === 'AR' ? 'Zona / barrio (ej: Palermo)' : 'Zona / barrio (ej: Sopocachi, La Paz)'}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={direccion}
              onChange={(e) => setDireccion(e.target.value)}
              placeholder="Dirección (opcional, ej: Fortunato Gumiel)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <textarea
              value={dondeTrabaja}
              onChange={(e) => setDondeTrabaja(e.target.value)}
              placeholder="Resumen de dónde trabaja (opcional, ej: Consultorio propio en Sopocachi, atiende también en Clínica del Sur los martes)"
              rows={2}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={educacion}
              onChange={(e) => setEducacion(e.target.value)}
              placeholder="Estudios (opcional, ej: Maestría en Data Mining (UBA) · Ingeniería en Sistemas (UCB))"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <div className="grid grid-cols-2 gap-3 mb-3">
              <input
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                placeholder="Latitud (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
              <input
                value={lng}
                onChange={(e) => setLng(e.target.value)}
                placeholder="Longitud (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
            </div>
            <input
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder={buscarCiudad(ciudadPf).pais === 'AR' ? 'WhatsApp (ej: 1123456789, código de área + número, sin +54)' : 'WhatsApp (ej: 71234567, sin +591)'}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={emailProfesional}
              onChange={(e) => setEmailProfesional(e.target.value)}
              type="email"
              placeholder="Email (opcional)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <CampoRedes valor={redesPf} onChange={setRedesPf} className="mb-3" />
            <CampoReservas valor={reservasPf} onChange={setReservasPf} link={linkVideoPf} onLink={setLinkVideoPf} className="mb-1" />
            {(reservasPf.consultorio || reservasPf.videollamada) && (plan !== 'premium' || bloquesConPendienteAdmin().length === 0) && (
              <div className="font-body text-[11px] text-ochre bg-ochre/10 border border-ochre/30 rounded-md px-2.5 py-1.5 mb-3">
                ⚠️ El calendario todavía no se va a ver en su perfil:{' '}
                {plan !== 'premium'
                  ? 'necesita plan Premium (elegilo arriba y guardá).'
                  : 'falta cargar sus horarios en "Agenda de turnos" de abajo (elegí los días, el horario y guardá).'}
              </div>
            )}
            {!(reservasPf.consultorio || reservasPf.videollamada) && <div className="mb-3" />}
            <div className="flex gap-2 mb-4 flex-wrap">
              {ICONOS_SERVICIO.map((i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setIcono(i)}
                  className={`w-11 h-11 rounded-lg border flex items-center justify-center ${
                    icono === i ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line text-inksoft'
                  }`}
                >
                  <ServiceIcon kind={i} size={20} />
                </button>
              ))}
            </div>
            {profesionalEditandoId && plan === 'premium' && (
              <div className="bg-panelalt rounded-lg p-3 mb-4">
                <div className="font-body text-xs font-semibold text-ink mb-2">Agenda de turnos (Premium)</div>
                <div className="font-body text-[11px] text-inksoft mb-2">
                  Bloques por día — ej. "Lunes a viernes, 19 a 21" y "Sábados, 9 a 14" son dos bloques distintos.
                </div>
                {editHorarioBloques.length === 0 && (
                  <div className="font-body text-[11px] text-ochre mb-2">Todavía no tiene horarios: tocá los días que atiende, elegí el horario y guardá.</div>
                )}
                {editHorarioBloques.length > 0 && (
                  <div className="flex flex-col gap-1.5 mb-3">
                    {editHorarioBloques.map((b) => (
                      <div key={b.id} className="flex items-center justify-between gap-2 bg-panel rounded-md px-2.5 py-2">
                        <div className="font-body text-xs text-ink">
                          <strong>{b.dias.map((d) => DIAS_SEMANA[d].corto).join(', ')}</strong> · {b.desde}–{b.hasta} · {INTERVALOS_TURNO.find((i) => i.min === b.intervaloMin)?.label || `cada ${b.intervaloMin} min`}
                        </div>
                        <button type="button" onClick={() => quitarBloqueAdmin(b.id)} className="text-inksoft border-none bg-transparent leading-none shrink-0">✕</button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex gap-1.5 flex-wrap mb-2">
                  {DIAS_SEMANA.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => toggleDiaNuevoBloqueAdmin(d.id)}
                      className={`px-2.5 py-1.5 rounded-md border font-body text-xs font-medium ${
                        editNuevoBloqueDias.includes(d.id) ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                      }`}
                    >
                      {d.corto}
                    </button>
                  ))}
                </div>

                <label className="flex items-center gap-1.5 mb-2">
                  <input type="checkbox" checked={editNuevoBloqueTodoElDia} onChange={(e) => setEditNuevoBloqueTodoElDia(e.target.checked)} />
                  <span className="font-body text-xs text-ink">Todo el día</span>
                </label>

                {!editNuevoBloqueTodoElDia && (
                  <div className="flex gap-2 mb-2 items-center">
                    <input
                      type="time"
                      value={editNuevoBloqueDesde}
                      onChange={(e) => setEditNuevoBloqueDesde(e.target.value)}
                      className="px-3 py-2 rounded-lg border border-line font-body text-sm"
                    />
                    <span className="font-body text-xs text-inksoft">a</span>
                    <input
                      type="time"
                      value={editNuevoBloqueHasta}
                      onChange={(e) => setEditNuevoBloqueHasta(e.target.value)}
                      className="px-3 py-2 rounded-lg border border-line font-body text-sm"
                    />
                  </div>
                )}

                <select
                  value={editNuevoBloqueIntervalo}
                  onChange={(e) => setEditNuevoBloqueIntervalo(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-line font-body text-sm bg-panel mb-2"
                >
                  {INTERVALOS_TURNO.map((i) => (
                    <option key={i.min} value={i.min}>{i.label}</option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={agregarBloqueAdmin}
                  disabled={editNuevoBloqueDias.length === 0}
                  className="w-full py-2 rounded-lg border border-line font-body text-xs text-ink disabled:opacity-50 mb-3"
                >
                  + Agregar bloque
                </button>

                <button
                  type="button"
                  onClick={guardarHorarioAdmin}
                  disabled={guardandoHorarioAdmin}
                  className="px-3.5 py-2 rounded-lg border-none bg-teal text-white font-body text-xs font-semibold disabled:opacity-60"
                >
                  {guardandoHorarioAdmin ? 'Guardando...' : 'Guardar agenda'}
                </button>
                {horarioAdminGuardado && <span className="font-body text-[11px] text-teal ml-2">Guardado ✓</span>}
                <div className="font-body text-[11px] text-inksoft mt-2">
                  Esto es lo mismo que el profesional puede cargar solo desde su perfil — se guarda al toque, no hace falta tocar "Guardar cambios" de abajo.
                </div>
              </div>
            )}

            {errorForm && <div className="font-body text-xs text-maroon mb-3">{errorForm}</div>}
            <button
              type="submit"
              disabled={publicando || subiendoImagen}
              className="w-full py-2.5 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold"
            >
              {publicando ? (profesionalEditandoId ? 'Guardando...' : 'Publicando...') : (profesionalEditandoId ? 'Guardar cambios' : 'Publicar profesional')}
            </button>
          </form>

          <div className={`${vistaServ === 'importar' ? '' : 'hidden '}bg-panel border border-line rounded-xl p-5 mb-8`}>
            <div className="font-body text-sm font-semibold text-ink mb-2">Importar en lote (desde WhatsApp)</div>
            <div className="font-body text-[11px] text-inksoft mb-2">
              Pegá el texto de un canal/grupo de WhatsApp con varios avisos de oficios o servicios seguidos (título, teléfono y descripción cada uno) — mismo formato que en Anuncios. A diferencia de los anuncios, acá <strong>ningún</strong> importado se publica solo: todos entran a "Solicitudes pendientes" de abajo con rubro y zona sin definir, para que los revises uno por uno, les asignes el rubro/zona real, y uses "Pedir más info" si hace falta antes de aprobar.
            </div>
            <textarea
              value={textoImportarServicios}
              onChange={(e) => setTextoImportarServicios(e.target.value)}
              placeholder="Pegá acá el texto completo copiado de WhatsApp..."
              rows={6}
              className="w-full px-3 py-2.5 rounded-lg border border-line font-body text-xs mb-2"
            />
            <button
              type="button"
              onClick={parsearTextoServicios}
              disabled={!textoImportarServicios.trim()}
              className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
            >
              Detectar avisos
            </button>

            {parseadosServicios.length > 0 && (
              <div className="mt-4">
                <div className="font-body text-xs text-inksoft mb-3">
                  Se detectaron <strong>{parseadosServicios.length}</strong> avisos. Los marcados <span className="text-ochre font-semibold">"texto cortado"</span> además quedan con una nota pidiendo el texto completo — pero insisto: TODOS quedan pendientes de revisión, completo o no.
                </div>

                <div className="flex flex-col gap-2 mb-3 max-h-[480px] overflow-y-auto pr-1">
                  {parseadosServicios.map((p, i) => (
                    <div key={i} className={`border rounded-lg p-3 ${p.incompleto ? 'border-ochre bg-ochresoft' : 'border-line bg-panel'}`}>
                      <div className="flex items-start gap-2 mb-2">
                        <input
                          type="checkbox"
                          checked={p.incluir}
                          onChange={(e) => actualizarParseadoServicio(i, { incluir: e.target.checked })}
                          className="mt-1 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <input
                            value={p.titulo}
                            onChange={(e) => actualizarParseadoServicio(i, { titulo: e.target.value })}
                            className="w-full font-body text-xs font-semibold text-ink bg-transparent border-none p-0 mb-1"
                          />
                          <div className="font-body text-[11px] text-inksoft mb-1">📞 {p.telefono} · {p.fecha}</div>
                          {p.incompleto && (
                            <div className="font-body text-[10px] font-bold text-ochre uppercase mb-1">⚠ Texto cortado — falta info</div>
                          )}
                        </div>
                      </div>
                      <textarea
                        value={p.descripcion}
                        onChange={(e) => actualizarParseadoServicio(i, { descripcion: e.target.value })}
                        rows={2}
                        className="w-full px-2 py-1.5 rounded-md border border-line font-body text-[11px] mb-2"
                      />
                      {invitadosLocal[soloNumero(p.telefono)] && (
                        <span className="inline-block mr-2 mb-1 px-2 py-0.5 rounded-full bg-tealsoft border border-teal font-body text-[10px] font-semibold text-teal">
                          ✓ Invitado el {fechaInvitacion(invitadosLocal[soloNumero(p.telefono)])}
                        </span>
                      )}
                      <a
                        href={`https://wa.me/591${p.telefono.replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => marcarInvitadoLocal(p.telefono)}
                        className={`inline-block px-2.5 py-1 rounded-md font-body text-[11px] font-semibold ${invitadosLocal[soloNumero(p.telefono)] ? 'border border-line bg-panel text-inksoft' : 'bg-teal text-white'}`}
                      >
                        💬 {invitadosLocal[soloNumero(p.telefono)] ? 'Invitar de nuevo' : 'Invitar por WhatsApp'}
                      </a>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={importarServiciosSeleccionados}
                  disabled={importandoServicios || parseadosServicios.filter((p) => p.incluir).length === 0}
                  className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-50"
                >
                  {importandoServicios
                    ? 'Importando...'
                    : `Importar ${parseadosServicios.filter((p) => p.incluir).length} a revisión`}
                </button>

                {resultadoImportacionServicios && (
                  <div className="mt-2 font-body text-xs text-teal">
                    Se crearon {resultadoImportacionServicios.creados} profesionales, todos pendientes de revisión.
                    {resultadoImportacionServicios.errores.length > 0 && (
                      <div className="text-maroon mt-1">{resultadoImportacionServicios.errores.join(' · ')}</div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className={vistaServ === 'pendientes' ? '' : 'hidden'}>
          {profesionales.filter((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada' || p.planEstadoPago === 'informado_pago').length === 0 && (
            <div className="font-body text-sm text-inksoft bg-panel border border-line rounded-xl p-6 text-center mb-6">✓ No hay solicitudes ni pagos pendientes.</div>
          )}
          {profesionales.some((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada') && (
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <div className="font-body text-xs text-inksoft">
                La IA ordena pendientes y en espera según qué tan probable es que acepten (los invitados hace días sin respuesta bajan).
              </div>
              <button
                onClick={() => { priorizarPendientesConIA(); setFiltrosPros((f) => ({ ...f, orden: 'ia' })) }}
                disabled={priorizandoIA}
                className="px-3 py-1.5 rounded-md border border-indigo-200 bg-indigo-50 font-body text-xs font-semibold text-indigo-700 disabled:opacity-60"
              >
                {priorizandoIA ? 'Analizando con IA...' : '🤖 Ordenar por prioridad con IA'}
              </button>
            </div>
          )}
          {errorPriorizarIA && (
            <div className="font-body text-xs text-maroon bg-maroon/10 border border-maroon rounded-md px-3 py-2 mb-3">{errorPriorizarIA}</div>
          )}
          {profesionales.some((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada') && (
            <FiltrosLista
              filtros={filtrosPros}
              onChange={setFiltrosPros}
              rubros={rubrosDe(profesionales.filter((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada'))}
              total={profesionales.filter((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada').length}
              visibles={filtrarPros(profesionales.filter((p) => p.estado === 'pendiente_revision' || p.estado === 'info_solicitada')).length}
            />
          )}
          {profesionales.filter((p) => p.estado === 'pendiente_revision').length > 0 && (
            <div className="mb-8">
              <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                <div className="font-body text-sm font-semibold text-ochre">
                  Solicitudes pendientes de revisión ({profesionales.filter((p) => p.estado === 'pendiente_revision').length})
                </div>
              </div>
              {filtrarPros(profesionales.filter((p) => p.estado === 'pendiente_revision')).length === 0 && (
                <div className="font-body text-xs text-inksoft mb-3">Ninguna solicitud pendiente coincide con los filtros.</div>
              )}
              {filtrarPros(profesionales.filter((p) => p.estado === 'pendiente_revision'))
                .map((p) => (
                <div key={p.id} className="bg-panel border border-ochre rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  <div className="font-body text-xs text-inksoft mb-1">
                    {ciudadDe(p) !== 'potosi' && `📍 ${buscarCiudad(ciudadDe(p)).nombre} · `}{p.atiendeOnline && '💻 Online · '}{buscarRubro(p.rubro)?.label} · {p.zona || 'sin zona'} · WhatsApp: {p.whatsapp}
                    {p.email && <> · Email: {p.email}</>}
                  </div>
                  {(p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)]) && (
                    <div className="inline-block mb-1.5 px-2 py-0.5 rounded-full bg-tealsoft border border-teal font-body text-[11px] font-semibold text-teal">
                      ✓ Invitado por WhatsApp el {fechaInvitacion(p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)])}
                      {(p.invitaciones || 0) > 1 && ` · ${p.invitaciones} veces`}
                    </div>
                  )}
                  {p.descripcion && <div className="font-body text-xs text-ink mb-2">{p.descripcion}</div>}
                  <div className="font-body text-[11px] text-inksoft mb-2">
                    {p.precio ? `Bs ${Number(p.precio).toLocaleString('es-BO')}` : 'Precio a convenir'}
                    {p.experiencia && ` · Experiencia: ${p.experiencia}`}
                  </div>
                  <BadgeRiesgoIA moderacionIA={p.moderacionIA} />
                  {p.prioridadInvitacionIA && <BadgePrioridad pr={p.prioridadInvitacionIA} />}

                  {pidiendoInfoId === p.id ? (
                    <div className="mt-3">
                      <textarea
                        value={notaPidiendoInfo}
                        onChange={(e) => setNotaPidiendoInfo(e.target.value)}
                        placeholder="¿Qué le pediste? (ej: le pedí una foto más clara, quedé de escribirle el viernes)"
                        rows={2}
                        className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            cambiarEstadoProfesional(p.id, 'info_solicitada', notaPidiendoInfo)
                            setPidiendoInfoId(null)
                            setNotaPidiendoInfo('')
                          }}
                          className="px-3.5 py-1.5 rounded-md border-none bg-ochre text-white font-body text-xs font-semibold"
                        >
                          Guardar y marcar en espera
                        </button>
                        <button
                          onClick={() => { setPidiendoInfoId(null); setNotaPidiendoInfo('') }}
                          className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2 mt-3 flex-wrap">
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'aprobado')}
                        className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                      >
                        Aprobar y publicar
                      </button>
                      <button
                        onClick={() => { setPidiendoInfoId(p.id); setNotaPidiendoInfo(p.notaAdmin || '') }}
                        className="px-3.5 py-1.5 rounded-md border border-ochre font-body text-xs text-ochre"
                      >
                        Pedir más info
                      </button>
                      {p.whatsapp && (
                        // Mismo botón que en Anuncios: abre WhatsApp con el
                        // mensaje de invitación y pasa la solicitud a
                        // "Esperando respuesta".
                        <a
                          href={`https://wa.me/${String(p.whatsapp).replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={() => invitarProfesional(p)}
                          className="px-3.5 py-1.5 rounded-md border border-indigo-200 font-body text-xs text-indigo-600"
                        >
                          💬 {p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)] ? 'Invitar de nuevo' : 'Invitar por WhatsApp'}
                        </a>
                      )}
                      <button
                        onClick={() => abrirEditarProfesional(p)}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'rechazado')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                      >
                        Rechazar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {profesionales.filter((p) => p.estado === 'info_solicitada').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-indigo-600 mb-3">
                ⏳ Esperando respuesta ({profesionales.filter((p) => p.estado === 'info_solicitada').length})
              </div>
              {filtrarPros(profesionales.filter((p) => p.estado === 'info_solicitada')).length === 0 && (
                <div className="font-body text-xs text-inksoft mb-3">Nadie en espera coincide con los filtros.</div>
              )}
              {filtrarPros(profesionales.filter((p) => p.estado === 'info_solicitada'))
                .map((p) => (
                <div key={p.id} className="bg-panel border border-indigo-200 rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  {p.prioridadInvitacionIA && <BadgePrioridad pr={p.prioridadInvitacionIA} />}
                  <div className="font-body text-xs text-inksoft mb-1">
                    {ciudadDe(p) !== 'potosi' && `📍 ${buscarCiudad(ciudadDe(p)).nombre} · `}{p.atiendeOnline && '💻 Online · '}{buscarRubro(p.rubro)?.label} · {p.zona || 'sin zona'} · WhatsApp: {p.whatsapp}
                    {p.email && <> · Email: {p.email}</>}
                  </div>
                  {(p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)]) && (
                    <div className="inline-block mb-1.5 px-2 py-0.5 rounded-full bg-tealsoft border border-teal font-body text-[11px] font-semibold text-teal">
                      ✓ Invitado por WhatsApp el {fechaInvitacion(p.invitadoEn || invitadosLocal[soloNumero(p.whatsapp)])}
                      {(p.invitaciones || 0) > 1 && ` · ${p.invitaciones} veces`}
                    </div>
                  )}
                  {p.notaAdmin && (
                    <div className="font-body text-xs text-indigo-700 bg-indigo-50 rounded-md px-2.5 py-2 mb-2">
                      📝 {p.notaAdmin}
                    </div>
                  )}
                  {pidiendoInfoId === p.id ? (
                    <div className="mt-1">
                      <textarea
                        value={notaPidiendoInfo}
                        onChange={(e) => setNotaPidiendoInfo(e.target.value)}
                        rows={2}
                        className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            cambiarEstadoProfesional(p.id, 'info_solicitada', notaPidiendoInfo)
                            setPidiendoInfoId(null)
                            setNotaPidiendoInfo('')
                          }}
                          className="px-3.5 py-1.5 rounded-md border-none bg-indigo-600 text-white font-body text-xs font-semibold"
                        >
                          Actualizar nota
                        </button>
                        <button
                          onClick={() => { setPidiendoInfoId(null); setNotaPidiendoInfo('') }}
                          className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2 flex-wrap">
                      <a
                        href={`https://wa.me/${String(p.whatsapp).replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => invitarProfesional(p)}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        💬 Invitar de nuevo
                      </a>
                      <a
                        href={`https://wa.me/${String(p.whatsapp).replace(/\D/g, '')}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                      >
                        Escribirle
                      </a>
                      <button
                        onClick={() => { setPidiendoInfoId(p.id); setNotaPidiendoInfo(p.notaAdmin || '') }}
                        className="px-3.5 py-1.5 rounded-md border border-indigo-200 font-body text-xs text-indigo-600"
                      >
                        Editar nota
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'aprobado')}
                        className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                      >
                        Aprobar y publicar
                      </button>
                      <button
                        onClick={() => abrirEditarProfesional(p)}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'pendiente_revision')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                      >
                        Volver a pendiente
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'rechazado')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                      >
                        Rechazar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {profesionales.filter((p) => p.planEstadoPago === 'informado_pago').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-teal mb-3">
                💳 Pagos de membresía Premium por confirmar ({profesionales.filter((p) => p.planEstadoPago === 'informado_pago').length})
              </div>
              {profesionales
                .filter((p) => p.planEstadoPago === 'informado_pago')
                .map((p) => (
                <div key={p.id} className="bg-panel border border-teal rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  <div className="font-body text-xs text-inksoft mb-3">
                    WhatsApp: {p.whatsapp}
                    {p.planVigenciaHasta && new Date(p.planVigenciaHasta).getTime() > Date.now() && (
                      <> · Ya tiene Premium vigente hasta {new Date(p.planVigenciaHasta).toLocaleDateString('es-BO')} — confirmar esto se lo extiende 30 días más desde esa fecha</>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => confirmarPagoPremium(p)}
                      className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                    >
                      Confirmar pago recibido
                    </button>
                    <button
                      onClick={() => rechazarPagoPremium(p.id)}
                      className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                    >
                      No llegó / rechazar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          </div>

          {vistaServ === 'publicados' && (() => {
            const q = buscarServ.trim().toLowerCase()
            const lista = profesionales
              .filter((p) => !p.estado || p.estado === 'aprobado')
              .filter((p) => !filtroCiudadServ || ciudadDe(p) === filtroCiudadServ)
              .filter((p) => !filtroPlanServ || (filtroPlanServ === 'premium' ? p.plan === 'premium' : p.plan !== 'premium'))
              .filter((p) => !q || [p.nombre, p.especialidad, buscarRubro(p.rubro)?.label, p.zona, p.whatsapp, p.email].some((x) => String(x || '').toLowerCase().includes(q)))
              .sort((a, b) =>
                ordenServ === 'vistas' ? (b.vistas || 0) - (a.vistas || 0)
                : ordenServ === 'recientes' ? String(b.createdAt || '').localeCompare(String(a.createdAt || ''))
                : ordenServ === 'nombre' ? String(a.nombre || '').localeCompare(String(b.nombre || ''), 'es')
                : (b.clicsWhatsapp || 0) - (a.clicsWhatsapp || 0))
            const sel = 'px-2 py-1.5 rounded-md border border-line bg-panel font-body text-xs'
            return (
              <div>
                <div className="flex flex-wrap gap-2 items-center mb-3">
                  <input
                    value={buscarServ}
                    onChange={(e) => { setBuscarServ(e.target.value); setLimiteServ(40) }}
                    placeholder="🔍 Buscar por nombre, rubro, zona o WhatsApp"
                    className="flex-1 min-w-[220px] px-3 py-2 rounded-lg border border-line bg-panel font-body text-sm"
                  />
                  <select value={filtroCiudadServ} onChange={(e) => setFiltroCiudadServ(e.target.value)} className={sel} aria-label="Ciudad">
                    <option value="">📍 Todas las ciudades</option>
                    {ciudadesTodas.map((c) => <option key={c.id} value={c.id}>{banderaDe(c.pais)} {c.nombre}</option>)}
                  </select>
                  <select value={filtroPlanServ} onChange={(e) => setFiltroPlanServ(e.target.value as any)} className={sel} aria-label="Plan">
                    <option value="">Todos los planes</option>
                    <option value="premium">⭐ Premium</option>
                    <option value="basico">Básico</option>
                  </select>
                  <select value={ordenServ} onChange={(e) => setOrdenServ(e.target.value as any)} className={sel} aria-label="Orden">
                    <option value="contactos">Más contactos</option>
                    <option value="vistas">Más vistas</option>
                    <option value="recientes">Más recientes</option>
                    <option value="nombre">Nombre A-Z</option>
                  </select>
                  <button type="button" onClick={() => { cancelarEdicionProfesional(); setVistaServ('form') }} className="px-3 py-1.5 rounded-md border-none bg-maroon text-white font-body text-xs font-semibold">➕ Nuevo</button>
                </div>
                <div className="font-body text-[11px] text-inksoft mb-2">{lista.length} de {profesionales.filter((p) => !p.estado || p.estado === 'aprobado').length} publicados</div>
                <div className="bg-panel border border-line rounded-xl overflow-hidden mb-4">
                  {lista.length === 0 && <div className="font-body text-sm text-inksoft p-6 text-center">Ningún profesional coincide.</div>}
                  {lista.slice(0, limiteServ).map((p) => {
                    const r = reservasDe(p)
                    const conAgenda = p.plan === 'premium' && (r.consultorio || r.videollamada) && (p.horarioTurnos?.bloques?.length > 0)
                    return (
                      <div key={p.id} className="flex items-center gap-3 px-3 py-2 border-b border-line last:border-b-0 hover:bg-panelalt">
                        <div className="w-9 h-9 rounded-lg bg-panelalt flex items-center justify-center text-maroon shrink-0 overflow-hidden">
                          {p.imagenUrl ? <img src={p.thumbUrl || p.imagenUrl} alt="" loading="lazy" decoding="async" className="w-full h-full object-cover" /> : <ServiceIcon kind={p.icono} size={18} />}
                        </div>
                        <button type="button" onClick={() => abrirEditarProfesional(p)} className="flex-1 min-w-0 text-left bg-transparent border-none p-0">
                          <div className="font-body text-sm font-semibold text-ink truncate">
                            {p.nombre}
                            {p.plan === 'premium' && <span className="ml-1.5 text-[10px] font-bold text-ochre">⭐ Premium</span>}
                          </div>
                          <div className="font-body text-[11px] text-inksoft truncate">
                            {banderaDe(buscarCiudad(ciudadDe(p)).pais)} {buscarCiudad(ciudadDe(p)).nombre} · {buscarRubro(p.rubro)?.label || p.especialidad || 'Sin rubro'}{p.zona ? ` · ${p.zona}` : ''}
                          </div>
                        </button>
                        <div className="hidden sm:flex items-center gap-2 font-body text-[11px] text-inksoft shrink-0">
                          {(r.consultorio || r.videollamada) && (
                            <span title={conAgenda ? 'Calendario activo' : 'Marcó reservas pero falta Premium u horarios'} className={conAgenda ? 'text-teal' : 'text-ochre'}>
                              {r.consultorio ? '🏢' : ''}{r.videollamada ? '🎥' : ''}{conAgenda ? '' : '⚠️'}
                            </span>
                          )}
                          <span title="Vistas">👁 {p.vistas || 0}</span>
                          <span title="Contactos por WhatsApp">💬 {p.clicsWhatsapp || 0}</span>
                        </div>
                        <div className="flex items-center gap-2.5 shrink-0">
                          <a href={`/servicios/${p.id}`} target="_blank" rel="noopener noreferrer" className="font-body text-xs text-inksoft underline" title="Ver perfil público">Ver</a>
                          <a href={`/servicios/${p.id}/cv`} target="_blank" rel="noopener noreferrer" className="hidden sm:inline font-body text-xs text-inksoft underline">{p.cvPublico === false ? 'CV 🔒' : 'CV'}</a>
                          <button type="button" onClick={() => abrirEditarProfesional(p)} className="font-body text-xs text-teal font-semibold underline">Editar</button>
                          <button type="button" onClick={() => borrarProfesional(p.id, p.nombre)} className="font-body text-xs text-maroon underline">Borrar</button>
                        </div>
                      </div>
                    )
                  })}
                </div>
                {lista.length > limiteServ && (
                  <button type="button" onClick={() => setLimiteServ((n) => n + 40)} className="w-full py-2 rounded-lg border border-line bg-panel font-body text-xs font-semibold text-ink mb-4">
                    Ver más ({lista.length - limiteServ} restantes)
                  </button>
                )}
              </div>
            )
          })()}
        </div>
      )}

      {tab === 'anuncios' && (
        <div>
          {macheos?.totales && (
            <div className="mb-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalVistas}</div>
                  <div className="font-body text-[11px] text-inksoft">Vistas totales</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalMatcheos}</div>
                  <div className="font-body text-[11px] text-inksoft">Matcheos generados</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalEmailsEnviados}</div>
                  <div className="font-body text-[11px] text-inksoft">Mails enviados</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink truncate" title={macheos.totales.anuncioMasVisto?.anuncioTitulo}>
                    {macheos.totales.anuncioMasVisto?.vistas ?? 0}
                  </div>
                  <div className="font-body text-[11px] text-inksoft truncate" title={macheos.totales.anuncioMasVisto?.anuncioTitulo}>
                    Más visto: {macheos.totales.anuncioMasVisto?.anuncioTitulo || '—'}
                  </div>
                </div>
              </div>

              <div className="font-body text-xs font-semibold text-inksoft mb-2">Ranking de anuncios por vistas y matcheos</div>
              <div className="space-y-1.5 mb-1">
                {macheos.porAnuncio.slice(0, 20).map((a: any, i: number) => (
                  <div key={a.anuncioId} className="bg-panel border border-line rounded-lg">
                    <button
                      type="button"
                      onClick={() => setAnuncioExpandido(anuncioExpandido === a.anuncioId ? null : a.anuncioId)}
                      className="w-full flex items-center gap-3 p-2.5 text-left"
                    >
                      <span className="font-body text-[11px] text-inksoft w-5 shrink-0">{i + 1}.</span>
                      <span className="font-body text-xs text-ink flex-1 truncate">{a.anuncioTitulo}</span>
                      <span className="font-body text-[11px] text-inksoft shrink-0">👁 {a.vistas}</span>
                      {a.matcheos > 0 && (
                        <span className="font-body text-[11px] text-teal shrink-0">
                          🎯 {a.matcheos} · ✉️ {a.emailsEnviados}
                        </span>
                      )}
                    </button>
                    {anuncioExpandido === a.anuncioId && (
                      <div className="border-t border-line px-3 py-2.5">
                        {a.destinatarios.length === 0 ? (
                          <div className="font-body text-[11px] text-inksoft">
                            {a.tipo === 'busqueda' ? 'Todavía no matcheó con ningún profesional.' : 'Este tipo de anuncio no genera matcheos automáticos.'}
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <div className="font-body text-[11px] font-semibold text-inksoft mb-1">A quiénes se avisó:</div>
                            {a.destinatarios.map((d: any, j: number) => (
                              <div key={j} className="font-body text-[11px] text-inksoft flex items-center gap-2">
                                <span className={d.emailEnviado ? 'text-teal' : 'text-maroon'}>{d.emailEnviado ? '✓' : '✕'}</span>
                                <span className="text-ink">{d.profesionalNombre || 'Profesional'}</span>
                                <span>{d.email || 'sin email cargado'}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {cargandoMacheos && <div className="font-body text-[11px] text-inksoft">Actualizando...</div>}
            </div>
          )}

          <div className="bg-panel border border-line rounded-xl p-5 mb-8">
            <div className="font-body text-sm font-semibold text-ink mb-1">Matcheos con IA</div>
            <div className="font-body text-[11px] text-inksoft mb-3">
              El matcheo automático de arriba solo cruza por rubro exacto. Este análisis mira los anuncios "Busco X" que se quedaron sin nadie (sin rubro, o rubro sin ningún profesional cargado) y sugiere, leyendo el texto, quién podría igual servir. No manda nada solo — cada sugerencia la aprobás vos, una por una.
            </div>

            <button
              type="button"
              onClick={analizarMatcheosIA}
              disabled={analizandoIA}
              className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
            >
              {analizandoIA ? 'Analizando...' : '🤖 Analizar con IA posibles matcheos'}
            </button>

            {mensajeAnalisisIA && (
              <div className="font-body text-xs text-inksoft mt-3">{mensajeAnalisisIA}</div>
            )}

            {sugerenciasIA && sugerenciasIA.length > 0 && (
              <div className="flex flex-col gap-2.5 mt-4">
                {sugerenciasIA.map((s) => {
                  const clave = `${s.anuncioId}:${s.profesionalId}`
                  const yaEnviada = sugerenciasEnviadas.has(clave)
                  return (
                    <div key={clave} className="border border-line rounded-lg p-3">
                      <div className="font-body text-xs text-inksoft mb-1">
                        <span className="font-semibold text-ink">{s.anuncioTitulo}</span> ↔ <span className="font-semibold text-ink">{s.profesionalNombre}</span>
                        <span className="text-inksoft"> ({s.profesionalRubroLabel})</span>
                      </div>
                      <div className="font-body text-[11px] text-inksoft italic mb-2">💡 {s.motivo}</div>
                      <button
                        type="button"
                        onClick={() => sugerirAAmbasPartes(s)}
                        disabled={yaEnviada || enviandoSugerenciaId === clave}
                        className={`px-3 py-1.5 rounded-md border-none font-body text-[11px] font-semibold disabled:opacity-50 ${
                          yaEnviada ? 'bg-teal text-white' : 'bg-maroon text-white'
                        }`}
                      >
                        {yaEnviada ? '✓ Sugerido a ambas partes' : enviandoSugerenciaId === clave ? 'Enviando...' : 'Sugerir a ambas partes'}
                      </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          <div className="font-body text-sm font-semibold text-ink mb-2">Importar en lote (desde WhatsApp)</div>
            <div className="font-body text-[11px] text-inksoft mb-2">
            Pegá el texto copiado de un canal/grupo de WhatsApp con varios avisos seguidos (título, teléfono y descripción cada uno). Se sube a nombre del cliente, sin que tenga cuenta acá — vos revisás cada uno antes de que se publique.
          </div>
          <textarea
            value={textoImportarAnuncios}
            onChange={(e) => setTextoImportarAnuncios(e.target.value)}
            placeholder="Pegá acá el texto completo copiado de WhatsApp..."
            rows={6}
            className="w-full px-3 py-2.5 rounded-lg border border-line font-body text-xs mb-2"
          />
          <button
            type="button"
            onClick={parsearTextoAnuncios}
            disabled={!textoImportarAnuncios.trim()}
            className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
          >
            Detectar avisos
          </button>

          {parseadosAnuncios.length > 0 && (
            <div className="mt-4">
              <div className="font-body text-xs text-inksoft mb-3">
                Se detectaron <strong>{parseadosAnuncios.length}</strong> avisos. Los marcados <span className="text-ochre font-semibold">"texto cortado"</span> se importan pidiendo más datos en vez de publicarse directo — tenés el botón de WhatsApp al lado de cada uno para pedirle al contacto que te mande el texto completo.
              </div>

              <div className="flex flex-col gap-2 mb-3 max-h-[480px] overflow-y-auto pr-1">
                {parseadosAnuncios.map((p, i) => (
                  <div key={i} className={`border rounded-lg p-3 ${p.incompleto ? 'border-ochre bg-ochresoft' : 'border-line bg-panel'}`}>
                    <div className="flex items-start gap-2 mb-2">
                      <input
                        type="checkbox"
                        checked={p.incluir}
                        onChange={(e) => actualizarParseado(i, { incluir: e.target.checked })}
                        className="mt-1 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <input
                          value={p.titulo}
                          onChange={(e) => actualizarParseado(i, { titulo: e.target.value })}
                          className="w-full font-body text-xs font-semibold text-ink bg-transparent border-none p-0 mb-1"
                        />
                        <div className="font-body text-[11px] text-inksoft mb-1">📞 {p.telefono} · {p.fecha}</div>
                        {p.incompleto && (
                          <div className="font-body text-[10px] font-bold text-ochre uppercase mb-1">⚠ Texto cortado — falta info</div>
                        )}
                      </div>
                    </div>
                    <textarea
                      value={p.descripcion}
                      onChange={(e) => actualizarParseado(i, { descripcion: e.target.value })}
                      rows={2}
                      className="w-full px-2 py-1.5 rounded-md border border-line font-body text-[11px] mb-2"
                    />
                    <a
                      href={`https://wa.me/591${p.telefono.replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block px-2.5 py-1 rounded-md bg-teal text-white font-body text-[11px] font-semibold"
                    >
                      💬 Invitar por WhatsApp
                    </a>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={importarAnunciosSeleccionados}
                disabled={importandoAnuncios || parseadosAnuncios.filter((p) => p.incluir).length === 0}
                className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-50"
              >
                {importandoAnuncios
                  ? 'Importando...'
                  : `Importar ${parseadosAnuncios.filter((p) => p.incluir).length} seleccionados`}
              </button>

              {resultadoImportacion && (
                <div className="mt-2 font-body text-xs text-teal">
                  Se crearon {resultadoImportacion.creados} anuncios.
                  {resultadoImportacion.errores.length > 0 && (
                    <div className="text-maroon mt-1">{resultadoImportacion.errores.join(' · ')}</div>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="border-t border-line my-6" />

          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="font-body text-sm font-semibold text-ink">
              Anuncios clasificados {anuncios.length > 0 && <span className="text-inksoft font-normal">({anuncios.length})</span>}
            </div>
            <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setVerPublicacionFacebook((v) => !v)}
              className="px-3 py-1.5 rounded-md border border-indigo-200 bg-panel font-body text-xs font-semibold text-indigo-700"
            >
              {verPublicacionFacebook ? 'Cerrar publicación' : '📣 Armar publicación para Facebook'}
            </button>
            <button
              onClick={priorizarAnunciosConIA}
              disabled={priorizandoAnunciosIA}
              className="px-3 py-1.5 rounded-md border border-indigo-200 bg-indigo-50 font-body text-xs font-semibold text-indigo-700 disabled:opacity-60"
            >
              {priorizandoAnunciosIA ? 'Analizando con IA...' : '🤖 Ordenar por prioridad con IA'}
            </button>
            </div>
          </div>
          {verPublicacionFacebook && <PublicacionFacebook anuncios={anuncios} rubroLabel={rubroLabelAnuncio} />}
          {errorPriorizarAnunciosIA && (
            <div className="font-body text-xs text-maroon bg-maroon/10 border border-maroon rounded-md px-3 py-2 mb-3">{errorPriorizarAnunciosIA}</div>
          )}
          {anuncios.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay ningún anuncio publicado.</div>}
          {anuncios.length > 0 && (
            <>
              <FiltrosLista
                filtros={filtrosAnuncios}
                onChange={setFiltrosAnuncios}
                rubros={rubrosDe(anuncios)}
                total={verHistorialAnuncios ? anuncios.length : anuncios.filter((a) => ['pendiente_revision', 'info_solicitada'].includes(a.estado)).length}
                visibles={filtrarAnuncios(anuncios.filter((a) => verHistorialAnuncios || ['pendiente_revision', 'info_solicitada'].includes(a.estado))).length}
              />
              <label className="flex items-center gap-2 font-body text-xs text-ink mb-3 cursor-pointer">
                <input type="checkbox" checked={verHistorialAnuncios} onChange={(e) => setVerHistorialAnuncios(e.target.checked)} className="accent-teal" />
                Ver también aprobados y rechazados ({anuncios.filter((a) => !['pendiente_revision', 'info_solicitada'].includes(a.estado)).length})
              </label>
            </>
          )}
          {filtrarAnuncios(anuncios.filter((a) => verHistorialAnuncios || ['pendiente_revision', 'info_solicitada'].includes(a.estado)))
            .map((a) => (
              <div key={a.id} className="bg-panel border border-line rounded-lg p-3.5 mb-3">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-body text-sm font-medium text-ink">{a.titulo}</span>
                      <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">
                        {labelTipoAnuncio(a.tipo)}
                      </span>
                      {a.estado === 'pendiente_revision' && (
                        <span className="inline-block bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">Pendiente</span>
                      )}
                      {a.estado === 'info_solicitada' && (
                        <span className="inline-block bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">⏳ Falta info</span>
                      )}
                      {a.estado === 'aprobado' && (
                        <span className="inline-block bg-teal text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">Aprobado</span>
                      )}
                      {a.estado === 'rechazado' && (
                        <span className="inline-block bg-maroonsoft text-maroon text-[10px] font-bold px-1.5 py-0.5 rounded-full">Rechazado</span>
                      )}
                      {a.creadoPorAdmin && (
                        <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded" title="Lo subiste vos a nombre de un cliente">
                          Importado
                        </span>
                      )}
                    </div>
                    <div className="font-body text-xs text-inksoft mt-1">{a.descripcion}</div>
                    {a.notaAdmin && (
                      <div className="font-body text-[11px] text-indigo-700 bg-indigo-50 rounded-md px-2.5 py-2 mt-1.5">
                        📝 {a.notaAdmin}
                      </div>
                    )}
                    <div className="font-body text-[11px] text-inksoft mt-1.5">
                      {ciudadDe(a) !== 'potosi' && `📍 ${buscarCiudad(ciudadDe(a)).nombre} · `}{a.autorEmail || (a.creadoPorAdmin ? 'Importado (sin cuenta)' : '')} · {a.whatsapp || a.telefonoOriginal || 'sin contacto'} {a.precio ? `· Bs ${Number(a.precio).toLocaleString('es-BO')}` : ''}
                      {a.createdAt && ` · ${new Date(a.createdAt).toLocaleDateString('es-BO')}`}
                    </div>
                    {(a.invitadoEn || invitadosLocal[soloNumero(a.whatsapp || a.telefonoOriginal)]) && (
                      <div className="inline-block mt-1.5 px-2 py-0.5 rounded-full bg-tealsoft border border-teal font-body text-[11px] font-semibold text-teal">
                        ✓ Invitado por WhatsApp el {fechaInvitacion(a.invitadoEn || invitadosLocal[soloNumero(a.whatsapp || a.telefonoOriginal)])}
                        {(a.invitaciones || 0) > 1 && ` · ${a.invitaciones} veces`}
                      </div>
                    )}
                    {a.prioridadInvitacionIA && ['pendiente_revision', 'info_solicitada'].includes(a.estado) && <BadgePrioridad pr={a.prioridadInvitacionIA} />}
                    {a.moderacionIA && (
                      <div className={`font-body text-[11px] mt-1.5 ${a.moderacionIA.riesgo === 'alto' ? 'text-maroon' : a.moderacionIA.riesgo === 'medio' ? 'text-ochre' : 'text-inksoft'}`}>
                        🤖 Riesgo {a.moderacionIA.riesgo}: {a.moderacionIA.motivo}
                      </div>
                    )}
                  </div>
                  {a.imagenUrl && (
                    <img src={a.imagenUrl} alt={a.titulo} loading="lazy" className="w-16 h-16 rounded-lg object-cover shrink-0" />
                  )}
                </div>
                <div className="flex gap-2 flex-wrap mt-3">
                  {a.estado !== 'aprobado' && (
                    <button type="button" onClick={() => cambiarEstadoAnuncio(a.id, 'aprobado')} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-[11px] font-semibold">Aprobar</button>
                  )}
                  {(a.whatsapp || a.telefonoOriginal) && a.estado !== 'aprobado' && (
                    <a
                      href={`https://wa.me/${(a.whatsapp || `591${a.telefonoOriginal}`).replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => invitarAnuncio(a)}
                      className="px-2.5 py-1.5 rounded-md border border-indigo-200 font-body text-[11px] text-indigo-600"
                    >
                      💬 {a.invitadoEn || invitadosLocal[soloNumero(a.whatsapp || a.telefonoOriginal)] ? 'Invitar de nuevo' : 'Invitar por WhatsApp'}
                    </a>
                  )}
                  {a.estado !== 'rechazado' && (
                    <button type="button" onClick={() => cambiarEstadoAnuncio(a.id, 'rechazado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Rechazar</button>
                  )}
                  <button type="button" onClick={() => eliminarAnuncio(a.id)} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Eliminar</button>
                </div>
              </div>
            ))}
        </div>
      )}

      {tab === 'reparto' && (
        <div>
          <button
            type="button"
            onClick={() => {
              const link = `${window.location.origin}/reparto-hoy?clave=${encodeURIComponent(password)}`
              navigator.clipboard.writeText(link)
              alert('Link copiado — pasáselo al repartidor por WhatsApp. No hace falta que inicie sesión.')
            }}
            className="mb-4 px-3.5 py-2 rounded-md border border-line font-body text-xs font-semibold"
          >
            🔗 Copiar link para el repartidor
          </button>
          {(() => {
            // Solo entran acá los pedidos con envío YA pagados (con
            // stock ya confirmado, porque sin eso ni siquiera llegan a
            // "pagado") y que todavía no salieron a reparto ni se
            // entregaron.
            const listos = pedidos.filter((p: any) => p.metodoEntrega === 'envio' && p.estado === 'pagado')
            const porFranja = (franja: '08:00' | '14:00') =>
              ordenarPorCercania(
                listos.filter((p: any) => calcularFranja(new Date(p.pagadoAt || p.createdAt)) === franja),
                DEPOSITO
              )
            const salida8 = porFranja('08:00')
            const salida14 = porFranja('14:00')

            const Tanda = ({ titulo, tanda }: { titulo: string; tanda: any[] }) => (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="font-display text-base font-bold text-ink">{titulo}</div>
                  {tanda.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!confirm(`¿Marcar ${tanda.length} pedido(s) como "en entrega"? Es para cuando la moto ya salió con todos estos.`)) return
                        tanda.forEach((p) => cambiarEstadoPedido(p.id, 'en_entrega'))
                      }}
                      className="px-2.5 py-1.5 rounded-md border-none bg-maroon text-white font-body text-[11px] font-semibold"
                    >
                      Marcar salida de la moto ({tanda.length})
                    </button>
                  )}
                </div>
                {tanda.length === 0 && (
                  <div className="font-body text-xs text-inksoft">No hay pedidos pagados esperando esta salida.</div>
                )}
                {tanda.map((p: any, i: number) => (
                  <div key={p.id} className="bg-panel border border-line rounded-lg p-3 mb-2 flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-maroonsoft text-maroon font-body text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-body text-[13px] font-medium text-ink">
                        {p.direccion || 'Sin dirección cargada'} · {p.zonaEntrega}
                        {p.entreCalles && ` (${p.entreCalles})`}
                        {p.referenciaAdicional && ` — ${p.referenciaAdicional}`}
                      {p.validacionZona?.coincide === false && (
                        <span className="ml-1 text-[11px] px-1.5 py-0.5 rounded bg-amber-100 text-amber-800 font-semibold" title={`Escribió “${p.validacionZona.escrita}” pero su ubicación queda en ${p.validacionZona.cercanaAlPunto || '?'}${p.validacionZona.distanciaKm != null ? ` (la zona escrita está a ${p.validacionZona.distanciaKm} km)` : ''}. Confirmá la dirección por WhatsApp.`}>⚠ zona dudosa: el mapa dice {p.validacionZona.cercanaAlPunto}</span>
                      )}
                      {p.validacionZona && !p.validacionZona.enLista && p.metodoEntrega === 'envio' && <span className="ml-1 text-[11px] px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700">🆕 zona nueva</span>}
                      </div>
                      <div className="font-body text-[11px] text-inksoft">
                        {p.comprador || 'Sin email'} · {bs(p.total, p.pais)}
                        {(p.lat == null || p.lng == null) && <span className="text-maroon"> · sin ubicación GPS, confirmar dirección a mano</span>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <label className="px-2 py-1 rounded-md border border-line font-body text-[10px] font-semibold cursor-pointer">
                        {subiendoFotoEntregaId === p.id ? 'Subiendo...' : '📷 Entregado'}
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          disabled={subiendoFotoEntregaId === p.id}
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) marcarEntregadoConFoto(p.id, file)
                            e.target.value = ''
                          }}
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => cambiarEstadoPedido(p.id, 'entregado')}
                        className="font-body text-[9px] text-inksoft underline"
                      >
                        marcar sin foto
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )

            return (
              <>
                <Tanda titulo="Salida 08:00" tanda={salida8} />
                <Tanda titulo="Salida 14:00" tanda={salida14} />
              </>
            )
          })()}
        </div>
      )}

      {tab === 'banners' && (
        <div>
          <AdminPortada password={password} />
          <div className="font-body text-sm font-semibold text-ink mb-3">
            Banners promocionales de la home
          </div>
          <div className="font-body text-xs text-inksoft mb-4">
            Se muestran en la página de inicio cuando alguien está en "🏠" (sin filtrar por Mujer/Hombre/Niños). Recomendado: imágenes apaisadas, más anchas que altas.
          </div>

          <div className="bg-panel border border-line rounded-lg p-3.5 mb-5">
            <div className="font-body text-xs font-semibold text-ink mb-2">Agregar banner nuevo</div>
            <input
              type="text"
              value={bannerLinkNuevo}
              onChange={(e) => setBannerLinkNuevo(e.target.value)}
              placeholder="Link opcional a donde lleva (https://...)"
              className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
            />
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirBanner(e.target.files?.[0] || null)}
              disabled={subiendoBanner}
              className="font-body text-xs"
            />
            {subiendoBanner && <div className="font-body text-xs text-inksoft mt-2">Subiendo...</div>}
          </div>

          {banners.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no cargaste ningún banner.</div>}
          {banners.map((b) => (
            <div key={b.id} className="bg-panel border border-line rounded-lg p-3 mb-2.5 flex items-center gap-3">
              <img src={b.imagenUrl} alt="Banner" className="w-24 h-14 rounded object-cover shrink-0 border border-line" />
              <div className="flex-1 min-w-0">
                <div className="font-body text-xs text-ink truncate">{b.link || 'Sin link'}</div>
                <div className="font-body text-[11px] text-inksoft">{b.activo !== false ? 'Activo' : 'Oculto'}</div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => toggleBanner(b.id, b.activo === false)}
                  className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                >
                  {b.activo !== false ? 'Ocultar' : 'Activar'}
                </button>
                <button
                  type="button"
                  onClick={() => eliminarBanner(b.id)}
                  className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon"
                >
                  Eliminar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'usuarios' && (
        <div>
          <CrearUsuario password={password} onCreado={() => cargarUsuarios()} />
          <CrearUsuarioPrueba password={password} onCreado={() => cargarUsuarios()} />
          <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
            <div className="font-body text-sm font-semibold text-ink">
              Usuarios registrados {usuarios.length > 0 && <span className="text-inksoft font-normal">({usuarios.length})</span>}
            </div>
            <input
              type="text"
              value={buscarUsuario}
              onChange={(e) => setBuscarUsuario(e.target.value)}
              placeholder="Buscar por email o nombre..."
              className="px-3 py-1.5 rounded-md border border-line font-body text-xs w-64 max-w-full"
            />
          </div>
          {cargandoUsuarios && <div className="font-body text-sm text-inksoft">Cargando...</div>}
          {!cargandoUsuarios && usuarios.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay usuarios registrados.</div>}
          {usuarios
            .filter((u) => {
              const q = buscarUsuario.trim().toLowerCase()
              if (!q) return true
              return (u.email || '').toLowerCase().includes(q) || (u.nombre || '').toLowerCase().includes(q)
            })
            .map((u) => {
              const productosDelUsuario = productos.filter((p) => p.vendedorId === u.uid)
              const profesionalesDelUsuario = profesionales.filter((p) => p.solicitanteUid === u.uid)
              const expandido = usuarioExpandidoId === u.uid
              return (
                <div key={u.uid} className="bg-panel border border-line rounded-lg p-3.5 mb-3">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex-1 min-w-[240px]">
                      <div className="font-body text-sm font-medium text-ink truncate flex items-center gap-2">
                        {u.email || u.nombre || u.uid}
                        {u.pausado && (
                          <span className="inline-block bg-maroonsoft text-maroon text-[10px] font-bold px-1.5 py-0.5 rounded-full">Pausado</span>
                        )}
                        {u.creadoPorAdmin && (
                          <span className="inline-block bg-tealsoft text-teal border border-teal text-[10px] font-bold px-1.5 py-0.5 rounded-full" title="Cuenta creada desde el admin">🛠️ Creado por admin</span>
                        )}
                        {u.esPrueba && (
                          <span className="inline-block bg-indigo-50 text-indigo-700 border border-indigo-200 text-[10px] font-bold px-1.5 py-0.5 rounded-full" title="Puede comprar sin restricciones de horario">🧪 Prueba</span>
                        )}
                        {administradores?.some((a) => a.uid === u.uid) && (
                          <span className="inline-block bg-ink text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full" title="Tiene clave de administrador">🛡️ Admin</span>
                        )}
                        {u.verificado === false && (
                          <span className="inline-block bg-ochresoft text-ochre border border-ochre text-[10px] font-bold px-1.5 py-0.5 rounded-full" title="Todavía no puso el código de 6 dígitos que le mandamos por mail">⏳ Sin verificar</span>
                        )}
                        {u.conGoogle && (
                          <span className="inline-block bg-panelalt text-inksoft border border-line text-[10px] font-bold px-1.5 py-0.5 rounded-full" title="Entra con su cuenta de Google">G Google</span>
                        )}
                      </div>
                      <div className="font-body text-[11px] text-inksoft mt-0.5">
                        Registrado: {u.creadoEl ? new Date(u.creadoEl).toLocaleDateString('es-BO') : '—'}
                        {u.ultimoLogin && <> · Último login: {new Date(u.ultimoLogin).toLocaleDateString('es-BO')}</>}
                        {u.celular && <> · 📱 {u.celular}</>}
                      </div>
                      <button
                        type="button"
                        onClick={() => setUsuarioExpandidoId(expandido ? null : u.uid)}
                        className="font-body text-[11px] text-teal font-semibold mt-1"
                      >
                        {productosDelUsuario.length} producto(s) · {profesionalesDelUsuario.length} servicio(s) {expandido ? '▲' : '▼'}
                      </button>
                    </div>
                    <div className="flex gap-2 flex-wrap justify-end">
                      <button
                        type="button"
                        onClick={() => cargarProductosComo(u.uid)}
                        disabled={u.pausado}
                        title="Entrar a su cuenta para cargarle la tienda y productos"
                        className="px-2.5 py-1.5 rounded-md border border-indigo-200 bg-indigo-50 text-indigo-700 font-body text-[11px] font-semibold disabled:opacity-50"
                      >
                        🛍️ Cargar productos
                      </button>
                      <button
                        type="button"
                        onClick={() => setPedirProductosUid(pedirProductosUid === u.uid ? null : u.uid)}
                        title="La IA arma un WhatsApp para pedirle sus productos y precios"
                        className={`px-2.5 py-1.5 rounded-md border font-body text-[11px] font-semibold ${pedirProductosUid === u.uid ? 'border-amber-400 bg-amber-100 text-amber-900' : 'border-amber-200 bg-amber-50 text-amber-800'}`}
                      >
                        📦 Pedir productos
                      </button>
                      <button
                        type="button"
                        onClick={() => (edicionUsuario?.uid === u.uid ? setEdicionUsuario(null) : abrirEdicionUsuario(u))}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                      >
                        ✏️ Editar
                      </button>
                      <button
                        type="button"
                        onClick={() => setPasswordUsuario(passwordUsuario?.uid === u.uid ? null : { uid: u.uid, valor: '', guardada: false, error: '', guardando: false })}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                      >
                        🔒 Contraseña
                      </button>
                      {u.email && (
                        <button
                          type="button"
                          onClick={() => enviarAccesoUsuario(u)}
                          title="Genera un link nuevo para elegir contraseña y lo manda por WhatsApp"
                          className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                        >
                          🔑 Enviar acceso
                        </button>
                      )}
                      {u.verificado === false && (
                        <button
                          type="button"
                          onClick={() => verificarUsuario(u.uid, u.email || u.uid)}
                          title="No le llegó el código de 6 dígitos: darlo por verificado"
                          className="px-2.5 py-1.5 rounded-md border border-teal bg-tealsoft text-teal font-body text-[11px] font-semibold"
                        >
                          ✅ Verificar a mano
                        </button>
                      )}
                      <select
                        value={u.ciudadAsignada || ''}
                        onChange={(e) => asignarCiudadUsuario(u.uid, e.target.value)}
                        title="Qué ciudad ve este usuario. Automática = la detectada por su IP (o la que elija)."
                        className={`px-2 py-1.5 rounded-md border font-body text-[11px] ${u.ciudadAsignada ? 'border-teal bg-tealsoft text-teal font-semibold' : 'border-line bg-panel'}`}
                      >
                        <option value="">📍 Ciudad: automática</option>
                        {ciudadesTodas.map((c) => <option key={c.id} value={c.id}>📍 Ve {c.nombre}</option>)}
                      </select>
                      {(() => {
                        const tienda = vendedoresAdmin.find((v) => v.id === u.uid)
                        if (!tienda) return null
                        return (
                          <select
                            value={ciudadDe(tienda)}
                            onChange={(e) => cambiarCiudadTienda(u.uid, e.target.value)}
                            title="Ciudad de la tienda: define el país, la moneda de sus precios y dónde aparecen sus productos"
                            className="px-2 py-1.5 rounded-md border border-line bg-panel font-body text-[11px]"
                          >
                            {ciudadesTodas.map((c) => <option key={c.id} value={c.id}>🏪 Tienda en {c.nombre}</option>)}
                          </select>
                        )
                      })()}
                      {(() => {
                        const tienda = vendedoresAdmin.find((v) => v.id === u.uid)
                        if (!tienda) return null
                        const visibleEn: string[] = Array.isArray(tienda.visibleEn) ? tienda.visibleEn : []
                        const otras = ciudadesTodas.filter((c) => c.id !== ciudadDe(tienda))
                        return (
                          <details className="relative">
                            <summary
                              title="Mostrar esta tienda y sus productos también en otras ciudades (ej. para pruebas en Argentina)"
                              className={`list-none cursor-pointer px-2.5 py-1.5 rounded-md border font-body text-[11px] ${visibleEn.length ? 'border-teal bg-tealsoft text-teal font-semibold' : 'border-line bg-panel'}`}
                            >
                              🌎 {visibleEn.length ? `También en ${visibleEn.map((id) => buscarCiudad(id).nombre).join(', ')}` : 'También visible en…'}
                            </summary>
                            <div className="absolute right-0 z-10 mt-1 w-56 bg-panel border border-line rounded-lg shadow-lg p-2.5">
                              <div className="font-body text-[10px] text-inksoft mb-1.5">Su tienda es de {buscarCiudad(ciudadDe(tienda)).nombre}. Mostrarla además en:</div>
                              {otras.map((c) => (
                                <label key={c.id} className="flex items-center gap-2 font-body text-xs text-ink py-0.5 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={visibleEn.includes(c.id)}
                                    onChange={(e) => cambiarVisibleEn(u.uid, e.target.checked ? [...visibleEn, c.id] : visibleEn.filter((x) => x !== c.id))}
                                    className="accent-teal"
                                  />
                                  {banderaDe(c.pais)} {c.nombre}{(c as any).estado === 'prueba' ? ' (en prueba)' : ''}
                                </label>
                              ))}
                            </div>
                          </details>
                        )
                      })()}
                      <button
                        type="button"
                        onClick={() => pausarUsuario(u.uid, !u.pausado)}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                      >
                        {u.pausado ? 'Reactivar' : 'Pausar'}
                      </button>
                      {administradores !== null && (() => {
                        const adm = administradores.find((a) => a.uid === u.uid)
                        return adm ? (
                          <button type="button" onClick={() => quitarAdmin(adm.id, u.email || u.nombre || 'este usuario')} className="px-2.5 py-1.5 rounded-md border border-ink bg-ink text-white font-body text-[11px] font-semibold" title={adm.ultimoAcceso ? `Último acceso: ${new Date(adm.ultimoAcceso).toLocaleString('es-BO')}` : 'Todavía no entró'}>
                            🛡️ Quitar admin
                          </button>
                        ) : (
                          <button type="button" onClick={() => hacerAdmin(u)} disabled={u.pausado} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] disabled:opacity-50" title="Le crea una clave personal para entrar a /admin">
                            🛡️ Hacer admin
                          </button>
                        )
                      })()}
                      <button
                        type="button"
                        onClick={() => marcarUsuarioPrueba(u.uid, !u.esPrueba)}
                        title="Las cuentas de prueba compran sin restricciones de horario"
                        className={`px-2.5 py-1.5 rounded-md border font-body text-[11px] ${u.esPrueba ? 'border-indigo-200 bg-indigo-50 text-indigo-700' : 'border-line'}`}
                      >
                        {u.esPrueba ? 'Quitar prueba' : '🧪 Hacer de prueba'}
                      </button>
                      <button
                        type="button"
                        onClick={() => eliminarUsuario(u.uid)}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon"
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>

                  {pedirProductosUid === u.uid && (() => {
                    const tienda = vendedoresAdmin.find((v) => v.id === u.uid)
                    return (
                      <div className="mt-3 pt-3 border-t border-line">
                        <PedirProductosIA
                          password={password}
                          nombre={tienda?.nombreNegocio || u.nombre}
                          contacto={u.nombre}
                          ciudad={tienda ? buscarCiudad(ciudadDe(tienda)).nombre : undefined}
                          whatsapp={tienda?.whatsapp || u.whatsapp}
                        />
                      </div>
                    )
                  })()}
                  {claveAdminNueva?.uid === u.uid && ((nueva: NonNullable<typeof claveAdminNueva>) => {
                    const texto = `Hola! Te di acceso de administrador a Clasi Click.\nEntrá a ${typeof window !== 'undefined' ? window.location.origin : 'https://www.clasiclick.com'}/admin y poné esta clave:\n${nueva.clave}\n\nEs personal: no la compartas.`
                    return (
                      <div className="mt-3 pt-3 border-t border-line font-body text-xs text-ink">
                        <div className="font-semibold text-teal mb-1">🛡️ Ya es admin. Esta es su clave personal (se muestra una sola vez):</div>
                        <div className="font-mono bg-panelalt border border-line rounded-md px-2.5 py-2 mb-2 break-all select-all">{nueva.clave}</div>
                        <div className="text-[11px] text-inksoft mb-2">Entra a /admin con esta clave en lugar de tu contraseña. Puede hacer todo menos crear o quitar admins. Si la pierde, tocá “Quitar admin” y volvé a hacerlo admin para darle una nueva.</div>
                        <div className="flex flex-wrap gap-2">
                          <button type="button" onClick={() => abrirWhatsapp(nueva.whatsapp || vendedoresAdmin.find((v) => v.id === u.uid)?.whatsapp, texto)} className="px-3 py-1.5 rounded-md border-none bg-[#25D366] text-white text-xs font-semibold">💬 Enviar por WhatsApp</button>
                          <button type="button" onClick={() => navigator.clipboard?.writeText(texto).catch(() => {})} className="px-3 py-1.5 rounded-md border border-line text-xs">📋 Copiar mensaje</button>
                          <button type="button" onClick={() => setClaveAdminNueva(null)} className="px-3 py-1.5 rounded-md border border-line text-xs">Listo</button>
                        </div>
                      </div>
                    )
                  })(claveAdminNueva!)}
                  {passwordUsuario?.uid === u.uid && (
                    <div className="mt-3 pt-3 border-t border-line">
                      {passwordUsuario!.guardada ? (
                        <div className="font-body text-xs text-ink">
                          <div className="text-teal font-semibold mb-1.5">✓ Contraseña cambiada: <span className="font-mono">{passwordUsuario!.valor}</span></div>
                          <div className="text-[11px] text-inksoft mb-2">Desde ahora entra con esta contraseña (la anterior ya no sirve).</div>
                          <div className="flex flex-wrap gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                const vendedor = vendedoresAdmin.find((v) => v.id === u.uid)
                                abrirWhatsapp(u.whatsapp || vendedor?.whatsapp, mensajeAcceso({ nombre: u.nombre, negocio: vendedor?.nombreNegocio, email: u.email, link: null, password: passwordUsuario!.valor, cambio: true }))
                              }}
                              className="px-3 py-1.5 rounded-md border-none bg-[#25D366] text-white font-body text-xs font-semibold"
                            >
                              💬 Enviar por WhatsApp
                            </button>
                            <button type="button" onClick={() => navigator.clipboard?.writeText(passwordUsuario!.valor).catch(() => {})} className="px-3 py-1.5 rounded-md border border-line font-body text-xs">📋 Copiar</button>
                            <button type="button" onClick={() => setPasswordUsuario(null)} className="px-3 py-1.5 rounded-md border border-line font-body text-xs">Listo</button>
                          </div>
                        </div>
                      ) : (
                        <div className="font-body text-xs text-ink">
                          <div className="font-semibold mb-1.5">Nueva contraseña para {u.email || 'este usuario'}</div>
                          <div className="flex flex-wrap gap-2">
                            <input
                              value={passwordUsuario!.valor}
                              onChange={(e) => { const v = e.target.value; setPasswordUsuario((p) => (p ? { ...p, valor: v, error: '' } : p)) }}
                              placeholder="Mínimo 6 caracteres"
                              autoComplete="new-password"
                              className="flex-1 min-w-[160px] px-2.5 py-1.5 rounded-md border border-line bg-panel font-mono text-xs"
                            />
                            <button type="button" onClick={() => setPasswordUsuario((p) => (p ? { ...p, valor: generarPassword(), error: '' } : p))} className="px-3 py-1.5 rounded-md border border-line text-xs">🎲 Generar</button>
                            <button type="button" onClick={guardarPasswordUsuario} disabled={passwordUsuario!.guardando} className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white text-xs font-semibold disabled:opacity-60">
                              {passwordUsuario!.guardando ? 'Guardando...' : 'Guardar contraseña'}
                            </button>
                          </div>
                          {passwordUsuario!.error && <div className="text-maroon mt-1.5">{passwordUsuario!.error}</div>}
                        </div>
                      )}
                    </div>
                  )}

                  {edicionUsuario?.uid === u.uid && (
                    <form onSubmit={guardarEdicionUsuario} className="mt-3 pt-3 border-t border-line grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                      {[
                        { k: 'email', label: 'Email', type: 'email', ph: 'vendedor@gmail.com' },
                        { k: 'nombre', label: 'Nombre', type: 'text', ph: 'Nombre' },
                        { k: 'whatsapp', label: `WhatsApp (${edicionUsuario?.whatsappPais === 'AR' ? '🇦🇷 +54' : '🇧🇴 +591'})`, type: 'tel', ph: edicionUsuario?.whatsappPais === 'AR' ? '1123456789' : '71234567' },
                        { k: 'nombreNegocio', label: edicionUsuario?.tieneTienda ? 'Nombre de la tienda' : 'Nombre de la tienda (la crea)', type: 'text', ph: 'Sin tienda' },
                      ].map((c) => (
                        <label key={c.k} className="font-body text-[11px] text-ink">
                          <span className="block font-semibold mb-1">{c.label}</span>
                          <input
                            type={c.type}
                            value={(edicionUsuario as any)?.[c.k] ?? ''}
                            onChange={(e) => { const v = e.target.value; setEdicionUsuario((prev) => (prev ? { ...prev, [c.k]: v } : prev)) }}
                            placeholder={c.ph}
                            className="w-full px-2.5 py-1.5 rounded-md border border-line bg-panel font-body text-xs"
                          />
                        </label>
                      ))}
                      <label className="font-body text-[11px] text-ink">
                        <span className="block font-semibold mb-1">País del WhatsApp</span>
                        <select
                          value={edicionUsuario?.whatsappPais || 'BO'}
                          onChange={(e) => { const v = e.target.value; setEdicionUsuario((prev) => (prev ? { ...prev, whatsappPais: v } : prev)) }}
                          className="w-full px-2.5 py-1.5 rounded-md border border-line bg-panel font-body text-xs"
                        >
                          {PAISES.map((p) => <option key={p.id} value={p.id}>{p.bandera} {p.nombre} (+{p.codigo})</option>)}
                        </select>
                      </label>
                      <div className="sm:col-span-2 font-body text-[10px] text-inksoft">
                        Si cambiás el email, la persona entra con el nuevo (misma contraseña) y se actualiza en sus productos y anuncios. QR, dirección y horarios de la tienda se editan con 🛍️ Cargar productos → Mi tienda.
                      </div>
                      {errorEdicionUsuario && <div className="sm:col-span-2 font-body text-xs text-maroon">{errorEdicionUsuario}</div>}
                      <div className="sm:col-span-2 flex gap-2">
                        <button type="submit" disabled={guardandoUsuario} className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold disabled:opacity-60">
                          {guardandoUsuario ? 'Guardando...' : 'Guardar cambios'}
                        </button>
                        <button type="button" onClick={() => setEdicionUsuario(null)} className="px-3 py-1.5 rounded-md border border-line font-body text-xs">Cancelar</button>
                      </div>
                    </form>
                  )}

                  {expandido && (
                    <div className="mt-3 pt-3 border-t border-line grid gap-2">
                      {productosDelUsuario.length === 0 && profesionalesDelUsuario.length === 0 && (
                        <div className="font-body text-xs text-inksoft">No tiene productos ni perfiles profesionales publicados.</div>
                      )}
                      {productosDelUsuario.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 font-body text-xs text-ink">
                          <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">Producto</span>
                          {p.nombre} · Bs {Number(p.precio || 0).toLocaleString('es-BO')} · {p.estado || 'activo'}{p.plan === 'premium' && ' · Premium'}
                        </div>
                      ))}
                      {profesionalesDelUsuario.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 font-body text-xs text-ink">
                          <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">Servicio</span>
                          {p.nombre} · {p.especialidad || buscarRubro(p.rubro)?.label || 'Sin rubro'} · {p.estado}{p.plan === 'premium' && ' · Premium'}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
        </div>
      )}

      {tab === 'categorias' && (
        <div>
          <div className="font-body text-sm text-inksoft mb-4">
            Acá se arma el árbol Categoría → Rubro que se usa en el selector de /servicios y en el formulario de publicar servicio.
            Salud, Ingeniería, etc. vienen con rubros de base; podés agregar categorías o rubros nuevos, y mover un rubro si quedó en la categoría que no corresponde.
          </div>

          <form onSubmit={crearCategoria} className="bg-panel border border-line rounded-lg p-4 mb-6 flex gap-2 items-center">
            <input
              value={nuevaCategoriaLabel}
              onChange={(e) => setNuevaCategoriaLabel(e.target.value)}
              placeholder="Nombre de la categoría nueva (ej: Tecnología)"
              className="flex-1 px-3 py-2 rounded-md border border-line font-body text-sm"
            />
            <button
              type="submit"
              disabled={guardandoCategoria}
              className="px-3.5 py-2 rounded-md border-none bg-maroon text-white font-body text-xs font-semibold shrink-0"
            >
              {guardandoCategoria ? 'Agregando...' : '+ Agregar categoría'}
            </button>
          </form>

          {errorCategorias && <div className="font-body text-xs text-maroon mb-4">{errorCategorias}</div>}

          {categorias.map((cat) => (
            <div key={cat.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
              <div className="flex items-center justify-between gap-2 mb-2">
                {renombrandoCategoriaId === cat.id ? (
                  <div className="flex gap-2 flex-1">
                    <input
                      value={nuevoNombreCategoria}
                      onChange={(e) => setNuevoNombreCategoria(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                    />
                    <button onClick={() => renombrarCategoria(cat.id)} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold">
                      Guardar
                    </button>
                    <button onClick={() => { setRenombrandoCategoriaId(null); setNuevoNombreCategoria('') }} className="px-2.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft">
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="font-display text-base font-bold text-ink">{cat.label}</div>
                    <button
                      onClick={() => { setRenombrandoCategoriaId(cat.id); setNuevoNombreCategoria(cat.label) }}
                      className="font-body text-xs text-inksoft underline shrink-0"
                    >
                      Renombrar
                    </button>
                  </>
                )}
              </div>

              <div className="flex flex-col gap-1.5 mb-3">
                {cat.rubros.length === 0 && (
                  <div className="font-body text-xs text-inksoft">Todavía sin rubros.</div>
                )}
                {cat.rubros.map((r) => (
                  <div key={r.id} className="flex items-center justify-between gap-2 bg-panelalt rounded-md px-2.5 py-1.5">
                    <span className="font-body text-sm text-ink">
                      {r.grupo && <span className="text-inksoft">{r.grupo.label} › </span>}
                      {r.label}
                    </span>
                    <select
                      value={cat.id}
                      onChange={(e) => moverRubro(r.id, e.target.value)}
                      className="px-2 py-1 rounded-md border border-line font-body text-[11px] bg-panel shrink-0"
                      title="Mover este rubro a otra categoría"
                    >
                      {categorias.map((c2) => (
                        <option key={c2.id} value={c2.id}>{c2.label}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              {categoriaAbierta === cat.id ? (
                <div className="flex gap-2">
                  <input
                    value={nuevoRubroLabel}
                    onChange={(e) => setNuevoRubroLabel(e.target.value)}
                    placeholder="Nombre del rubro (ej: Kinesiólogo)"
                    className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                  />
                  <button
                    onClick={() => crearRubro(cat.id)}
                    disabled={guardandoRubro}
                    className="px-3 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                  >
                    Guardar
                  </button>
                  <button
                    onClick={() => { setCategoriaAbierta(null); setNuevoRubroLabel('') }}
                    className="px-3 py-1.5 rounded-md border border-line font-body text-xs text-inksoft shrink-0"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { setCategoriaAbierta(cat.id); setNuevoRubroLabel('') }}
                  className="font-body text-xs text-maroon underline"
                >
                  + Agregar rubro en {cat.label}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'zonas' && <AdminZonasEnvio password={password} />}

      {tab === 'categorias-productos' && (
        <div>
          <div className="font-body text-sm text-inksoft mb-4">
            Acá se arma el árbol Categoría › Subcategoría › Rubro que se usa para clasificar los productos (selector en /vender, filtros del catálogo y ficha del producto).
            Viene con el árbol de Mercado Libre (32 categorías, ~3.200 rubros); podés agregar categorías o rubros nuevos, y mover un rubro si quedó en la categoría que no corresponde. Tocá una categoría para ver sus rubros.
          </div>

          <form onSubmit={crearCategoriaProducto} className="bg-panel border border-line rounded-lg p-4 mb-6 flex gap-2 items-center">
            <input
              value={nuevaCategoriaProductoLabel}
              onChange={(e) => setNuevaCategoriaProductoLabel(e.target.value)}
              placeholder="Nombre de la categoría nueva (ej: Electrónica)"
              className="flex-1 px-3 py-2 rounded-md border border-line font-body text-sm"
            />
            <button
              type="submit"
              disabled={guardandoCategoriaProducto}
              className="px-3.5 py-2 rounded-md border-none bg-maroon text-white font-body text-xs font-semibold shrink-0"
            >
              {guardandoCategoriaProducto ? 'Agregando...' : '+ Agregar categoría'}
            </button>
          </form>

          {errorCategoriasProductos && <div className="font-body text-xs text-maroon mb-4">{errorCategoriasProductos}</div>}

          {categoriasProductos.map((cat) => (
            <div key={cat.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
              <div className="flex items-center justify-between gap-2 mb-2">
                {renombrandoCategoriaProductoId === cat.id ? (
                  <div className="flex gap-2 flex-1">
                    <input
                      value={nuevoNombreCategoriaProducto}
                      onChange={(e) => setNuevoNombreCategoriaProducto(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                    />
                    <button onClick={() => renombrarCategoriaProducto(cat.id)} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold">
                      Guardar
                    </button>
                    <button onClick={() => { setRenombrandoCategoriaProductoId(null); setNuevoNombreCategoriaProducto('') }} className="px-2.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft">
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="font-display text-base font-bold text-ink">{cat.label}</div>
                    <button
                      onClick={() => { setRenombrandoCategoriaProductoId(cat.id); setNuevoNombreCategoriaProducto(cat.label) }}
                      className="font-body text-xs text-inksoft underline shrink-0"
                    >
                      Renombrar
                    </button>
                  </>
                )}
              </div>

              <button
                type="button"
                onClick={() => setCategoriaProductoExpandida(categoriaProductoExpandida === cat.id ? null : cat.id)}
                className="font-body text-xs text-teal underline mb-2"
              >
                {categoriaProductoExpandida === cat.id ? '▾ Ocultar rubros' : `▸ Ver rubros (${new Set(cat.rubros.map((r) => r.grupoId).filter(Boolean)).size} subcategorías · ${cat.rubros.length} rubros)`}
              </button>
              {categoriaProductoExpandida === cat.id && (
              <div className="flex flex-col gap-1.5 mb-3">
                {cat.rubros.length === 0 && (
                  <div className="font-body text-xs text-inksoft">Todavía sin rubros.</div>
                )}
                {cat.rubros.map((r, i) => (
                  <div key={r.id + i}>
                  {r.grupoId && r.grupoId !== cat.rubros[i - 1]?.grupoId && (
                    <div className="font-body text-xs font-semibold text-ink mt-2 mb-1">{r.grupo}</div>
                  )}
                  <div className={`flex items-center justify-between gap-2 bg-panelalt rounded-md px-2.5 py-1.5 ${r.grupoId ? 'ml-3' : ''}`}>
                    <span className="font-body text-sm text-ink">{r.label}</span>
                    <select
                      value={cat.id}
                      onChange={(e) => moverRubroProducto(r.id, e.target.value)}
                      className="px-2 py-1 rounded-md border border-line font-body text-[11px] bg-panel shrink-0"
                      title="Mover este rubro a otra categoría"
                    >
                      {categoriasProductos.map((c2) => (
                        <option key={c2.id} value={c2.id}>{c2.label}</option>
                      ))}
                    </select>
                  </div>
                  </div>
                ))}
              </div>
              )}

              {categoriaProductoAbierta === cat.id ? (
                <div className="flex gap-2">
                  <input
                    value={nuevoRubroProductoLabel}
                    onChange={(e) => setNuevoRubroProductoLabel(e.target.value)}
                    placeholder="Nombre del rubro (ej: Mochilas)"
                    className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                  />
                  <button
                    onClick={() => crearRubroProducto(cat.id)}
                    disabled={guardandoRubroProducto}
                    className="px-3 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                  >
                    Guardar
                  </button>
                  <button
                    onClick={() => { setCategoriaProductoAbierta(null); setNuevoRubroProductoLabel('') }}
                    className="px-3 py-1.5 rounded-md border border-line font-body text-xs text-inksoft shrink-0"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { setCategoriaProductoAbierta(cat.id); setNuevoRubroProductoLabel('') }}
                  className="font-body text-xs text-maroon underline"
                >
                  + Agregar rubro en {cat.label}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'consumo' && <ConsumoBase password={password} />}
      {tab === 'base' && <BaseDatos password={password} />}

      {tab === 'metricas' && (
        <div>
          {cargandoMetricas && <div className="font-body text-sm text-inksoft">Cargando métricas...</div>}
          {!cargandoMetricas && metricas?.error && (
            <div className="font-body text-sm text-maroon bg-panelalt border border-line rounded-lg p-3">
              No se pudieron cargar las métricas: {metricas.error}. Probá recargar la pestaña — si sigue igual, revisá los logs de la función /api/admin/metricas en Vercel.
            </div>
          )}
          {!cargandoMetricas && !metricas && (
            <div className="font-body text-sm text-inksoft">Todavía no se cargó nada — probá cambiar de pestaña y volver acá.</div>
          )}
          {!cargandoMetricas && metricas && !metricas.error && (
            <div>
              {metricas.flujoCaja && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">💰 Flujo de caja — Membresías Premium</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Es el único ingreso real y verificado que recibe la plataforma — los pedidos del marketplace se cobran directo al vendedor por su propio QR, no pasan por tu cuenta. Incluye tanto a profesionales como a vendedores de productos con Premium. El histórico de pagos se empezó a registrar recién, así que "histórico" cuenta solo desde ahora en adelante.
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-5">
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos confirmados (histórico)</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.pagosConfirmadosHistorico}</div>
                      <div className="font-body text-[11px] text-inksoft">{bs(metricas.flujoCaja.facturadoHistorico)}</div>
                    </div>
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos este mes</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.pagosEsteMes}</div>
                      <div className="font-body text-[11px] text-inksoft">{bs(metricas.flujoCaja.facturadoEsteMes)}</div>
                    </div>
                    <div className="bg-panel border border-teal rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Premium vigentes ahora</div>
                      <div className="font-display text-lg font-bold text-teal">{metricas.flujoCaja.premiumVigentesAhora}</div>
                      <div className="font-body text-[11px] text-inksoft">Tu ingreso recurrente actual</div>
                    </div>
                    <div className="bg-ochresoft border border-ochre rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos por confirmar</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.porConfirmar}</div>
                      <div className="font-body text-[11px] text-inksoft">Dicen que ya pagaron — revisalos abajo, en "Servicios profesionales"</div>
                    </div>
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Vencen en 7 días</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.venciendoEn7Dias}</div>
                      <div className="font-body text-[11px] text-inksoft">Riesgo de no renovar</div>
                    </div>
                    <div className="bg-maroonsoft border border-maroon rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Proyección próx. 30 días</div>
                      <div className="font-display text-lg font-bold text-maroon">{bs(metricas.flujoCaja.proyeccionProximos30Dias)}</div>
                      <div className="font-body text-[11px] text-inksoft">Si todos los vigentes renuevan</div>
                    </div>
                  </div>
                </>
              )}

              <div className="font-body text-sm font-semibold text-ink mb-1">Evolución en el tiempo</div>
              <div className="font-body text-[11px] text-inksoft mb-3">
                Visitas, vistas, clics y búsquedas se empiezan a contar día a día desde ahora — antes solo se guardaba un total acumulado, sin saber qué día. Pedidos, productos y profesionales publicados sí muestran toda la historia, porque ya tenían fecha guardada.
              </div>

              {metricas.comparativaSemanal && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                  {(
                    [
                      ['Visitas', metricas.comparativaSemanal.estaSemana.visitas, metricas.comparativaSemanal.cambioVisitas],
                      ['Pedidos', metricas.comparativaSemanal.estaSemana.pedidos, metricas.comparativaSemanal.cambioPedidos],
                      ['Facturado', metricas.comparativaSemanal.estaSemana.facturado, metricas.comparativaSemanal.cambioFacturado],
                    ] as [string, number, number | null][]
                  ).map(([label, valor, cambio]) => (
                    <div key={label} className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">{label} · últimos 7 días</div>
                      <div className="font-display text-lg font-bold text-ink">
                        {label === 'Facturado' ? bs(valor) : valor.toLocaleString('es-BO')}
                      </div>
                      {cambio != null && (
                        <div className={`font-body text-[11px] font-semibold ${cambio >= 0 ? 'text-teal' : 'text-maroon'}`}>
                          {cambio >= 0 ? '↑' : '↓'} {Math.abs(cambio)}% vs. semana anterior
                        </div>
                      )}
                    </div>
                  ))}
                  <div className="bg-panel border border-line rounded-lg p-3">
                    <div className="font-body text-[10px] text-inksoft mb-0.5">Conversión aprox. · últimos 7 días</div>
                    <div className="font-display text-lg font-bold text-ink">
                      {metricas.comparativaSemanal.estaSemana.visitas > 0
                        ? `${((metricas.comparativaSemanal.estaSemana.pedidos / metricas.comparativaSemanal.estaSemana.visitas) * 100).toFixed(1)}%`
                        : '—'}
                    </div>
                    <div className="font-body text-[11px] text-inksoft">Pedidos / visitas — si baja, el problema es más de conversión que de tráfico.</div>
                  </div>
                </div>
              )}

              <div className="flex gap-3 mb-3 flex-wrap items-center">
                <div className="flex gap-1 bg-panelalt border border-line rounded-lg p-1">
                  {(['dia', 'mes', 'anio'] as const).map((p) => (
                    <button
                      key={p}
                      onClick={() => setPeriodoMetricas(p)}
                      className={`px-3 py-1.5 rounded-md font-body text-xs font-semibold ${periodoMetricas === p ? 'bg-panel text-ink' : 'text-inksoft'}`}
                    >
                      {p === 'dia' ? 'Por día' : p === 'mes' ? 'Por mes' : 'Por año'}
                    </button>
                  ))}
                </div>
                <select
                  value={campoMetricas}
                  onChange={(e) => setCampoMetricas(e.target.value as keyof typeof CAMPOS_METRICAS)}
                  className="px-3 py-1.5 rounded-lg border border-line font-body text-xs bg-panel"
                >
                  {Object.entries(CAMPOS_METRICAS).map(([campo, info]) => (
                    <option key={campo} value={campo}>{info.label}</option>
                  ))}
                </select>
              </div>

              <div className="bg-panel border border-line rounded-xl p-4 mb-8">
                <GraficoBarras
                  datos={(
                    periodoMetricas === 'dia' ? metricas.serieDiaria
                    : periodoMetricas === 'mes' ? metricas.serieMensual
                    : metricas.serieAnual
                  ).map((p: any) => ({ clave: p.clave, valor: p[campoMetricas] || 0 }))}
                  color={CAMPOS_METRICAS[campoMetricas].color}
                  formatoEtiqueta={(clave) =>
                    periodoMetricas === 'dia' ? clave.slice(5).replace('-', '/')
                    : periodoMetricas === 'mes' ? clave
                    : clave
                  }
                />
              </div>

              {metricas.porDiaSemana?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">¿Qué día se mueve más?</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Suma de toda la historia disponible, agrupada por día de la semana — para decidir, por ejemplo, qué día conviene publicar una oferta o subir precio de un servicio con más demanda.
                  </div>
                  <div className="bg-panel border border-line rounded-xl p-4 mb-8">
                    <GraficoBarras
                      datos={metricas.porDiaSemana.map((p: any) => ({ clave: p.clave, valor: p[campoMetricas] || 0 }))}
                      color={CAMPOS_METRICAS[campoMetricas].color}
                      formatoEtiqueta={(clave) => clave.slice(0, 3)}
                    />
                  </div>
                </>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Usuarios registrados</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    {metricas.usuariosTotal != null ? metricas.usuariosTotal : '—'}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Total facturado</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    Bs {Number(metricas.pedidos?.totalFacturado || 0).toLocaleString('es-BO')}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Pedidos totales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.pedidos?.total ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Productos publicados</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.productos?.total ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Profesionales aprobados</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    {metricas.profesionales?.porEstado?.aprobado ?? 0}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Reseñas totales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalResenas ?? 0}</div>
                </div>
              </div>

              <div className="font-body text-sm font-semibold text-ink mb-3">Pedidos por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.pedidos?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft">{ESTADOS_LABEL[estado]?.texto || estado}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
              </div>

              <div className="font-body text-sm font-semibold text-ink mb-3">Productos por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.productos?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft capitalize">{estado}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
                <div className="bg-ochresoft border border-ochre rounded-lg px-3 py-2">
                  <div className="font-body text-[11px] text-inksoft">premium</div>
                  <div className="font-display text-lg font-bold text-ink">{metricas.productos?.premium ?? 0}</div>
                </div>
              </div>

              {metricas.productosMasVistos?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Productos más vistos</div>
                  <div className="mb-8">
                    {metricas.productosMasVistos.map((p: any, i: number) => (
                      <div key={p.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {p.nombre}</span>
                        <span className="font-body text-xs text-inksoft">{p.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="font-body text-sm font-semibold text-ink mb-3">Anuncios por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.anuncios?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft capitalize">{estado.replace('_', ' ')}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
                <div className="bg-panel border border-line rounded-lg px-3 py-2">
                  <div className="font-body text-[11px] text-inksoft">vistas totales</div>
                  <div className="font-display text-lg font-bold text-ink">{metricas.anuncios?.totalVistas ?? 0}</div>
                </div>
              </div>

              {metricas.anunciosMasVistos?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Anuncios más vistos</div>
                  <div className="mb-8">
                    {metricas.anunciosMasVistos.map((a: any, i: number) => (
                      <div key={a.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {a.titulo}</span>
                        <span className="font-body text-xs text-inksoft">{a.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="grid grid-cols-2 gap-3 mb-8">
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Vistas de perfiles profesionales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalVistas ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Clics a WhatsApp (profesionales)</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalClicsWhatsapp ?? 0}</div>
                </div>
              </div>

              {metricas.profesionalesMasClicWhatsapp?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Profesionales con más contactos por WhatsApp</div>
                  <div className="mb-8">
                    {metricas.profesionalesMasClicWhatsapp.map((p: any, i: number) => (
                      <div key={p.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {p.nombre}</span>
                        <span className="font-body text-xs text-inksoft">{p.clicsWhatsapp} clics · {p.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {metricas.categoriasMasBuscadas?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">Categorías y rubros más buscados</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Para identificar nichos rentables — esto es lo que la gente filtra de verdad, no una suposición.
                  </div>
                  <div className="mb-4">
                    {metricas.categoriasMasBuscadas.map((c: any, i: number) => (
                      <div key={`${c.tipo}-${c.valor}`} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">
                          {i + 1}. {c.valor} <span className="text-inksoft text-xs">({c.tipo === 'producto' ? 'producto' : 'servicio'})</span>
                        </span>
                        <span className="font-body text-xs text-inksoft">{c.clics} búsquedas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="font-body text-[11px] text-inksoft mt-4">
                Todos estos números salen de datos reales de Firestore y Firebase Auth — no hay estimaciones ni cifras infladas.
              </div>
            </div>
          )}
          {!cargandoMetricas && metricas?.error && (
            <div className="font-body text-sm text-maroon">{metricas.error}</div>
          )}
        </div>
      )}
        </main>
      </div>
    </div>
  )
}
// Marketing: el plan de lanzamiento (calendario por red con IA) y las
// campañas / textos de siempre.
function MarketingConPestanas({ password }: { password: string }) {
  const [vista, setVista] = useState<'lanzamiento' | 'contenido' | 'reportes' | 'campanas'>('lanzamiento')
  return (
    <div>
      <div className="flex flex-wrap gap-1.5 mb-4">
        {([['lanzamiento', '🚀 Plan de lanzamiento'], ['contenido', '🎬 Contenido'], ['reportes', '📊 Reportes'], ['campanas', '🎯 Campañas y textos']] as const).map(([id, label]) => (
          <button key={id} type="button" onClick={() => setVista(id)} className={`px-3.5 py-1.5 rounded-full border font-body text-xs font-semibold ${vista === id ? 'bg-ink text-white border-ink' : 'bg-panel text-ink border-line'}`}>{label}</button>
        ))}
      </div>
      {vista === 'lanzamiento' ? <AdminLanzamiento password={password} /> : vista === 'contenido' ? <AdminContenido password={password} /> : vista === 'reportes' ? <AdminReporteMarketing password={password} /> : <AdminMarketing password={password} />}
    </div>
  )
}
