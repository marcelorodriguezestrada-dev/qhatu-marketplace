'use client'

import { useEffect, useRef, useState } from 'react'
import { formatoMoneda, paisDeCiudad } from '@/lib/mercado'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import BannerCuponPromo from '@/components/BannerCuponPromo'
import { usePortada } from '@/lib/portada'
import { agotado, ultimasUnidades } from '@/lib/stock'
import ResenasProducto, { Estrellas } from '@/components/ResenasProducto'
import PreguntasProducto from '@/components/PreguntasProducto'
import dynamic from 'next/dynamic'
import { ProductIcon } from '@/components/ProductIcon'
import { expandirTalles } from '@/data/productos'
import { nombreRubro } from '@/lib/arbolCategorias'
import { useCarrito } from '@/lib/store'
import { useAuth } from '@/lib/auth'
import { useDatoInicial } from '@/components/DatosIniciales'
import { useCategoriasProductos } from '@/lib/useCategoriasProductos'
import { CartDrawer } from '@/components/CartDrawer'
import { track } from '@/lib/tracking'
import { registrarInteres } from '@/lib/interes'
import { registrarVisto } from '@/lib/vistos'

const MapaProfesionales = dynamic(() => import('@/components/MapaProfesionales').then((m) => m.MapaProfesionales), {
  ssr: false,
  loading: () => <div className="w-full h-[260px] rounded-xl border border-line bg-panelalt flex items-center justify-center font-body text-sm text-inksoft">Cargando mapa...</div>,
})

// Precio en la moneda del país de la tienda (Bs en Bolivia, $ en Argentina…).
function bs(n: number, ciudad?: unknown) {
  return formatoMoneda(n, paisDeCiudad(typeof ciudad === 'string' ? ciudad : null))
}

function esNuevo(createdAt?: string) {
  if (!createdAt) return false
  const dias = (Date.now() - new Date(createdAt).getTime()) / 86400000
  return dias <= 7
}

function haceCuanto(createdAt?: string) {
  if (!createdAt) return ''
  const dias = Math.floor((Date.now() - new Date(createdAt).getTime()) / 86400000)
  if (dias <= 0) return 'hoy'
  if (dias === 1) return 'hace 1 día'
  return `hace ${dias} días`
}

const TIPOS_VENTA_LABEL: Record<string, string> = {
  mayorista: 'Mayorista',
  minorista: 'Minorista',
  haceEnvios: 'Hace envíos',
  aceptaCambios: 'Acepta cambios',
  permiteProbar: 'Permite probar',
  pagoQr: 'Pago con QR',
  videollamada: 'Hace videollamada',
  pagoTarjeta: 'Pago con tarjeta',
}

export default function ProductoDetallePage() {
  const params = useParams()
  const id = params?.id as string
  const router = useRouter()
  const { agregar, items } = useCarrito()
  const { usuario } = useAuth()
  const { buscarRubroProducto } = useCategoriasProductos()

  // El layout (servidor) ya trae el producto: la página llega armada (Google).
  const inicial = useDatoInicial<any>('producto')
  const [producto, setProducto] = useState<any>(inicial && inicial.id === id ? inicial : null)
  const [tienda, setTienda] = useState<any>(null)
  const [relacionados, setRelacionados] = useState<any[]>([])
  const portada = usePortada()
  const [cargando, setCargando] = useState(!(inicial && inicial.id === id))
  const [cantidad, setCantidad] = useState(1)
  const [imagenRota, setImagenRota] = useState(false)
  // Galería: foto principal + fotos extra (Premium del vendedor).
  const [fotoIdx, setFotoIdx] = useState(0)
  const toqueX = useRef<number | null>(null)
  const [agregado, setAgregado] = useState(false)
  const [tab, setTab] = useState<'publicacion' | 'tienda'>('publicacion')
  const [carritoAbierto, setCarritoAbierto] = useState(false)
  const [tallaSel, setTallaSel] = useState('')
  const [colorSel, setColorSel] = useState('')
  const [errorSeleccion, setErrorSeleccion] = useState('')
  const [linkCopiado, setLinkCopiado] = useState(false)

  useEffect(() => {
    if (!id) return
    setCargando(!(inicial && inicial.id === id))
    setAgregado(false)
    setCantidad(1)
    setImagenRota(false)
    setFotoIdx(0)
    setTab('publicacion')
    setTallaSel('')
    setColorSel('')
    setErrorSeleccion('')

    fetch(`/api/productos/${id}`)
      .then((r) => r.json())
      .then(async (detalle) => {
        // Si falla pero el servidor ya lo había traído, se queda con ese.
        setProducto((prev: any) => (detalle && !detalle.error && detalle.id ? detalle : prev && !prev.error ? prev : detalle))
        if (!detalle.error) {
          const catalogo = await fetch('/api/productos').then((r) => r.json())
          const otros = (catalogo.productos || []).filter(
            (p: any) => p.rubro === detalle.rubro && p.id !== detalle.id
          )
          setRelacionados(otros.slice(0, 4))
          // El propio vendedor mirando su producto no suma vistas.
          if (!usuario || usuario.uid !== detalle.vendedorId) fetch(`/api/productos/${id}/vista`, { method: 'POST' }).catch(() => {})
          track('ver_producto', { productoId: detalle.id, precio: detalle.precio, categoria: detalle.rubro })
          registrarInteres(detalle.id, 'visto', detalle.nombre)
          registrarVisto(detalle.id)

          if (detalle.vendedorId) {
            const t = await fetch(`/api/vendedores/${detalle.vendedorId}`).then((r) => r.json())
            setTienda(t)
          }
        }
        setCargando(false)
      })
  }, [id])

  // Sin cuenta también se puede: la cuenta se pide recién al pagar (checkout).
  function agregarItemsAlCarrito() {
    if (!producto) return false
    // Si el producto tiene talles/colores cargados, no dejamos avanzar
    // sin elegir uno — si no, no hay forma de saber qué le mandan al
    // vendedor después.
    if (producto.talles?.length > 0 && !tallaSel) {
      setErrorSeleccion('Elegí una talla antes de continuar.')
      return false
    }
    if (producto.colores?.length > 0 && !colorSel) {
      setErrorSeleccion('Elegí un color antes de continuar.')
      return false
    }
    // Stock: no se puede agregar más de lo que queda (el servidor lo
    // vuelve a controlar al comprar).
    if (agotado(producto)) {
      setErrorSeleccion('Este producto está agotado.')
      return false
    }
    const unidadesPedidas = Math.max(cantidad, producto.compraMinima || 1)
    if (typeof producto.stock === 'number' && unidadesPedidas > producto.stock) {
      setErrorSeleccion(`Quedan solo ${producto.stock} unidad${producto.stock === 1 ? '' : 'es'}.`)
      return false
    }
    setErrorSeleccion('')
    const minimo = producto.compraMinima && producto.compraMinima > 1 ? producto.compraMinima : cantidad
    for (let i = 0; i < Math.max(cantidad, minimo); i++) agregar(producto, { talla: tallaSel || undefined, color: colorSel || undefined })
    registrarInteres(producto.id, 'carrito', producto.nombre)
    track('agregar_carrito', { productoId: producto.id, precio: producto.precio, categoria: producto.rubro, talla: tallaSel || '', color: colorSel || '', cantidad: Math.max(cantidad, minimo) })
    return true
  }

  function agregarAlCarrito() {
    if (agregarItemsAlCarrito()) setAgregado(true)
  }

  function comprarAhora() {
    // Directo al pago de ESTA tienda (si el carrito tiene cosas de otras, quedan guardadas).
    if (agregarItemsAlCarrito()) router.push(`/checkout?tienda=${encodeURIComponent(producto?.vendedorId || 'plataforma')}`)
  }

  if (cargando) {
    return <div className="px-5 py-16 text-center font-body text-sm text-inksoft">Cargando...</div>
  }
  if (!producto || producto.error) {
    return (
      <div className="px-5 py-16 text-center">
        <div className="font-body text-sm text-inksoft mb-4">No encontramos este producto.</div>
        <Link href="/" className="font-body text-sm text-maroon underline">Volver al catálogo</Link>
      </div>
    )
  }

  // Si el navegador soporta el selector nativo de compartir (celular,
  // sobre todo), lo usamos — abre directo WhatsApp/Facebook/Instagram/
  // copiar link, como en cualquier app. Si no existe (típico en
  // desktop), copiamos el link al portapapeles como respaldo.
  async function compartirProducto() {
    // Link limpio (sin ?parámetros): la vista previa con foto y precio la
    // arma ./layout.tsx del lado del servidor.
    const url = typeof window !== 'undefined' ? `${window.location.origin}/producto/${id}` : ''
    const texto = `${producto.nombre}${producto.precio ? ` — ${bs(Number(producto.precio), producto.ciudad)}` : ''} en Clasi Click`
    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      try {
        await navigator.share({ title: producto.nombre, text: texto, url })
      } catch {
        // La persona cerró el selector nativo, o el share falló — no hay nada más que hacer.
      }
      return
    }
    try {
      await navigator.clipboard.writeText(url)
      setLinkCopiado(true)
      setTimeout(() => setLinkCopiado(false), 2000)
    } catch {
      // Portapapeles bloqueado (permiso denegado, contexto no seguro) — sin más respaldo razonable.
    }
  }

  const mostrarFoto = producto.imagenUrl && !imagenRota
  const fotos: string[] = [
    ...(mostrarFoto ? [producto.imagenUrl] : []),
    ...(Array.isArray(producto.fotosAdicionales) ? producto.fotosAdicionales.filter((f: unknown) => typeof f === 'string' && f) : []),
  ]
  const tieneDescuento = producto.precioOriginal && producto.precioOriginal > producto.precio
  const rubroProducto = buscarRubroProducto(producto.rubro)
  function volverAlListado() {
    let listado = '/'
    try { listado = sessionStorage.getItem('clasiclick_listado') || '/' } catch {}
    router.push(listado)
  }
  const porcentajeOff = tieneDescuento
    ? Math.round((1 - producto.precio / producto.precioOriginal) * 100)
    : 0
  const linkWhatsappVendedor = tienda?.qrImageUrl || tienda?.cbu ? null : null // el whatsapp de contacto directo del vendedor no se guarda hoy, se usa el chat/checkout

  return (
    <div className="max-w-[960px] mx-auto px-5 py-8">
      <div className="flex items-start justify-between gap-3 mb-5">
        {/* Compu: como Mercado Libre — "Volver al listado | Categoría › Rubro".
            Celular: solo la flecha para volver (la ruta ocupa lugar). */}
        <button type="button" onClick={volverAlListado} className="sm:hidden w-10 h-10 rounded-full border border-line bg-panel flex items-center justify-center text-lg shrink-0" aria-label="Volver">←</button>
        <div className="hidden sm:flex font-body text-[13px] text-inksoft flex-wrap items-center gap-1.5">
          <button type="button" onClick={volverAlListado} className="text-teal hover:underline bg-transparent border-none p-0">Volver al listado</button>
          {rubroProducto && (
            <>
              <span className="text-line">|</span>
              <Link href={`/?categoria=${rubroProducto.categoriaId}`} className="text-teal hover:underline">{rubroProducto.categoriaLabel}</Link>
              {rubroProducto.grupoId && (
                <>
                  <span>›</span>
                  <Link href={`/?grupo=${rubroProducto.grupoId}`} className="text-teal hover:underline">{rubroProducto.grupo}</Link>
                </>
              )}
              {rubroProducto.id !== rubroProducto.grupoId && (
                <>
                  <span>›</span>
                  <Link href={`/?rubro=${producto.rubro}`} className="text-teal hover:underline">{nombreRubro(rubroProducto)}</Link>
                </>
              )}
            </>
          )}
        </div>
        <div className="flex items-center gap-2 shrink-0 relative">
          <button
            type="button"
            onClick={compartirProducto}
            className="w-10 h-10 rounded-full border border-line bg-panel flex items-center justify-center text-lg"
            aria-label="Compartir"
          >
            📤
          </button>
          {linkCopiado && (
            <div className="absolute top-full right-0 mt-1.5 bg-ink text-white font-body text-xs px-2.5 py-1.5 rounded-lg whitespace-nowrap z-10">
              Link copiado
            </div>
          )}
          {/* Acceso directo al carrito desde la ficha del producto — antes
              solo se podía llegar al carrito volviendo al catálogo, y si
              alguien ya se decidió a comprar acá mismo no tenía forma de
              ir directo a pagar. */}
          <button
            type="button"
            onClick={() => setCarritoAbierto(true)}
            className="relative w-10 h-10 rounded-full border border-line bg-panel flex items-center justify-center text-lg"
            aria-label="Ver carrito"
          >
            🛒
            {items.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-maroon text-white text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center">
                {items.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {portada?.cupon && <BannerCuponPromo />}

      {/* Pestañas */}
      <div className="flex gap-1 mb-6 border-b border-line">
        <button
          onClick={() => setTab('publicacion')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'publicacion' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Publicación
        </button>
        <button
          onClick={() => setTab('tienda')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'tienda' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Info. Tienda
        </button>
      </div>

      {tab === 'publicacion' && (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
            <div
              className="bg-panelalt rounded-xl overflow-hidden flex items-center justify-center h-[48vh] md:h-[380px] relative"
              onTouchStart={(e) => { toqueX.current = e.touches[0].clientX }}
              onTouchEnd={(e) => {
                if (toqueX.current == null || fotos.length < 2) return
                const dx = e.changedTouches[0].clientX - toqueX.current
                toqueX.current = null
                if (Math.abs(dx) > 40) setFotoIdx((i) => (i + (dx < 0 ? 1 : -1) + fotos.length) % fotos.length)
              }}
            >
              {fotos.length > 0 ? (
                <img
                  key={fotos[fotoIdx]}
                  src={fotos[fotoIdx]}
                  alt={`${producto.nombre}${fotos.length > 1 ? ` — foto ${fotoIdx + 1} de ${fotos.length}` : ''}`}
                  className="max-w-full max-h-full object-contain"
                  onError={() => { if (fotoIdx === 0 && mostrarFoto) { setImagenRota(true); setFotoIdx(0) } }}
                />
              ) : (
                <ProductIcon kind={producto.icono} size={72} />
              )}
              {fotos.length > 1 && (
                <>
                  <button
                    type="button"
                    onClick={() => setFotoIdx((i) => (i - 1 + fotos.length) % fotos.length)}
                    aria-label="Foto anterior"
                    className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/85 shadow flex items-center justify-center text-ink"
                  >
                    ‹
                  </button>
                  <button
                    type="button"
                    onClick={() => setFotoIdx((i) => (i + 1) % fotos.length)}
                    aria-label="Foto siguiente"
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/85 shadow flex items-center justify-center text-ink"
                  >
                    ›
                  </button>
                  <span className="absolute bottom-2 right-2 bg-ink/70 text-white font-body text-[11px] px-2 py-0.5 rounded-full">
                    {fotoIdx + 1}/{fotos.length}
                  </span>
                </>
              )}
              {tieneDescuento && (
                <span className="absolute top-3 left-3 bg-teal text-white text-xs font-bold px-2.5 py-1 rounded font-body">
                  {porcentajeOff}% OFF
                </span>
              )}
              {!tieneDescuento && esNuevo(producto.createdAt) && (
                <span className="absolute top-3 left-3 bg-ochre text-white text-xs font-bold px-2.5 py-1 rounded font-body">
                  Nuevo
                </span>
              )}
            </div>
            {fotos.length > 1 && (
              <div className="flex gap-2 mt-2.5 overflow-x-auto pb-1">
                {fotos.map((f, i) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFotoIdx(i)}
                    aria-label={`Ver foto ${i + 1}`}
                    className={`shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 ${i === fotoIdx ? 'border-maroon' : 'border-line'} bg-panelalt`}
                  >
                    <img src={f} alt="" loading="lazy" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
            </div>

            <div>
              <div className="font-body text-xs text-inksoft mb-1 flex items-center gap-1.5 flex-wrap">
                <span>{nombreRubro(buscarRubroProducto(producto.rubro)) || producto.categoria || 'Sin rubro'} ·</span>
                {producto.vendedorId ? (
                  <Link
                    href={`/tienda/${producto.vendedorId}`}
                    className="inline-flex items-center gap-1.5 text-ink font-semibold hover:underline"
                  >
                    {(tienda?.logoUrl || producto.tiendaLogoUrl) && (
                      <img
                        src={tienda?.logoUrl || producto.tiendaLogoUrl}
                        alt=""
                        className="w-4 h-4 rounded-full object-cover"
                      />
                    )}
                    {tienda?.nombreNegocio || producto.tiendaNombre || producto.vendedor}
                  </Link>
                ) : (
                  <span>{tienda?.nombreNegocio || producto.tiendaNombre || producto.vendedor}</span>
                )}
                {tienda?.verificado && (
                  <span className="inline-flex items-center gap-1 text-teal font-semibold">
                    ✓ Verificado
                  </span>
                )}
              </div>
              <h1 className="font-display text-2xl font-bold text-ink mb-4">{producto.nombre}</h1>

              {tieneDescuento && (
                <div className="font-body text-sm text-inksoft line-through mb-1">{bs(producto.precioOriginal, producto.ciudad)}</div>
              )}
              {producto.cantidadResenas > 0 && (
                <a href="#resenas" className="flex items-center gap-1.5 mb-1.5 font-body text-xs text-inksoft hover:underline">
                  <Estrellas valor={producto.ratingPromedio || 0} />
                  <span className="text-ink font-semibold">{Number(producto.ratingPromedio || 0).toFixed(1)}</span>
                  ({producto.cantidadResenas} {producto.cantidadResenas === 1 ? 'opinión' : 'opiniones'})
                </a>
              )}
              <div className="flex items-baseline gap-2 mb-6">
                <span className="font-display text-3xl font-bold text-ink">{bs(producto.precio, producto.ciudad)}</span>
                {tieneDescuento && (
                  <span className="font-body text-sm font-semibold text-teal">{porcentajeOff}% OFF</span>
                )}
              </div>
              {agotado(producto) && (
                <div className="-mt-4 mb-5 inline-block font-body text-sm font-bold text-white bg-ink rounded-lg px-3 py-1.5">Agotado</div>
              )}
              {ultimasUnidades(producto) && (
                <div className="-mt-4 mb-5 inline-block font-body text-sm font-bold text-maroon bg-maroonsoft border border-maroon rounded-lg px-3 py-1.5">
                  🔥 ¡{ultimasUnidades(producto) === 1 ? 'Última unidad' : `Últimas ${ultimasUnidades(producto)} unidades`}!
                </div>
              )}

              {producto.descripcionLarga && (
                <div className="mb-6 font-body text-sm text-inksoft whitespace-pre-line">{producto.descripcionLarga}</div>
              )}

              {producto.talles?.length > 0 && (
                <div className="mb-4">
                  <span className="font-body text-sm text-inksoft block mb-1.5">Talla</span>
                  <div className="flex flex-wrap gap-2">
                    {expandirTalles(producto.talles).map((t: string) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => { setTallaSel(t); setErrorSeleccion('') }}
                        className={`px-3.5 py-1.5 rounded-full border font-body text-sm font-medium ${
                          tallaSel === t ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {producto.colores?.length > 0 && (
                <div className="mb-4">
                  <span className="font-body text-sm text-inksoft block mb-1.5">Color</span>
                  <div className="flex flex-wrap gap-2">
                    {producto.colores.map((c: string) => (
                      <button
                        key={c}
                        type="button"
                        onClick={() => { setColorSel(c); setErrorSeleccion('') }}
                        className={`px-3.5 py-1.5 rounded-full border font-body text-sm font-medium ${
                          colorSel === c ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                        }`}
                      >
                        {c}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {errorSeleccion && (
                <div className="font-body text-xs text-maroon mb-4">{errorSeleccion}</div>
              )}

              <div className="flex items-center gap-3 mb-5">
                <span className="font-body text-sm text-inksoft">Cantidad</span>
                <div className="flex items-center gap-2 border border-line rounded-lg px-2 py-1">
                  <button
                    onClick={() => setCantidad((c) => Math.max(1, c - 1))}
                    className="w-7 h-7 border-none bg-transparent text-lg text-ink"
                  >
                    −
                  </button>
                  <span className="font-body text-sm w-6 text-center">{cantidad}</span>
                  <button
                    onClick={() => setCantidad((c) => (typeof producto.stock === 'number' ? Math.min(Math.max(1, producto.stock), c + 1) : c + 1))}
                    className="w-7 h-7 border-none bg-transparent text-lg text-ink"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="flex flex-col gap-2.5 mb-4">
                <button
                  onClick={comprarAhora}
                  disabled={agotado(producto)}
                  className="w-full py-3 rounded-lg border-none bg-ink text-white font-body text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {agotado(producto) ? 'Agotado' : 'Comprar'}
                </button>
                {tienda?.whatsapp && (
                  <a
                    href={`https://wa.me/${tienda.whatsapp.replace(/\D/g, '')}?text=${encodeURIComponent(
                      `Hola! Te escribo por "${producto.nombre}" (${bs(Number(producto.precio), producto.ciudad)}) que vi en Clasi Click.`
                    )}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={() => fetch(`/api/vendedores/${producto.vendedorId}/click-whatsapp`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ productoId: producto.id }) }).catch(() => {})}
                    className="w-full py-3 rounded-lg border-none bg-teal text-white font-body text-sm font-semibold flex items-center justify-center gap-1.5"
                  >
                    💬 Contactar
                  </a>
                )}
                <button
                  onClick={agregarAlCarrito}
                  disabled={agotado(producto)}
                  className="w-full py-3 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {agregado ? 'Agregado ✓' : 'Agregar al carrito'}
                </button>
              </div>

              {agregado && (
                <div className="font-body text-xs text-teal">
                  {cantidad > 1 ? `${cantidad} unidades agregadas.` : 'Producto agregado.'}{' '}
                  <button type="button" onClick={() => setCarritoAbierto(true)} className="underline">Ver mi carrito</button>
                </div>
              )}
            </div>
          </div>

          {/* Detalle del producto */}
          <div className="mt-10 max-w-[600px]">
            <div className="font-display text-lg font-bold text-ink mb-3">Detalle del producto</div>
            <div className="divide-y divide-line border-t border-b border-line">
              {producto.talles?.length > 0 && (
                <div className="py-3 flex items-center gap-3">
                  <span className="text-lg">🏷️</span>
                  <span className="font-body text-sm text-ink"><strong>Talles:</strong> {producto.talles.join(', ')}</span>
                </div>
              )}
              {producto.colores?.length > 0 && (
                <div className="py-3 flex items-center gap-3">
                  <span className="text-lg">🎨</span>
                  <span className="font-body text-sm text-ink"><strong>Colores:</strong> {producto.colores.join(', ')}</span>
                </div>
              )}
              {producto.materiales && (
                <div className="py-3 flex items-center gap-3">
                  <span className="text-lg">✅</span>
                  <span className="font-body text-sm text-ink"><strong>Materiales:</strong> {producto.materiales}</span>
                </div>
              )}
              {producto.compraMinima > 1 && (
                <div className="py-3 flex items-center gap-3">
                  <span className="text-lg">📦</span>
                  <span className="font-body text-sm text-ink"><strong>Compra mínima:</strong> {producto.compraMinima}</span>
                </div>
              )}
              <div className="py-3 flex items-center gap-3">
                <span className="text-lg">📋</span>
                <span className="font-body text-sm text-ink"><strong>Rubro:</strong> {nombreRubro(buscarRubroProducto(producto.rubro)) || producto.categoria || 'Sin rubro'}</span>
              </div>
              <div className="py-3 flex items-center gap-3">
                <span className="text-lg">📅</span>
                <span className="font-body text-sm text-ink"><strong>Publicado:</strong> {haceCuanto(producto.createdAt)}</span>
              </div>
            </div>
          </div>
        </>
      )}

      {tab === 'tienda' && (
        <div className="max-w-[600px]">
          {tienda?.lat != null && tienda?.lng != null && (
            <div className="mb-5">
              <MapaProfesionales
                profesionales={[{ id: producto.vendedorId, nombre: tienda?.nombreNegocio || producto.tiendaNombre || producto.vendedor, rubro: nombreRubro(buscarRubroProducto(producto.rubro)) || producto.categoria || '', lat: tienda.lat, lng: tienda.lng }]}
                centro={{ lat: tienda.lat, lng: tienda.lng }}
              />
            </div>
          )}

          <div className="flex items-center gap-3 mb-4">
            {tienda?.logoUrl && (
              <img src={tienda.logoUrl} alt={producto.vendedor} className="w-14 h-14 rounded-full object-cover border border-line" />
            )}
            <div>
              {producto.vendedorId ? (
                <Link
                  href={`/tienda/${producto.vendedorId}`}
                  className="font-display text-lg font-bold text-ink flex items-center gap-1.5 hover:underline"
                >
                  {tienda?.nombreNegocio || producto.tiendaNombre || producto.vendedor}
                  {tienda?.verificado && <span className="text-teal text-sm">✓</span>}
                </Link>
              ) : (
                <div className="font-display text-lg font-bold text-ink flex items-center gap-1.5">
                  {tienda?.nombreNegocio || producto.tiendaNombre || producto.vendedor}
                  {tienda?.verificado && <span className="text-teal text-sm">✓</span>}
                </div>
              )}
              {tienda?.direccion && <div className="font-body text-xs text-inksoft">{tienda.direccion}</div>}
            </div>
          </div>

          {tienda?.horarios && (
            <div className="mb-5">
              <div className="font-display text-base font-bold text-ink mb-1.5">Horarios</div>
              <div className="font-body text-sm text-inksoft">{tienda.horarios}</div>
            </div>
          )}

          {tienda?.tiposVenta && Object.values(tienda.tiposVenta).some(Boolean) && (
            <div className="mb-5">
              <div className="font-display text-base font-bold text-ink mb-2">Tipo de ventas</div>
              <div className="flex flex-wrap gap-2">
                {Object.entries(tienda.tiposVenta)
                  .filter(([, v]) => v)
                  .map(([k]) => (
                    <span key={k} className="bg-tealsoft text-teal font-body text-xs font-semibold px-2.5 py-1 rounded-full">
                      ✓ {TIPOS_VENTA_LABEL[k] || k}
                    </span>
                  ))}
              </div>
            </div>
          )}

          {!tienda?.direccion && !tienda?.horarios && !tienda?.lat && (
            <div className="font-body text-sm text-inksoft">
              Este vendedor todavía no cargó información de su tienda.
            </div>
          )}
        </div>
      )}

      <PreguntasProducto productoId={String(id)} vendedorId={producto.vendedorId} />

      <ResenasProducto productoId={String(id)} />

      {relacionados.length > 0 && (
        <div className="mt-14">
          <div className="font-display text-lg font-bold text-ink mb-4">Más publicaciones del vendedor</div>
          <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))' }}>
            {relacionados.map((r) => (
              <Link
                key={r.id}
                href={`/producto/${r.id}`}
                className="bg-panel border border-line rounded-lg overflow-hidden"
              >
                <div className="bg-panelalt h-32 flex items-center justify-center text-maroon overflow-hidden">
                  {r.imagenUrl ? (
                    <img src={r.thumbUrl || r.imagenUrl} alt={r.nombre} loading="lazy" decoding="async" className="w-full h-full object-contain p-2" />
                  ) : (
                    <ProductIcon kind={r.icono} size={30} />
                  )}
                </div>
                <div className="p-3">
                  <div className="font-body text-xs text-ink mb-1 leading-snug">{r.nombre}</div>
                  {/* A propósito no se muestra el precio acá — misma
                      lógica que en la grilla principal (ProductCard):
                      genera curiosidad y hace falta entrar al producto
                      para verlo. */}
                  <div className="font-body text-[11px] font-semibold text-maroon">Ver precio</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {carritoAbierto && <CartDrawer onClose={() => setCarritoAbierto(false)} />}
    </div>
  )
}