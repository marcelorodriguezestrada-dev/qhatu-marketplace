'use client'

import { buscarCiudad, ciudadDe, type CiudadId } from '@/data/ciudades'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Producto } from '@/data/productos'
import { ProductIcon } from './ProductIcon'
import { useCarrito } from '@/lib/store'
import { useFavoritos } from '@/lib/favoritos'
import { useAuth } from '@/lib/auth'
import { track } from '@/lib/tracking'
import { agotado, ultimasUnidades } from '@/lib/stock'
import { registrarInteres } from '@/lib/interes'

function esNuevo(createdAt?: string) {
  if (!createdAt) return false
  const dias = (Date.now() - new Date(createdAt).getTime()) / 86400000
  return dias <= 7
}

function CorazonIcon({ relleno }: { relleno: boolean }) {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill={relleno ? '#A23B2E' : 'none'} stroke={relleno ? '#A23B2E' : '#1E2233'} strokeWidth="1.8">
      <path d="M12 20s-7-4.35-9.5-8.5C.8 8.2 2.3 5 5.5 5c2 0 3.3 1 4.5 2.5C11.2 6 12.5 5 14.5 5 17.7 5 19.2 8.2 21.5 11.5 19 15.65 12 20 12 20z" strokeLinejoin="round" />
    </svg>
  )
}

// ciudadComprador: si el producto es de otra ciudad (tienda que envía a
// todo Bolivia), muestra "🚚 Envía desde …".
export function ProductCard({ p, ciudadComprador }: { p: Producto; ciudadComprador?: CiudadId }) {
  const { agregar } = useCarrito()
  const { esFavorito, toggleFavorito } = useFavoritos()
  const { usuario } = useAuth()
  const router = useRouter()
  const [imagenRota, setImagenRota] = useState(false)
  const mostrarFoto = (p.thumbUrl || p.imagenUrl) && !imagenRota
  const favorito = esFavorito(p.id)

  // Navegar y armar el carrito es libre, sin cuenta (el carrito se guarda
  // en el navegador): la cuenta se pide recién al pagar, en el checkout.
  function agregarAlCarrito() {
    // Si tiene talles o colores para elegir, no lo agregamos a ciegas
    // desde la grilla — lo mandamos a la ficha del producto, que es
    // donde están los selectores.
    if ((p.talles?.length ?? 0) > 0 || (p.colores?.length ?? 0) > 0) {
      router.push(`/producto/${p.id}`)
      return
    }
    if (sinStock) return
    agregar(p)
    registrarInteres(p.id, 'carrito', p.nombre)
    track('agregar_carrito', { productoId: p.id, precio: p.precio, categoria: p.rubro, desde: 'grilla' })
  }

  const sinStock = agotado(p)
  const quedan = ultimasUnidades(p)
  const tieneDescuento = p.precioOriginal && p.precioOriginal > p.precio
  const porcentajeOff = tieneDescuento
    ? Math.round((1 - p.precio / (p.precioOriginal as number)) * 100)
    : 0

  return (
    <div className="bg-panel border border-line rounded-xl overflow-hidden flex flex-col transition-shadow hover:shadow-md">
      <Link href={`/producto/${p.id}`} className="bg-panelalt flex justify-center items-center text-maroon overflow-hidden h-36 sm:h-48 relative">
        {mostrarFoto ? (
          <img
            src={p.thumbUrl || p.imagenUrl}
            alt={p.nombre}
            loading="lazy"
            decoding="async"
            className="w-full h-full object-contain p-2"
            onError={() => setImagenRota(true)}
          />
        ) : (
          <ProductIcon kind={p.icono} size={40} />
        )}
        {p.plan === 'premium' && (
          <span className="absolute top-2 left-2 bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded font-body">
            Premium
          </span>
        )}
        {tieneDescuento && (
          <span className="absolute top-2 left-2 bg-teal text-white text-[10px] font-bold px-1.5 py-0.5 rounded font-body">
            {porcentajeOff}% OFF
          </span>
        )}
        {!tieneDescuento && esNuevo(p.createdAt) && (
          <span className="absolute top-2 left-2 bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded font-body">
            Nuevo
          </span>
        )}
        {sinStock && (
          <span className="absolute inset-x-0 bottom-0 bg-ink/80 text-white text-center text-[11px] font-bold py-1 font-body">Agotado</span>
        )}
        {quedan && (
          <span className="absolute inset-x-0 bottom-0 bg-maroon/90 text-white text-center text-[11px] font-bold py-1 font-body">
            ¡{quedan === 1 ? 'Última unidad' : `Últimas ${quedan} unidades`}!
          </span>
        )}
        <button
          onClick={(e) => {
            e.preventDefault()
            if (!favorito) track('guardar_favorito', { productoId: p.id, precio: p.precio, categoria: p.rubro })
            toggleFavorito(p.id)
          }}
          aria-label={favorito ? 'Quitar de favoritos' : 'Agregar a favoritos'}
          className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/90 flex items-center justify-center shadow-sm"
        >
          <CorazonIcon relleno={favorito} />
        </button>
      </Link>
      <div className="p-2.5 sm:p-4 flex flex-col flex-1">
        <div className="flex items-center gap-1.5 mb-0.5 sm:mb-1">
          {p.tiendaLogoUrl && (
            <img src={p.tiendaLogoUrl} alt="" loading="lazy" decoding="async" className="w-4 h-4 rounded-full object-cover shrink-0" />
          )}
          {p.vendedorId ? (
            <Link
              href={`/tienda/${p.vendedorId}`}
              className="text-[10px] sm:text-[11px] text-inksoft font-body truncate hover:underline hover:text-maroon"
            >
              {p.tiendaNombre || p.vendedor}
            </Link>
          ) : (
            <div className="text-[10px] sm:text-[11px] text-inksoft font-body truncate">{p.tiendaNombre || p.vendedor}</div>
          )}
        </div>
        <Link href={`/producto/${p.id}`} className="font-body text-[13px] sm:text-[14px] font-medium text-ink mb-1.5 sm:mb-2 flex-1 leading-snug hover:underline">
          {p.nombre}
        </Link>
        {ciudadComprador && ciudadDe(p as any) !== ciudadComprador && (
          <div className="font-body text-[10px] sm:text-[11px] text-teal font-semibold mb-1.5">🚚 Envía desde {buscarCiudad(ciudadDe(p as any)).nombre}</div>
        )}

        {p.descripcionCorta && (
          <div className="font-body text-[12px] text-inksoft mb-2 truncate">{p.descripcionCorta}</div>
        )}

        {(p.cantidadResenas || 0) > 0 && (
          <div className="flex items-center gap-1 mb-1.5 font-body text-[11px] text-inksoft">
            <span className="text-ochre">★</span>
            <span className="font-semibold text-ink">{Number(p.ratingPromedio || 0).toFixed(1)}</span>
            <span>({p.cantidadResenas})</span>
          </div>
        )}

        {/* A propósito no se muestra ningún precio acá en la grilla — la
            idea por ahora es generar curiosidad y que haga falta entrar
            al producto para verlo. El precio real sigue mostrándose
            en /producto/[id] y, obviamente, en el carrito antes de
            pagar — no queda oculto en ningún momento de la compra. */}
        <Link
          href={`/producto/${p.id}`}
          className="font-body text-[12px] sm:text-[13px] font-semibold text-maroon mb-2 sm:mb-3 inline-flex items-center gap-1 hover:underline"
        >
          Ver precio
          {tieneDescuento && (
            <span className="font-body text-[11px] sm:text-[12px] font-semibold text-teal">· {porcentajeOff}% OFF</span>
          )}
        </Link>

        <button
          onClick={agregarAlCarrito}
          disabled={sinStock}
          className="w-full py-1.5 sm:py-2 rounded-md bg-maroon text-white font-body text-[11px] sm:text-xs font-semibold disabled:bg-inksoft/40 disabled:cursor-not-allowed"
        >
          {sinStock ? 'Agotado' : 'Agregar al carrito'}
        </button>
      </div>
    </div>
  )
}
