import { NextRequest, NextResponse } from 'next/server'
import { getDb, getUsuarioDesdeRequest } from '@/lib/firebaseAdmin'

export const dynamic = 'force-dynamic'

// GET: perfil público de un producto, para la página de detalle.
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const db = getDb()
    const doc = await db.collection('productos').doc(params.id).get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }
    return NextResponse.json({ id: doc.id, ...doc.data() })
  } catch (err) {
    console.error('GET /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo cargar el producto.' }, { status: 500 })
  }
}

// DELETE: solo el usuario que publicó el producto puede borrarlo.
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const usuario = await getUsuarioDesdeRequest(req)
  const password = req.headers.get('x-admin-password')
  const esAdmin = !!password && password === process.env.ADMIN_PASSWORD
  if (!usuario && !esAdmin) {
    return NextResponse.json({ error: 'Necesitás iniciar sesión.' }, { status: 401 })
  }
  try {
    const db = getDb()
    const ref = db.collection('productos').doc(params.id)
    const doc = await ref.get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }
    if (!esAdmin && doc.data()?.vendedorId !== usuario?.uid) {
      return NextResponse.json({ error: 'Ese producto no te pertenece.' }, { status: 403 })
    }
    await ref.delete()
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('DELETE /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo borrar el producto.' }, { status: 500 })
  }
}

// PATCH: editar precio/nombre/categoría — mismo chequeo de dueño.
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const usuario = await getUsuarioDesdeRequest(req)
  const password = req.headers.get('x-admin-password')
  const esAdmin = !!password && password === process.env.ADMIN_PASSWORD

  if (!usuario && !esAdmin) {
    return NextResponse.json({ error: 'Necesitás iniciar sesión.' }, { status: 401 })
  }

  try {
    const db = getDb()
    const ref = db.collection('productos').doc(params.id)
    const doc = await ref.get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }

    if (!esAdmin && doc.data()?.vendedorId !== usuario?.uid) {
      return NextResponse.json({ error: 'Ese producto no te pertenece.' }, { status: 403 })
    }

    const body = await req.json()
    const { nombre, categoria, precio, icono, imagenUrl, precioOriginal, estado, descripcionCorta, descripcionLarga, thumbUrl,
      vendedor, direccion, zona, horarios, tipoVentas, tiendaAprobada, verificado, rating } = body
    const cambios: Record<string, unknown> = {}

    if (nombre !== undefined) cambios.nombre = nombre
    if (categoria !== undefined) cambios.categoria = categoria
    if (precio !== undefined) cambios.precio = precio
    if (icono !== undefined) cambios.icono = icono
    if (imagenUrl !== undefined) cambios.imagenUrl = imagenUrl
    if (thumbUrl !== undefined) cambios.thumbUrl = thumbUrl
    if (precioOriginal !== undefined) cambios.precioOriginal = precioOriginal
    if (descripcionCorta !== undefined) cambios.descripcionCorta = descripcionCorta
    if (descripcionLarga !== undefined) cambios.descripcionLarga = descripcionLarga
    if (vendedor !== undefined) cambios.vendedor = vendedor
    if (direccion !== undefined) cambios.direccion = direccion
    if (zona !== undefined) cambios.zona = zona
    if (horarios !== undefined) cambios.horarios = horarios
    if (tipoVentas !== undefined) cambios.tipoVentas = tipoVentas
    if (thumbUrl !== undefined) cambios.thumbUrl = thumbUrl
    if (estado !== undefined) {
      if (!esAdmin) {
        return NextResponse.json({ error: 'Solo el administrador puede cambiar el estado del producto.' }, { status: 403 })
      }
      if (!['activo', 'pendiente', 'rechazado', 'oculto'].includes(estado)) {
        return NextResponse.json({ error: 'Estado inválido.' }, { status: 400 })
      }
      cambios.estado = estado
    }

    // Campos que solo el admin puede forzar/modificar
    if (tiendaAprobada !== undefined) {
      if (!esAdmin) return NextResponse.json({ error: 'Solo el administrador puede cambiar el estado de la tienda.' }, { status: 403 })
      cambios.tiendaAprobada = tiendaAprobada
    }
    if (verificado !== undefined) {
      if (!esAdmin) return NextResponse.json({ error: 'Solo el administrador puede marcar verificado.' }, { status: 403 })
      cambios.verificado = verificado
    }
    if (rating !== undefined) {
      if (!esAdmin) return NextResponse.json({ error: 'Solo el administrador puede establecer la calificación.' }, { status: 403 })
      cambios.rating = rating
    }

    cambios.updatedAt = new Date().toISOString()
    await ref.update(cambios)
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('PATCH /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo actualizar el producto.' }, { status: 500 })
  }
}
