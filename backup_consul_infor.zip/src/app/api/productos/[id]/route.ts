import { NextRequest, NextResponse } from 'next/server'
import { getDb, getUsuarioDesdeRequest } from '@/lib/firebaseAdmin'

export const dynamic = 'force-dynamic'

// GET: perfil público de un producto, para la página de detalle.
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const db = getDb()
    const doc = await db.collection('productos').doc(params.id).get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }
    return NextResponse.json({ id: doc.id, ...doc.data() })
  } catch (err) {
    console.error('GET /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo cargar el producto.' }, { status: 500 })
  }
}

// DELETE: solo el usuario que publicó el producto puede borrarlo.
export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const usuario = await getUsuarioDesdeRequest(req)
  const password = req.headers.get('x-admin-password')
  const esAdmin = !!password && password === process.env.ADMIN_PASSWORD
  if (!usuario && !esAdmin) {
    return NextResponse.json({ error: 'Necesitás iniciar sesión.' }, { status: 401 })
  }
  try {
    const db = getDb()
    const ref = db.collection('productos').doc(params.id)
    const doc = await ref.get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }
    if (!esAdmin && doc.data()?.vendedorId !== usuario?.uid) {
      return NextResponse.json({ error: 'Ese producto no te pertenece.' }, { status: 403 })
    }
    await ref.delete()
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('DELETE /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo borrar el producto.' }, { status: 500 })
  }
}

// PATCH: editar precio/nombre/categoría — mismo chequeo de dueño.
export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const usuario = await getUsuarioDesdeRequest(req)
  const password = req.headers.get('x-admin-password')
  const esAdmin = !!password && password === process.env.ADMIN_PASSWORD

  if (!usuario && !esAdmin) {
    return NextResponse.json({ error: 'Necesitás iniciar sesión.' }, { status: 401 })
  }

  try {
    const db = getDb()
    const ref = db.collection('productos').doc(params.id)
    const doc = await ref.get()
    if (!doc.exists) {
      return NextResponse.json({ error: 'Producto no encontrado.' }, { status: 404 })
    }

    if (!esAdmin && doc.data()?.vendedorId !== usuario?.uid) {
      return NextResponse.json({ error: 'Ese producto no te pertenece.' }, { status: 403 })
    }

    const body = await req.json()
    const { nombre, rubro, publico, precio, icono, imagenUrl, precioOriginal, estado, descripcionCorta, descripcionLarga, thumbUrl, talles, colores, materiales, compraMinima } = body
    const cambios: Record<string, unknown> = {}

    if (nombre !== undefined) cambios.nombre = nombre
    if (rubro !== undefined) cambios.rubro = rubro
    if (publico !== undefined) {
      cambios.publico = ['mujer', 'hombre', 'ninos', 'unisex'].includes(publico) ? publico : 'unisex'
    }
    if (precio !== undefined) cambios.precio = precio
    if (icono !== undefined) cambios.icono = icono
    if (imagenUrl !== undefined) cambios.imagenUrl = imagenUrl
    if (thumbUrl !== undefined) cambios.thumbUrl = thumbUrl
    if (precioOriginal !== undefined) cambios.precioOriginal = precioOriginal
    if (descripcionCorta !== undefined) cambios.descripcionCorta = descripcionCorta
    if (descripcionLarga !== undefined) cambios.descripcionLarga = descripcionLarga
    if (talles !== undefined) cambios.talles = Array.isArray(talles) ? talles.filter(Boolean) : []
    if (colores !== undefined) cambios.colores = Array.isArray(colores) ? colores.filter(Boolean) : []
    if (materiales !== undefined) cambios.materiales = materiales
    if (compraMinima !== undefined) cambios.compraMinima = Math.max(1, Number(compraMinima) || 1)
    if (estado !== undefined) {
      if (!esAdmin) {
        return NextResponse.json({ error: 'Solo el administrador puede cambiar el estado del producto.' }, { status: 403 })
      }
      if (!['activo', 'pendiente', 'rechazado', 'oculto'].includes(estado)) {
        return NextResponse.json({ error: 'Estado inválido.' }, { status: 400 })
      }
      cambios.estado = estado
    }

    cambios.updatedAt = new Date().toISOString()
    await ref.update(cambios)
    return NextResponse.json({ ok: true })
  } catch (err) {
    console.error('PATCH /api/productos/[id]', err)
    return NextResponse.json({ error: 'No se pudo actualizar el producto.' }, { status: 500 })
  }
}
