'use client'

import { useEffect, useState } from 'react'
import { ServiceIcon } from '@/components/ServiceIcon'
import { GraficoBarras } from '@/components/GraficoBarras'
import { useCategorias } from '@/lib/useCategorias'
import { useCategoriasProductos } from '@/lib/useCategoriasProductos'
import { labelPublicoProducto } from '@/data/publicoProducto'
import { DIAS_SEMANA, INTERVALOS_TURNO, BloqueHorario } from '@/data/turnos'
import { calcularNuevaVigencia } from '@/lib/planPremium'
import { calcularFranja, ordenarPorCercania, DEPOSITO } from '@/lib/reparto'
import { labelTipoAnuncio } from '@/data/anuncios'
import { parsearAnunciosWhatsapp, AnuncioParseado, mensajeInvitacionAnuncio } from '@/lib/parsearAnunciosWhatsapp'

function bs(n: number) {
  return 'Bs ' + n.toLocaleString('es-BO')
}

const ESTADOS_LABEL: Record<string, { texto: string; color: string }> = {
  verificando_stock: { texto: 'Verificando stock con el vendedor', color: 'text-ochre' },
  pendiente_pago: { texto: 'Esperando que pague', color: 'text-inksoft' },
  informado_pago: { texto: 'Dice que ya pagó — revisar', color: 'text-ochre' },
  pagado: { texto: 'Pagado', color: 'text-teal' },
  en_preparacion: { texto: 'En preparación', color: 'text-indigo-600' },
  en_entrega: { texto: 'En entrega', color: 'text-amber-600' },
  entregado: { texto: 'Entregado', color: 'text-emerald-600' },
  cancelado: { texto: 'Cancelado', color: 'text-red-600' },
}

const ICONOS_SERVICIO = ['abogado', 'contador', 'electricista', 'enfermera', 'estilista', 'ingeniero', 'manicurista', 'medico', 'odontologo', 'oftalmologo', 'pintor', 'plomero', 'profesor', 'otro']

// Qué números se pueden graficar en la línea de tiempo de Métricas, y
// cómo mostrar cada uno (etiqueta corta para el selector, color de la
// barra, y si es plata para formatear en Bs en vez de un número pelado).
const CAMPOS_METRICAS = {
  visitas: { label: 'Visitas al sitio', color: '#1a7f6e' },
  vistasProductos: { label: 'Vistas de productos', color: '#8a5a2f' },
  vistasProfesionales: { label: 'Vistas de profesionales', color: '#8a5a2f' },
  vistasAnuncios: { label: 'Vistas de anuncios', color: '#8a5a2f' },
  clicsWhatsapp: { label: 'Clics a WhatsApp', color: '#25a244' },
  busquedasProductos: { label: 'Búsquedas de productos', color: '#b08900' },
  busquedasServicios: { label: 'Búsquedas de servicios', color: '#b08900' },
  pedidos: { label: 'Pedidos', color: '#7a1f2b' },
  facturado: { label: 'Facturado (Bs)', color: '#7a1f2b', esPlata: true },
  productosPublicados: { label: 'Productos publicados', color: '#3a5a8a' },
  profesionalesPublicados: { label: 'Profesionales publicados', color: '#3a5a8a' },
  anunciosPublicados: { label: 'Anuncios publicados', color: '#3a5a8a' },
} as const

function BadgeRiesgoIA({ moderacionIA }: { moderacionIA: { riesgo: string; motivo: string } | null | undefined }) {
  if (!moderacionIA) return null
  const estilos: Record<string, string> = {
    alto: 'bg-maroonsoft text-maroon border-maroon',
    medio: 'bg-ochresoft text-ochre border-ochre',
    bajo: 'bg-tealsoft text-teal border-teal',
  }
  const clase = estilos[moderacionIA.riesgo] || 'bg-panelalt text-inksoft border-line'
  return (
    <div className={`inline-flex items-center gap-1 border rounded-full px-2 py-0.5 text-[10px] font-semibold font-body mt-1 ${clase}`} title={moderacionIA.motivo}>
      IA: riesgo {moderacionIA.riesgo}
    </div>
  )
}

export default function AdminPage() {
  const [password, setPassword] = useState('')
  const [autenticado, setAutenticado] = useState(false)
  const [solicitudes, setSolicitudes] = useState<any[]>([])
  const [cargandoSolicitudes, setCargandoSolicitudes] = useState(false)
  const [error, setError] = useState('')
  const [cargando, setCargando] = useState(false)
  const [tab, setTab] = useState<'pedidos' | 'productos' | 'servicios' | 'anuncios' | 'usuarios' | 'reparto' | 'banners' | 'categorias' | 'categorias-productos' | 'metricas'>('pedidos')
  const { categorias, buscarRubro, recargar: recargarCategorias } = useCategorias()
  const { categorias: categoriasProductos, buscarRubroProducto, recargar: recargarCategoriasProductos } = useCategoriasProductos()

  const [pedidos, setPedidos] = useState<any[]>([])
  const [subiendoFotoEntregaId, setSubiendoFotoEntregaId] = useState<string | null>(null)
  const [productos, setProductos] = useState<any[]>([])
  const [profesionales, setProfesionales] = useState<any[]>([])
  const [usuarios, setUsuarios] = useState<any[]>([])
  const [anuncios, setAnuncios] = useState<any[]>([])
  const [banners, setBanners] = useState<any[]>([])
  const [subiendoBanner, setSubiendoBanner] = useState(false)
  const [bannerLinkNuevo, setBannerLinkNuevo] = useState('')
  const [macheos, setMacheos] = useState<any>(null)
  const [cargandoMacheos, setCargandoMacheos] = useState(false)

  // Análisis con IA de los anuncios que el macheo exacto por rubro no
  // resolvió, y envío puntual de la sugerencia a ambas partes.
  const [sugerenciasIA, setSugerenciasIA] = useState<any[] | null>(null)
  const [analizandoIA, setAnalizandoIA] = useState(false)
  const [mensajeAnalisisIA, setMensajeAnalisisIA] = useState('')
  const [enviandoSugerenciaId, setEnviandoSugerenciaId] = useState<string | null>(null)
  const [sugerenciasEnviadas, setSugerenciasEnviadas] = useState<Set<string>>(new Set())

  async function analizarMatcheosIA() {
    setAnalizandoIA(true)
    setMensajeAnalisisIA('')
    try {
      const res = await fetch('/api/admin/macheos/analizar-ia', {
        method: 'POST',
        headers: { 'x-admin-password': password },
      })
      const data = await res.json()
      if (data.error) {
        setMensajeAnalisisIA(data.error)
        setSugerenciasIA([])
        return
      }
      setSugerenciasIA(data.sugerencias || [])
      setMensajeAnalisisIA(data.mensaje || (data.sugerencias?.length ? '' : 'La IA no encontró ninguna coincidencia razonable por ahora.'))
    } finally {
      setAnalizandoIA(false)
    }
  }

  async function sugerirAAmbasPartes(s: any) {
    const clave = `${s.anuncioId}:${s.profesionalId}`
    setEnviandoSugerenciaId(clave)
    try {
      const res = await fetch('/api/admin/macheos/sugerir', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ anuncioId: s.anuncioId, profesionalId: s.profesionalId, motivo: s.motivo }),
      })
      const data = await res.json()
      if (!data.error) {
        setSugerenciasEnviadas((prev) => new Set(prev).add(clave))
      }
    } finally {
      setEnviandoSugerenciaId(null)
    }
  }
  const [anuncioExpandido, setAnuncioExpandido] = useState<string | null>(null)
  const [cargandoUsuarios, setCargandoUsuarios] = useState(false)
  // uid del usuario cuya fila está desplegada mostrando el detalle de
  // sus productos y perfiles profesionales (null = ninguna abierta).
  const [usuarioExpandidoId, setUsuarioExpandidoId] = useState<string | null>(null)
  const [buscarUsuario, setBuscarUsuario] = useState('')
  const [metricas, setMetricas] = useState<any>(null)
  const [cargandoMetricas, setCargandoMetricas] = useState(false)
  // Línea de tiempo de la pestaña Métricas: qué período se ve
  // (día/mes/año) y qué número se está graficando.
  const [periodoMetricas, setPeriodoMetricas] = useState<'dia' | 'mes' | 'anio'>('dia')
  const [campoMetricas, setCampoMetricas] = useState<keyof typeof CAMPOS_METRICAS>('visitas')

  const resumen = {
    pedidosTotal: pedidos.length,
    pedidosPagados: pedidos.filter((p) => p.estado === 'pagado' || p.estado === 'en_preparacion' || p.estado === 'en_entrega' || p.estado === 'entregado').length,
    productosActivos: productos.filter((p) => p.estado === 'activo').length,
    productosPremium: productos.filter((p) => p.plan === 'premium').length,
    profesionalesTotal: profesionales.length,
  }

  // Formulario de alta de profesional
  const [nombre, setNombre] = useState('')
  const [emailProfesional, setEmailProfesional] = useState('')
  // Id de la solicitud para la que se está escribiendo la nota de "pedir
  // más info" en este momento (null = ninguna abierta), y el texto que
  // se va tipeando ahí.
  const [pidiendoInfoId, setPidiendoInfoId] = useState<string | null>(null)
  const [notaPidiendoInfo, setNotaPidiendoInfo] = useState('')
  const [rubro, setRubro] = useState('')
  const [categoriaSel, setCategoriaSel] = useState('')
  const [especialidad, setEspecialidad] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [zona, setZona] = useState('')
  const [direccion, setDireccion] = useState('')
  const [lat, setLat] = useState('')
  const [lng, setLng] = useState('')
  const [whatsapp, setWhatsapp] = useState('')
  const [instagram, setInstagram] = useState('')
  const [icono, setIcono] = useState(ICONOS_SERVICIO[0])
  const [imagenUrl, setImagenUrl] = useState('')
  const [subiendoImagen, setSubiendoImagen] = useState(false)
  const [precio, setPrecio] = useState('')
  const [experiencia, setExperiencia] = useState('')
  const [plan, setPlan] = useState<'basico' | 'premium'>('basico')
  const [publicando, setPublicando] = useState(false)
  const [errorForm, setErrorForm] = useState('')
  // null = formulario en modo "publicar nuevo". Con un id, el mismo
  // formulario pasa a modo edición de ese profesional ya existente.
  const [profesionalEditandoId, setProfesionalEditandoId] = useState<string | null>(null)
  const [editHorarioBloques, setEditHorarioBloques] = useState<BloqueHorario[]>([])
  const [editNuevoBloqueDias, setEditNuevoBloqueDias] = useState<number[]>([])
  const [editNuevoBloqueDesde, setEditNuevoBloqueDesde] = useState('09:00')
  const [editNuevoBloqueHasta, setEditNuevoBloqueHasta] = useState('18:00')
  const [editNuevoBloqueIntervalo, setEditNuevoBloqueIntervalo] = useState(60)
  const [editNuevoBloqueTodoElDia, setEditNuevoBloqueTodoElDia] = useState(false)
  const [guardandoHorarioAdmin, setGuardandoHorarioAdmin] = useState(false)
  const [horarioAdminGuardado, setHorarioAdminGuardado] = useState(false)

  // Pestaña "Categorías": alta de categoría nueva, alta de rubro dentro
  // de una categoría, y reubicar un rubro existente a otra categoría.
  const [nuevaCategoriaLabel, setNuevaCategoriaLabel] = useState('')
  const [guardandoCategoria, setGuardandoCategoria] = useState(false)
  const [errorCategorias, setErrorCategorias] = useState('')
  const [categoriaAbierta, setCategoriaAbierta] = useState<string | null>(null)
  const [nuevoRubroLabel, setNuevoRubroLabel] = useState('')
  const [guardandoRubro, setGuardandoRubro] = useState(false)
  const [renombrandoCategoriaId, setRenombrandoCategoriaId] = useState<string | null>(null)
  const [nuevoNombreCategoria, setNuevoNombreCategoria] = useState('')

  // Pestaña "Categorías de productos": mismo esquema que la de
  // servicios de arriba, pero contra /api/categorias-productos.
  const [nuevaCategoriaProductoLabel, setNuevaCategoriaProductoLabel] = useState('')
  const [guardandoCategoriaProducto, setGuardandoCategoriaProducto] = useState(false)
  const [errorCategoriasProductos, setErrorCategoriasProductos] = useState('')
  const [categoriaProductoAbierta, setCategoriaProductoAbierta] = useState<string | null>(null)
  const [nuevoRubroProductoLabel, setNuevoRubroProductoLabel] = useState('')
  const [guardandoRubroProducto, setGuardandoRubroProducto] = useState(false)
  const [renombrandoCategoriaProductoId, setRenombrandoCategoriaProductoId] = useState<string | null>(null)
  const [nuevoNombreCategoriaProducto, setNuevoNombreCategoriaProducto] = useState('')

  useEffect(() => {
    if (categorias.length === 0 || categoriaSel) return
    setCategoriaSel(categorias[0].id)
    setRubro(categorias[0].rubros[0]?.id || 'otro')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [categorias])

  useEffect(() => {
    const guardada = typeof window !== 'undefined' ? localStorage.getItem('clasiclick_admin_pw') : null
    if (guardada) {
      setPassword(guardada)
      entrar(guardada)
    }
  }, [])

  function entrar(pw: string) {
    setCargando(true)
    fetch('/api/pedidos', { headers: { 'x-admin-password': pw } })
      .then(async (r) => {
        if (!r.ok) throw new Error((await r.json()).error || 'Contraseña incorrecta.')
        return r.json()
      })
      .then((data) => {
        setPedidos(data.pedidos || [])
        setAutenticado(true)
        setError('')
        localStorage.setItem('clasiclick_admin_pw', pw)
        // Importante: le pasamos "pw" explícito acá, no dependemos del
        // estado "password" — en el login automático (contraseña
        // guardada en localStorage), el estado todavía no se actualizó
        // en este mismo instante, y usar la versión vieja hacía que
        // estos pedidos salieran sin contraseña válida (mostrando la
        // vista pública filtrada en vez de la completa).
        cargarProfesionales(pw)
        cargarProductos(pw)
        cargarAnuncios(pw)
        cargarBanners(pw)
        cargarMacheos(pw)
        cargarConfigPagos()
      })
      .catch((e) => {
        setError(e.message)
        setAutenticado(false)
      })
      .finally(() => setCargando(false))
  }

  // QR de cobro para pedidos con envío (se paga acá, nunca directo al
  // vendedor — ver la explicación en checkout/page.tsx).
  const [qrPagoUrl, setQrPagoUrl] = useState('')
  const [cbuPago, setCbuPago] = useState('')
  const [bancoPago, setBancoPago] = useState('')
  const [titularPago, setTitularPago] = useState('')
  const [whatsappPago, setWhatsappPago] = useState('')
  const [subiendoQrPago, setSubiendoQrPago] = useState(false)
  const [guardandoConfigPago, setGuardandoConfigPago] = useState(false)
  const [configPagoGuardada, setConfigPagoGuardada] = useState(false)

  function cargarConfigPagos() {
    fetch('/api/configuracion/pagos')
      .then((r) => r.json())
      .then((data) => {
        setQrPagoUrl(data.qrImageUrl || '')
        setCbuPago(data.cbu || '')
        setBancoPago(data.banco || '')
        setTitularPago(data.titular || '')
        setWhatsappPago(data.whatsapp || '')
      })
  }

  async function subirQrPago(file: File | null) {
    if (!file) return
    setSubiendoQrPago(true)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setQrPagoUrl(data.url)
    } catch (e: any) {
      setError('Error subiendo el QR: ' + e.message)
    } finally {
      setSubiendoQrPago(false)
    }
  }

  async function guardarConfigPagos() {
    setGuardandoConfigPago(true)
    setConfigPagoGuardada(false)
    try {
      await fetch('/api/configuracion/pagos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ qrImageUrl: qrPagoUrl, cbu: cbuPago, banco: bancoPago, titular: titularPago, whatsapp: whatsappPago }),
      })
      setConfigPagoGuardada(true)
    } finally {
      setGuardandoConfigPago(false)
    }
  }

  function cargarProfesionales(pw?: string) {
    fetch('/api/profesionales', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setProfesionales(data.profesionales || []))
  }

  function cargarMetricas(pw?: string) {
    setCargandoMetricas(true)
    fetch('/api/admin/metricas', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setMetricas(data))
      .finally(() => setCargandoMetricas(false))
  }

  function cargarProductos(pw?: string) {
    fetch('/api/productos', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setProductos(data.productos || []))
  }

  function cargarAnuncios(pw?: string) {
    fetch('/api/anuncios', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setAnuncios(data.anuncios || []))
  }

  function cargarBanners(pw?: string) {
    fetch('/api/banners', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setBanners(data.banners || []))
  }

  async function subirBanner(file: File | null) {
    if (!file) return
    setSubiendoBanner(true)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const resSubida = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const dataSubida = await resSubida.json()
      if (dataSubida.error) throw new Error(dataSubida.error)

      await fetch('/api/banners', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ imagenUrl: dataSubida.url, link: bannerLinkNuevo || null, orden: banners.length }),
      })
      setBannerLinkNuevo('')
      cargarBanners()
    } catch (e: any) {
      alert('Error subiendo el banner: ' + e.message)
    } finally {
      setSubiendoBanner(false)
    }
  }

  function toggleBanner(id: string, activo: boolean) {
    fetch(`/api/banners/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ activo }),
    }).then(() => cargarBanners())
  }

  function eliminarBanner(id: string) {
    if (!confirm('¿Eliminar este banner?')) return
    fetch(`/api/banners/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarBanners())
  }

  function cargarMacheos(pw?: string) {
    setCargandoMacheos(true)
    fetch('/api/admin/macheos', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setMacheos(data))
      .finally(() => setCargandoMacheos(false))
  }

  function cambiarEstadoAnuncio(id: string, estado: 'aprobado' | 'rechazado') {
    fetch(`/api/anuncios/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => {
      cargarAnuncios()
      cargarMacheos()
    })
  }

  function cambiarEstadoAnuncioConNota(id: string, estado: string, notaAdmin: string) {
    fetch(`/api/anuncios/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado, notaAdmin }),
    }).then(() => cargarAnuncios())
  }

  function eliminarAnuncio(id: string) {
    if (!confirm('¿Eliminar este anuncio? No se puede deshacer.')) return
    fetch(`/api/anuncios/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarAnuncios())
  }

  // Importación en lote de anuncios (pegar texto de un canal de WhatsApp)
  const [textoImportarAnuncios, setTextoImportarAnuncios] = useState('')
  const [parseadosAnuncios, setParseadosAnuncios] = useState<(AnuncioParseado & { incluir: boolean })[]>([])
  const [importandoAnuncios, setImportandoAnuncios] = useState(false)
  const [resultadoImportacion, setResultadoImportacion] = useState<{ creados: number; errores: string[] } | null>(null)

  // Importación en lote de profesionales/servicios — mismo mecanismo que
  // arriba (mismo formato de texto, mismo parser), pero el resultado
  // SIEMPRE queda pendiente de revisión: acá no hay atajo de "completo
  // = se aprueba solo", porque un rubro y una zona reales no salen de
  // un texto de WhatsApp.
  const [textoImportarServicios, setTextoImportarServicios] = useState('')
  const [parseadosServicios, setParseadosServicios] = useState<(AnuncioParseado & { incluir: boolean })[]>([])
  const [importandoServicios, setImportandoServicios] = useState(false)
  const [resultadoImportacionServicios, setResultadoImportacionServicios] = useState<{ creados: number; errores: string[] } | null>(null)

  function parsearTextoServicios() {
    const parseados = parsearAnunciosWhatsapp(textoImportarServicios)
    setParseadosServicios(parseados.map((p) => ({ ...p, incluir: true })))
    setResultadoImportacionServicios(null)
  }

  function actualizarParseadoServicio(i: number, cambios: Partial<AnuncioParseado & { incluir: boolean }>) {
    setParseadosServicios((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...cambios } : p)))
  }

  async function importarServiciosSeleccionados() {
    const seleccionados = parseadosServicios.filter((p) => p.incluir)
    if (seleccionados.length === 0) return
    setImportandoServicios(true)
    try {
      const res = await fetch('/api/admin/profesionales/importar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({
          profesionales: seleccionados.map((p) => ({
            nombre: p.titulo,
            descripcion: p.descripcion,
            telefono: p.telefono,
            notaAdmin: p.incompleto ? 'Además, el texto quedó cortado — pedile al contacto la descripción completa.' : null,
          })),
        }),
      })
      const data = await res.json()
      setResultadoImportacionServicios({ creados: data.creados || 0, errores: data.errores || [] })
      setParseadosServicios((prev) => prev.filter((p) => !p.incluir))
      cargarProfesionales()
    } finally {
      setImportandoServicios(false)
    }
  }

  function parsearTextoAnuncios() {
    const parseados = parsearAnunciosWhatsapp(textoImportarAnuncios)
    setParseadosAnuncios(parseados.map((p) => ({ ...p, incluir: true })))
    setResultadoImportacion(null)
  }

  function actualizarParseado(i: number, cambios: Partial<AnuncioParseado & { incluir: boolean }>) {
    setParseadosAnuncios((prev) => prev.map((p, idx) => (idx === i ? { ...p, ...cambios } : p)))
  }

  async function importarAnunciosSeleccionados() {
    const seleccionados = parseadosAnuncios.filter((p) => p.incluir)
    if (seleccionados.length === 0) return
    setImportandoAnuncios(true)
    try {
      const res = await fetch('/api/admin/anuncios/importar', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({
          anuncios: seleccionados.map((p) => ({
            titulo: p.titulo,
            descripcion: p.descripcion,
            telefono: p.telefono,
            tipo: 'busqueda',
            estado: p.incompleto ? 'info_solicitada' : 'aprobado',
            notaAdmin: p.incompleto ? 'Importado desde WhatsApp con el texto cortado — falta pedirle al contacto la descripción completa.' : null,
          })),
        }),
      })
      const data = await res.json()
      setResultadoImportacion({ creados: data.creados || 0, errores: data.errores || [] })
      setParseadosAnuncios((prev) => prev.filter((p) => !p.incluir))
      cargarAnuncios()
    } finally {
      setImportandoAnuncios(false)
    }
  }

  function cargarUsuarios(pw?: string) {
    setCargandoUsuarios(true)
    fetch('/api/admin/usuarios', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setUsuarios(data.usuarios || []))
      .finally(() => setCargandoUsuarios(false))
  }

  function pausarUsuario(uid: string, pausado: boolean) {
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ pausado }),
    }).then(() => cargarUsuarios())
  }

  function eliminarUsuario(uid: string) {
    if (!confirm('¿Eliminar esta cuenta definitivamente? El usuario no va a poder volver a entrar con este login. Esta acción no se puede deshacer.')) return
    fetch(`/api/admin/usuarios/${uid}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarUsuarios())
  }

  function cambiarEstadoProducto(id: string, estado: 'activo' | 'pendiente' | 'rechazado' | 'oculto') {
    fetch(`/api/productos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => cargarProductos(password))
  }

  function cambiarEstadoPedido(id: string, estado: 'pendiente_pago' | 'pagado' | 'en_preparacion' | 'en_entrega' | 'entregado' | 'cancelado') {
    fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ estado }),
    }).then(() => entrar(password))
  }

  // La moto saca una foto del producto entregado (en la puerta, o en
  // manos de quien lo recibió) al marcar el pedido como entregado — es
  // más simple que pedir una firma física, y ya alcanza como
  // comprobante de que el reparto se hizo bien.
  async function marcarEntregadoConFoto(id: string, file: File) {
    setSubiendoFotoEntregaId(id)
    try {
      const formData = new FormData()
      formData.append('image', file)
      const resSubida = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const dataSubida = await resSubida.json()
      if (dataSubida.error) throw new Error(dataSubida.error)

      await fetch(`/api/pedidos/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ estado: 'entregado', fotoEntregaUrl: dataSubida.url }),
      })
      entrar(password)
    } catch (e: any) {
      alert('No se pudo subir la foto: ' + e.message)
    } finally {
      setSubiendoFotoEntregaId(null)
    }
  }

  function confirmarPago(id: string) {
    cambiarEstadoPedido(id, 'pagado')
  }

  function pagarAlVendedor(id: string, medio: 'efectivo' | 'qr') {
    fetch(`/api/pedidos/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ pagoVendedorMedio: medio }),
    }).then(() => entrar(password))
  }

  function eliminarPedido(id: string) {
    if (!confirm('¿Eliminar este pedido? Esta acción no se puede deshacer.')) return
    fetch(`/api/pedidos/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => entrar(password))
  }

  const [productoEditando, setProductoEditando] = useState<any>(null)
  const [editNombre, setEditNombre] = useState('')
  const [editPrecio, setEditPrecio] = useState('')
  const [editPrecioOriginal, setEditPrecioOriginal] = useState('')
  const [editCategoria, setEditCategoria] = useState('')
  const [editDescCorta, setEditDescCorta] = useState('')
  const [editDescLarga, setEditDescLarga] = useState('')
  const [editTalles, setEditTalles] = useState('')
  const [editColores, setEditColores] = useState('')
  const [editMateriales, setEditMateriales] = useState('')
  const [editEstado, setEditEstado] = useState('')
  const [guardandoEdit, setGuardandoEdit] = useState(false)

  function abrirEditarProducto(p: any) {
    setProductoEditando(p)
    setEditNombre(p.nombre || '')
    setEditPrecio(String(p.precio || ''))
    setEditPrecioOriginal(String(p.precioOriginal || ''))
    setEditCategoria(p.rubro || p.categoria || '')
    setEditDescCorta(p.descripcionCorta || '')
    setEditDescLarga(p.descripcionLarga || '')
    setEditTalles(Array.isArray(p.talles) ? p.talles.join(', ') : (p.talles || ''))
    setEditColores(Array.isArray(p.colores) ? p.colores.join(', ') : (p.colores || ''))
    setEditMateriales(p.materiales || '')
    setEditEstado(p.estado || 'activo')
  }

  async function guardarEditProducto() {
    if (!productoEditando) return
    setGuardandoEdit(true)
    const tallesArr = editTalles.split(',').map(s => s.trim()).filter(Boolean)
    const coloresArr = editColores.split(',').map(s => s.trim()).filter(Boolean)
    await fetch(`/api/productos/${productoEditando.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({
        nombre: editNombre,
        precio: Number(editPrecio),
        precioOriginal: editPrecioOriginal ? Number(editPrecioOriginal) : null,
        rubro: editCategoria,
        descripcionCorta: editDescCorta,
        descripcionLarga: editDescLarga,
        talles: tallesArr,
        colores: coloresArr,
        materiales: editMateriales,
        estado: editEstado,
      }),
    })
    setGuardandoEdit(false)
    setProductoEditando(null)
    cargarProductos(password)
  }



  // Mismo endpoint que usan los vendedores en /vender, pero acá nos
  // autenticamos con la contraseña de admin en vez de un login de
  // Firebase (este panel no usa ese sistema de cuentas).
  async function subirImagenProfesional(file: File | null) {
    if (!file) return
    setSubiendoImagen(true)
    setErrorForm('')
    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/upload-image', {
        method: 'POST',
        headers: { 'x-admin-password': password },
        body: formData,
      })
      const data = await res.json()
      if (data.error) throw new Error(data.error)
      setImagenUrl(data.url)
    } catch (e: any) {
      setErrorForm('Error subiendo la imagen: ' + e.message)
    } finally {
      setSubiendoImagen(false)
    }
  }

  async function publicarProfesional(e: React.FormEvent) {
    e.preventDefault()
    setErrorForm('')
    if (!nombre.trim() || !whatsapp.trim()) {
      setErrorForm('Completá al menos el nombre y el WhatsApp.')
      return
    }
    setPublicando(true)
    try {
      const datos = {
        nombre, rubro, especialidad, descripcion, zona, direccion,
        lat: lat || null, lng: lng || null,
        whatsapp, instagram, email: emailProfesional, icono, plan, imagenUrl,
        precio: precio || null,
        experiencia,
      }
      const editando = !!profesionalEditandoId
      const res = await fetch(
        editando ? `/api/profesionales/${profesionalEditandoId}` : '/api/profesionales',
        {
          method: editando ? 'PATCH' : 'POST',
          headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
          body: JSON.stringify(datos),
        }
      )
      const data = await res.json()
      if (data.error) {
        setErrorForm(data.error)
        return
      }
      setNombre(''); setDescripcion(''); setZona(''); setDireccion(''); setLat(''); setLng(''); setWhatsapp('')
      setImagenUrl(''); setPrecio(''); setExperiencia(''); setInstagram(''); setEmailProfesional(''); setEspecialidad('')
      setProfesionalEditandoId(null)
      cargarProfesionales()
    } finally {
      setPublicando(false)
    }
  }

  // Carga los datos de un profesional ya existente en el mismo
  // formulario de arriba (que pasa a modo "edición"), para poder
  // corregir cualquier dato sin tener que borrarlo y volver a cargarlo.
  function abrirEditarProfesional(p: any) {
    setProfesionalEditandoId(p.id)
    setNombre(p.nombre || '')
    const rubroInfo = buscarRubro(p.rubro)
    setCategoriaSel(rubroInfo?.categoriaId || categorias[0]?.id || '')
    setRubro(p.rubro || '')
    setEspecialidad(p.especialidad || '')
    setDescripcion(p.descripcion || '')
    setZona(p.zona || '')
    setDireccion(p.direccion || '')
    setLat(p.lat != null ? String(p.lat) : '')
    setLng(p.lng != null ? String(p.lng) : '')
    setWhatsapp(p.whatsapp || '')
    setInstagram(p.instagram || '')
    setEmailProfesional(p.email || '')
    setIcono(p.icono || ICONOS_SERVICIO[0])
    setImagenUrl(p.imagenUrl || '')
    setPrecio(p.precio != null ? String(p.precio) : '')
    setExperiencia(p.experiencia || '')
    setPlan(p.plan === 'premium' ? 'premium' : 'basico')
    setEditHorarioBloques(p.horarioTurnos?.bloques || [])
    setErrorForm('')
    if (typeof window !== 'undefined') window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function cancelarEdicionProfesional() {
    setProfesionalEditandoId(null)
    setNombre(''); setDescripcion(''); setZona(''); setDireccion(''); setLat(''); setLng(''); setWhatsapp('')
    setImagenUrl(''); setPrecio(''); setExperiencia(''); setInstagram(''); setEmailProfesional(''); setEspecialidad('')
    setEditHorarioBloques([]); setEditNuevoBloqueDias([]); setEditNuevoBloqueTodoElDia(false)
    setErrorForm('')
  }

  function toggleDiaNuevoBloqueAdmin(diaId: number) {
    setEditNuevoBloqueDias((dias) => (dias.includes(diaId) ? dias.filter((d) => d !== diaId) : [...dias, diaId].sort()))
  }

  function agregarBloqueAdmin() {
    if (editNuevoBloqueDias.length === 0) return
    const desde = editNuevoBloqueTodoElDia ? '00:00' : editNuevoBloqueDesde
    const hasta = editNuevoBloqueTodoElDia ? '23:30' : editNuevoBloqueHasta
    if (hasta <= desde) return
    const nuevo: BloqueHorario = { id: `b${Date.now()}`, dias: editNuevoBloqueDias, desde, hasta, intervaloMin: editNuevoBloqueIntervalo }
    setEditHorarioBloques((b) => [...b, nuevo])
    setEditNuevoBloqueDias([])
    setEditNuevoBloqueTodoElDia(false)
  }

  function quitarBloqueAdmin(id: string) {
    setEditHorarioBloques((b) => b.filter((x) => x.id !== id))
  }

  async function guardarHorarioAdmin() {
    if (!profesionalEditandoId) return
    setGuardandoHorarioAdmin(true)
    setHorarioAdminGuardado(false)
    try {
      const res = await fetch(`/api/profesionales/${profesionalEditandoId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ horarioTurnos: { bloques: editHorarioBloques } }),
      })
      const data = await res.json()
      if (data.error) { setErrorForm(data.error); return }
      setHorarioAdminGuardado(true)
      cargarProfesionales()
    } finally {
      setGuardandoHorarioAdmin(false)
    }
  }

  function borrarProfesional(id: string) {
    fetch(`/api/profesionales/${id}`, {
      method: 'DELETE',
      headers: { 'x-admin-password': password },
    }).then(() => cargarProfesionales())
  }

  async function crearCategoria(e: React.FormEvent) {
    e.preventDefault()
    if (!nuevaCategoriaLabel.trim()) return
    setGuardandoCategoria(true)
    setErrorCategorias('')
    try {
      const res = await fetch('/api/categorias', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_categoria', label: nuevaCategoriaLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategorias(data.error); return }
      setNuevaCategoriaLabel('')
      recargarCategorias()
    } finally {
      setGuardandoCategoria(false)
    }
  }

  async function crearRubro(categoriaId: string) {
    if (!nuevoRubroLabel.trim()) return
    setGuardandoRubro(true)
    setErrorCategorias('')
    try {
      const res = await fetch('/api/categorias', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_rubro', categoriaId, label: nuevoRubroLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategorias(data.error); return }
      setNuevoRubroLabel('')
      setCategoriaAbierta(null)
      recargarCategorias()
    } finally {
      setGuardandoRubro(false)
    }
  }

  async function moverRubro(rubroId: string, categoriaId: string) {
    setErrorCategorias('')
    const res = await fetch('/api/categorias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'mover_rubro', rubroId, categoriaId }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategorias(data.error); return }
    recargarCategorias()
  }

  async function renombrarCategoria(categoriaId: string) {
    if (!nuevoNombreCategoria.trim()) return
    setErrorCategorias('')
    const res = await fetch('/api/categorias', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'renombrar_categoria', categoriaId, label: nuevoNombreCategoria.trim() }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategorias(data.error); return }
    setRenombrandoCategoriaId(null)
    setNuevoNombreCategoria('')
    recargarCategorias()
  }

  async function crearCategoriaProducto(e: React.FormEvent) {
    e.preventDefault()
    if (!nuevaCategoriaProductoLabel.trim()) return
    setGuardandoCategoriaProducto(true)
    setErrorCategoriasProductos('')
    try {
      const res = await fetch('/api/categorias-productos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_categoria', label: nuevaCategoriaProductoLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategoriasProductos(data.error); return }
      setNuevaCategoriaProductoLabel('')
      recargarCategoriasProductos()
    } finally {
      setGuardandoCategoriaProducto(false)
    }
  }

  async function crearRubroProducto(categoriaId: string) {
    if (!nuevoRubroProductoLabel.trim()) return
    setGuardandoRubroProducto(true)
    setErrorCategoriasProductos('')
    try {
      const res = await fetch('/api/categorias-productos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
        body: JSON.stringify({ accion: 'crear_rubro', categoriaId, label: nuevoRubroProductoLabel.trim() }),
      })
      const data = await res.json()
      if (data.error) { setErrorCategoriasProductos(data.error); return }
      setNuevoRubroProductoLabel('')
      setCategoriaProductoAbierta(null)
      recargarCategoriasProductos()
    } finally {
      setGuardandoRubroProducto(false)
    }
  }

  async function moverRubroProducto(rubroId: string, categoriaId: string) {
    setErrorCategoriasProductos('')
    const res = await fetch('/api/categorias-productos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'mover_rubro', rubroId, categoriaId }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategoriasProductos(data.error); return }
    recargarCategoriasProductos()
  }

  async function renombrarCategoriaProducto(categoriaId: string) {
    if (!nuevoNombreCategoriaProducto.trim()) return
    setErrorCategoriasProductos('')
    const res = await fetch('/api/categorias-productos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ accion: 'renombrar_categoria', categoriaId, label: nuevoNombreCategoriaProducto.trim() }),
    })
    const data = await res.json()
    if (data.error) { setErrorCategoriasProductos(data.error); return }
    setRenombrandoCategoriaProductoId(null)
    setNuevoNombreCategoriaProducto('')
    recargarCategoriasProductos()
  }

  function cambiarEstadoProfesional(
    id: string,
    estado: 'aprobado' | 'rechazado' | 'info_solicitada' | 'pendiente_revision',
    notaAdmin?: string
  ) {
    fetch(`/api/profesionales/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify(notaAdmin !== undefined ? { estado, notaAdmin } : { estado }),
    }).then(() => cargarProfesionales())
  }

  // Confirma que el pago de la membresía Premium realmente llegó (lo
  // revisás vos a mano contra el banco/QR, como con los pedidos de
  // productos) — activa Premium y extiende la vigencia 30 días desde
  // hoy, o desde la vigencia actual si todavía no había vencido.
  function confirmarPagoPremium(p: { id: string; planVigenciaHasta?: string | null }) {
    fetch(`/api/profesionales/${p.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({
        plan: 'premium',
        planEstadoPago: 'ninguno',
        planVigenciaHasta: calcularNuevaVigencia(p.planVigenciaHasta),
      }),
    }).then(() => cargarProfesionales())
  }

  function rechazarPagoPremium(id: string) {
    fetch(`/api/profesionales/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ planEstadoPago: 'ninguno' }),
    }).then(() => cargarProfesionales())
  }

  const [vendedoresAdmin, setVendedoresAdmin] = useState<any[]>([])

  function cargarVendedoresAdmin(pw?: string) {
    fetch('/api/admin/vendedores', { headers: { 'x-admin-password': pw ?? password } })
      .then((r) => r.json())
      .then((data) => setVendedoresAdmin(data.vendedores || []))
  }

  function confirmarPagoPremiumVendedor(v: { id: string; planVigenciaHasta?: string | null }) {
    fetch(`/api/vendedores/${v.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({
        plan: 'premium',
        planEstadoPago: 'ninguno',
        planVigenciaHasta: calcularNuevaVigencia(v.planVigenciaHasta),
      }),
    }).then(() => cargarVendedoresAdmin())
  }

  function rechazarPagoPremiumVendedor(id: string) {
    fetch(`/api/vendedores/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ planEstadoPago: 'ninguno' }),
    }).then(() => cargarVendedoresAdmin())
  }

  if (!autenticado) {
    return (
      <div className="max-w-[360px] mx-auto px-5 py-20">
        <div className="font-display text-xl font-bold text-ink mb-4">Panel de administración</div>
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Contraseña de administrador"
          className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
          onKeyDown={(e) => e.key === 'Enter' && entrar(password)}
        />
        <button
          onClick={() => entrar(password)}
          disabled={cargando}
          className="w-full py-2.5 rounded-lg border-none bg-ink text-white font-body text-sm font-semibold"
        >
          {cargando ? 'Entrando...' : 'Entrar'}
        </button>
        {error && <div className="font-body text-xs text-maroon mt-3">{error}</div>}
      </div>
    )
  }


  async function cargarSolicitudes() {
    setCargandoSolicitudes(true)
    try {
      const res = await fetch('/api/solicitud-ayuda', {
        headers: { 'x-admin-password': password }
      })
      const data = await res.json()
      setSolicitudes(data.solicitudes || [])
    } finally { setCargandoSolicitudes(false) }
  }

  async function marcarSolicitud(id: string, estado: string) {
    await fetch('/api/solicitud-ayuda', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
      body: JSON.stringify({ id, estado }),
    })
    setSolicitudes(prev => prev.map(s => s.id === id ? { ...s, estado } : s))
  }


  return (
    <div className="max-w-[640px] mx-auto px-5 py-8">
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Pedidos</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.pedidosTotal}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">En proceso</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.pedidosPagados}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Productos activos</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.productosActivos}</div>
        </div>
        <div className="bg-panel border border-line rounded-xl p-3.5">
          <div className="font-body text-[11px] text-inksoft">Premium</div>
          <div className="font-display text-2xl font-bold text-ink">{resumen.productosPremium}</div>
        </div>
      </div>

      <div className="bg-panel border border-line rounded-xl p-4 mb-6">
        <div className="font-body text-sm font-semibold text-ink mb-1">Mi QR de cobro (pedidos con envío)</div>
        <div className="font-body text-[11px] text-inksoft mb-3">
          Cuando un comprador elige "envío" en el checkout, siempre paga a ESTE QR (nunca directo al vendedor) — recién se le libera la plata al vendedor cuando confirmás la entrega. Con "retiro en tienda" sí se paga al QR propio del vendedor.
        </div>
        <div className="flex items-start gap-4 flex-wrap">
          <div className="shrink-0">
            {qrPagoUrl ? (
              <img src={qrPagoUrl} alt="QR de cobro" className="w-28 h-28 object-cover rounded-lg border border-line" />
            ) : (
              <div className="w-28 h-28 rounded-lg border border-dashed border-line flex items-center justify-center font-body text-[10px] text-inksoft text-center px-2">
                Sin QR cargado
              </div>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirQrPago(e.target.files?.[0] || null)}
              disabled={subiendoQrPago}
              className="font-body text-[10px] mt-1.5 w-28"
            />
            {subiendoQrPago && <div className="font-body text-[10px] text-maroon mt-1">Subiendo...</div>}
          </div>
          <div className="flex-1 min-w-[220px]">
            <input
              value={cbuPago}
              onChange={(e) => setCbuPago(e.target.value)}
              placeholder="Cuenta / CBU (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={bancoPago}
              onChange={(e) => setBancoPago(e.target.value)}
              placeholder="Banco (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={titularPago}
              onChange={(e) => setTitularPago(e.target.value)}
              placeholder="Titular de la cuenta (opcional)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <input
              value={whatsappPago}
              onChange={(e) => setWhatsappPago(e.target.value)}
              placeholder="Tu WhatsApp para recibir comprobantes (ej: 59171234567)"
              className="w-full px-3 py-2 rounded-lg border border-line font-body text-xs mb-2"
            />
            <div className="font-body text-[10px] text-inksoft mb-2 -mt-1">
              A este número te va a llegar el comprobante de los pedidos con envío (esos siempre se pagan a tu cuenta, nunca directo al vendedor).
            </div>
            <button
              onClick={guardarConfigPagos}
              disabled={guardandoConfigPago}
              className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-60"
            >
              {guardandoConfigPago ? 'Guardando...' : 'Guardar'}
            </button>
            {configPagoGuardada && <span className="font-body text-[11px] text-teal ml-2">Guardado ✓</span>}
          </div>
        </div>
      </div>

      <div className="flex gap-2 mb-6 border-b border-line flex-wrap">
        <button
          onClick={() => setTab('pedidos')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'pedidos' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Pedidos
        </button>
        <button
          onClick={() => { setTab('productos'); if (vendedoresAdmin.length === 0) cargarVendedoresAdmin() }}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'productos' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Productos
        </button>
        <button
          onClick={() => setTab('servicios')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'servicios' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Servicios profesionales
          {profesionales.filter((p) => p.estado === 'pendiente_revision').length > 0 && (
            <span className="ml-1.5 inline-block bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
              {profesionales.filter((p) => p.estado === 'pendiente_revision').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('anuncios')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'anuncios' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Anuncios
          {anuncios.filter((a) => a.estado === 'pendiente_revision').length > 0 && (
            <span className="ml-1.5 inline-block bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
              {anuncios.filter((a) => a.estado === 'pendiente_revision').length}
            </span>
          )}
        </button>
        <button
          onClick={() => setTab('reparto')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'reparto' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Reparto
        </button>
        <button
          onClick={() => setTab('banners')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'banners' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Banners
        </button>
        <button
          onClick={() => { setTab('usuarios'); if (usuarios.length === 0) cargarUsuarios() }}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'usuarios' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Usuarios
        </button>
        <button
          onClick={() => setTab('categorias')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'categorias' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Categorías
        </button>
        <button
          onClick={() => setTab('categorias-productos')}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'categorias-productos' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Categorías de productos
        </button>
        <button
          onClick={() => { setTab('metricas'); if (!metricas) cargarMetricas() }}
          className={`px-4 py-2.5 font-body text-sm font-semibold border-b-2 ${tab === 'metricas' ? 'border-maroon text-ink' : 'border-transparent text-inksoft'}`}
        >
          Métricas
        </button>
      </div>

      {tab === 'pedidos' && (
        <div>
          {pedidos.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay pedidos.</div>}
          {pedidos.map((p) => {
            const estado = ESTADOS_LABEL[p.estado] || { texto: p.estado, color: 'text-inksoft' }
            return (
              <div key={p.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-body text-sm font-medium text-ink">Pedido #{p.id.slice(0, 6)}</div>
                    <div className="font-body text-xs font-semibold text-ink mt-0.5">
                      👤 {p.nombreComprador || 'Sin nombre cargado'}
                    </div>
                    <div className="font-body text-[11px] text-inksoft">{p.comprador || 'Sin email'}</div>
                    <div className="font-body text-[11px] text-inksoft mt-1">
                      🏪 {p.vendedorNombre || 'Clasi Click'}
                      {p.createdAt && ` · ${new Date(p.createdAt).toLocaleString('es-BO', { dateStyle: 'short', timeStyle: 'short' })}`}
                    </div>
                    <div className="font-body text-[11px] text-inksoft mt-1">
                      {p.zonaEntrega || 'Sin zona'} · {p.direccion ? `Entrega: ${p.direccion}` : 'Sin dirección'}
                      {p.entreCalles && ` (${p.entreCalles})`}
                    </div>
                    <div className={`font-body text-xs font-semibold ${estado.color}`}>{estado.texto}</div>
                  </div>
                  {p.estado !== 'pagado' && p.estado !== 'en_preparacion' && p.estado !== 'en_entrega' && p.estado !== 'entregado' && p.estado !== 'cancelado' && (
                    <button
                      onClick={() => confirmarPago(p.id)}
                      className="px-3.5 py-2 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                    >
                      Confirmar pago
                    </button>
                  )}
                  {p.estado === 'pagado' && p.whatsappComprador && (
                    <a
                      href={`https://wa.me/${p.whatsappComprador.replace(/\D/g, '')}?text=${encodeURIComponent(`¡Felicitaciones ${p.nombreComprador || ''}! 🎉 Tu pedido #${p.id.slice(0, 6)} quedó confirmado. En cuanto esté listo te avisamos por acá.`)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-3.5 py-2 rounded-md border border-teal text-teal font-body text-xs font-semibold shrink-0"
                    >
                      🎉 Mandar felicitaciones
                    </a>
                  )}
                </div>

                {p.comprobanteUrl && (
                  <div className="mt-3 pt-3 border-t border-line">
                    <div className="font-body text-[11px] text-inksoft mb-1.5">Comprobante enviado por el comprador</div>
                    <div className="flex items-start gap-2.5">
                      <a href={p.comprobanteUrl} target="_blank" rel="noopener noreferrer" className="shrink-0">
                        <img src={p.comprobanteUrl} alt="Comprobante" className="w-16 h-16 rounded-lg object-cover border border-line" />
                      </a>
                      <div className="flex-1 min-w-0">
                        {p.ocrCoincide === true && (
                          <div className="font-body text-[11px] text-teal mb-0.5">
                            ✓ Lectura automática: {bs(p.ocrMonto)} — coincide con el total
                          </div>
                        )}
                        {p.ocrCoincide === false && (
                          <div className="font-body text-[11px] text-maroon mb-0.5">
                            ⚠ Lectura automática: {bs(p.ocrMonto)} — no coincide con {bs(p.total)}. Revisá la imagen.
                          </div>
                        )}
                        {p.ocrCoincide == null && (
                          <div className="font-body text-[11px] text-inksoft mb-0.5">
                            No se pudo leer el monto automáticamente — revisá la imagen a mano.
                          </div>
                        )}
                        <a href={p.comprobanteUrl} target="_blank" rel="noopener noreferrer" className="font-body text-[11px] text-maroon underline">
                          Ver comprobante en grande
                        </a>
                      </div>
                    </div>
                  </div>
                )}

                <div className="mt-3 pt-3 border-t border-line flex flex-col gap-2">
                  {(p.items || []).map((it: any, i: number) => (
                    <div key={i} className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-md bg-panelalt flex items-center justify-center overflow-hidden shrink-0">
                        {(it.thumbUrl || it.imagenUrl) ? (
                          <img src={it.thumbUrl || it.imagenUrl} alt={it.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
                        ) : (
                          <span className="font-body text-[8px] text-inksoft">IMG</span>
                        )}
                      </div>
                      <div className="font-body text-xs text-ink flex-1 min-w-0 truncate">
                        {it.cantidad} × {it.nombre}
                        {(it.tallaElegida || it.colorElegida) && (
                          <span className="text-inksoft"> ({[it.tallaElegida, it.colorElegida].filter(Boolean).join(' · ')})</span>
                        )}
                      </div>
                      <div className="font-body text-xs text-inksoft shrink-0">{bs(it.precio * it.cantidad)}</div>
                    </div>
                  ))}
                  <div className="font-body text-xs font-semibold text-ink text-right">Total: {bs(p.total)}</div>
                </div>

                {p.estado === 'verificando_stock' && (
                  <div className="mt-3">
                    {p.vendedorWhatsapp && (
                      <a
                        href={`https://wa.me/${p.vendedorWhatsapp}?text=${encodeURIComponent(
                          `Hola ${p.vendedorNombre}! Te escribo de Clasi Click — llegó un pedido nuevo (${p.items?.length || 0} producto(s), Bs ${p.total}). ¿Podés confirmarme si tenés stock disponible?`
                        )}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block mb-2 px-2.5 py-1.5 rounded-md border border-teal text-teal font-body text-[11px] font-semibold"
                      >
                        💬 Contactar al vendedor para verificar stock
                      </a>
                    )}
                    <div className="flex flex-wrap gap-2">
                      <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'pendiente_pago')} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-[11px] font-semibold">Confirmar stock disponible</button>
                      <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Sin stock / cancelar</button>
                    </div>
                  </div>
                )}

                {p.metodoEntrega === 'envio' && ['pagado', 'en_preparacion', 'en_entrega', 'entregado'].includes(p.estado) && (
                  <div className="mt-3">
                    {p.pagoVendedorHecho ? (
                      <div className="font-body text-[11px] text-teal">
                        ✓ Pagado al vendedor por {p.pagoVendedorMedio === 'efectivo' ? 'efectivo' : 'QR'}{p.pagoVendedorAt && ` el ${new Date(p.pagoVendedorAt).toLocaleDateString('es-BO')}`}
                      </div>
                    ) : (
                      <div className="bg-panelalt border border-line rounded-lg p-2.5">
                        <div className="font-body text-[11px] text-inksoft mb-1.5">
                          Este pedido cobró por QR de la plataforma — todavía falta pagarle al vendedor su parte:
                        </div>
                        <div className="flex gap-2">
                          <button type="button" onClick={() => pagarAlVendedor(p.id, 'efectivo')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] font-semibold">Ya le pagué en efectivo</button>
                          <button type="button" onClick={() => pagarAlVendedor(p.id, 'qr')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] font-semibold">Ya le pagué por QR</button>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {p.estado === 'pagado' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_preparacion')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">En preparación</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_entrega')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">En entrega</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'entregado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Entregado</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Cancelar</button>
                  </div>
                )}

                {p.estado === 'en_preparacion' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'en_entrega')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Enviar</button>
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'cancelado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Cancelar</button>
                  </div>
                )}

                {p.estado === 'en_entrega' && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button type="button" onClick={() => cambiarEstadoPedido(p.id, 'entregado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]">Marcar entregado</button>
                  </div>
                )}

                <div className="mt-3 pt-3 border-t border-line text-right">
                  <button
                    type="button"
                    onClick={() => eliminarPedido(p.id)}
                    className="font-body text-[11px] text-maroon underline"
                  >
                    Eliminar pedido
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {tab === 'productos' && (
        <div>
          {vendedoresAdmin.filter((v) => v.planEstadoPago === 'informado_pago').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-teal mb-3">
                💳 Pagos de membresía Premium de vendedores por confirmar ({vendedoresAdmin.filter((v) => v.planEstadoPago === 'informado_pago').length})
              </div>
              {vendedoresAdmin
                .filter((v) => v.planEstadoPago === 'informado_pago')
                .map((v) => (
                <div key={v.id} className="bg-panel border border-teal rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{v.nombreNegocio || v.email || v.id}</div>
                  <div className="font-body text-xs text-inksoft mb-3">
                    WhatsApp: {v.whatsapp || 'sin cargar'}
                    {v.planVigenciaHasta && new Date(v.planVigenciaHasta).getTime() > Date.now() && (
                      <> · Ya tiene Premium vigente hasta {new Date(v.planVigenciaHasta).toLocaleDateString('es-BO')} — confirmar esto se lo extiende 30 días más desde esa fecha</>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => confirmarPagoPremiumVendedor(v)}
                      className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                    >
                      Confirmar pago recibido
                    </button>
                    <button
                      onClick={() => rechazarPagoPremiumVendedor(v.id)}
                      className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                    >
                      No llegó / rechazar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="font-body text-sm font-semibold text-ink mb-3">Moderación de productos</div>
          {productos.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay productos.</div>}
          {[...productos]
            .sort((a, b) => {
              const orden: Record<string, number> = { alto: 0, medio: 1, bajo: 2 }
              const oa = orden[a.moderacionIA?.riesgo] ?? 3
              const ob = orden[b.moderacionIA?.riesgo] ?? 3
              return oa - ob
            })
            .map((p) => (
            <div key={p.id} className="bg-panel border border-line rounded-lg p-3.5 mb-3 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-panelalt flex items-center justify-center overflow-hidden shrink-0">
                {p.thumbUrl || p.imagenUrl ? <img src={p.thumbUrl || p.imagenUrl} alt={p.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" /> : <span className="font-body text-[10px] text-inksoft">IMG</span>}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-body text-sm font-medium text-ink truncate">{p.nombre}</div>
                <div className="font-body text-xs text-inksoft">{p.vendedor || 'Vendedor'} · {labelPublicoProducto(p.publico)} · {buscarRubroProducto(p.rubro)?.label || p.categoria || 'Sin rubro'} · Bs {Number(p.precio || 0).toLocaleString('es-BO')}</div>
                <div className="font-body text-[11px] text-inksoft mt-1">Estado: {p.estado || 'activo'}</div>
                <BadgeRiesgoIA moderacionIA={p.moderacionIA} />
              </div>
              <div className="flex gap-2 flex-wrap justify-end">
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'activo')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Activo</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'pendiente')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Pendiente</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'oculto')} className="px-2 py-1 rounded-md border border-line font-body text-[11px]">Ocultar</button>
                <button type="button" onClick={() => cambiarEstadoProducto(p.id, 'rechazado')} className="px-2 py-1 rounded-md border border-line font-body text-[11px] text-maroon">Rechazar</button>
                  <button
                    type="button"
                    onClick={() => {
                      if (!confirm('¿Borrar este producto definitivamente?')) return
                      fetch(`/api/productos/${p.id}`, {
                        method: 'DELETE',
                        headers: { 'x-admin-password': password },
                      }).then(() => cargarProductos())
                    }}
                    className="px-2 py-1 rounded-md border border-line font-body text-[11px] text-maroon"
                  >
                    Borrar
                  </button>
                  <button
                    type="button"
                    onClick={async () => {
                      const nuevoNombre = prompt('Nuevo nombre', p.nombre || '')
                      if (nuevoNombre === null) return
                      const nuevoPrecio = prompt('Nuevo precio (Bs)', String(p.precio || ''))
                      if (nuevoPrecio === null) return
                      fetch(`/api/productos/${p.id}`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json', 'x-admin-password': password },
                        body: JSON.stringify({ nombre: nuevoNombre, precio: Number(nuevoPrecio) }),
                      }).then(() => cargarProductos())
                    }}
                    className="px-2 py-1 rounded-md border border-line font-body text-[11px]"
                  >
                    Editar
                  </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'servicios' && (
        <div>
          <form onSubmit={publicarProfesional} className="bg-panel border border-line rounded-xl p-5 mb-8">
            <div className="flex items-center justify-between mb-3">
              <div className="font-body text-sm font-semibold text-ink">
                {profesionalEditandoId ? 'Editando profesional' : 'Nuevo profesional'}
              </div>
              {profesionalEditandoId && (
                <button
                  type="button"
                  onClick={cancelarEdicionProfesional}
                  className="font-body text-xs text-inksoft underline"
                >
                  Cancelar edición
                </button>
              )}
            </div>
            <input
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              placeholder="Nombre o nombre del negocio"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <div className="grid grid-cols-2 gap-3 mb-3">
              <select
                value={categoriaSel}
                onChange={(e) => {
                  const nuevaCategoria = e.target.value
                  setCategoriaSel(nuevaCategoria)
                  const cat = categorias.find((c) => c.id === nuevaCategoria)
                  setRubro(cat?.rubros[0]?.id || 'otro')
                }}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                {categorias.map((c) => (
                  <option key={c.id} value={c.id}>{c.label}</option>
                ))}
              </select>
              <select
                value={rubro}
                onChange={(e) => setRubro(e.target.value)}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                {(categorias.find((c) => c.id === categoriaSel)?.rubros || []).map((r) => (
                  <option key={r.id} value={r.id}>{r.label}</option>
                ))}
              </select>
            </div>
            <div className="font-body text-[11px] text-inksoft mb-3 -mt-2">
              ¿No está el rubro que buscás? Agregalo desde la pestaña "Categorías" y va a aparecer acá.
            </div>
            <div className="grid grid-cols-2 gap-3 mb-3">
              <select
                value={plan}
                onChange={(e) => setPlan(e.target.value as 'basico' | 'premium')}
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm bg-panel"
              >
                <option value="basico">Plan básico</option>
                <option value="premium">Plan premium (destacado)</option>
              </select>
            </div>
            <input
              value={especialidad}
              onChange={(e) => setEspecialidad(e.target.value)}
              placeholder="Especialidad (opcional, ej: Médico general - Ecografista)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <textarea
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              placeholder="Descripción breve"
              rows={2}
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />

            <div className="mb-3">
              <div className="font-body text-xs text-inksoft mb-1.5">Foto (opcional)</div>
              <div className="flex items-center gap-3 flex-wrap">
                {imagenUrl && (
                  <img
                    src={imagenUrl}
                    alt="Vista previa"
                    className="w-14 h-14 object-cover rounded-lg border border-line"
                  />
                )}
                <div>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => subirImagenProfesional(e.target.files?.[0] || null)}
                    disabled={subiendoImagen}
                    className="font-body text-xs"
                  />
                  {subiendoImagen && <div className="font-body text-xs text-maroon mt-1">Subiendo imagen...</div>}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 mb-3">
              <input
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
                type="number"
                placeholder="Precio en Bs (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
              <input
                value={experiencia}
                onChange={(e) => setExperiencia(e.target.value)}
                placeholder="Experiencia (ej: 20 años)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
            </div>
            <div className="font-body text-[11px] text-inksoft mb-3 -mt-2">
              Si dejás el precio vacío, no se muestra ningún precio (hasta que el profesional lo pase por WhatsApp).
            </div>

            <input
              value={zona}
              onChange={(e) => setZona(e.target.value)}
              placeholder="Zona / barrio (ej: Sopocachi, La Paz)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={direccion}
              onChange={(e) => setDireccion(e.target.value)}
              placeholder="Dirección (opcional, ej: Fortunato Gumiel)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <div className="grid grid-cols-2 gap-3 mb-3">
              <input
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                placeholder="Latitud (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
              <input
                value={lng}
                onChange={(e) => setLng(e.target.value)}
                placeholder="Longitud (opcional)"
                className="px-3.5 py-2.5 rounded-lg border border-line font-body text-sm"
              />
            </div>
            <input
              value={whatsapp}
              onChange={(e) => setWhatsapp(e.target.value)}
              placeholder="WhatsApp (ej: 71234567, sin +591)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={emailProfesional}
              onChange={(e) => setEmailProfesional(e.target.value)}
              type="email"
              placeholder="Email (opcional)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <input
              value={instagram}
              onChange={(e) => setInstagram(e.target.value)}
              placeholder="Instagram u otra red social (opcional)"
              className="w-full px-3.5 py-2.5 rounded-lg border border-line font-body text-sm mb-3"
            />
            <div className="flex gap-2 mb-4 flex-wrap">
              {ICONOS_SERVICIO.map((i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setIcono(i)}
                  className={`w-11 h-11 rounded-lg border flex items-center justify-center ${
                    icono === i ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line text-inksoft'
                  }`}
                >
                  <ServiceIcon kind={i} size={20} />
                </button>
              ))}
            </div>
            {profesionalEditandoId && plan === 'premium' && (
              <div className="bg-panelalt rounded-lg p-3 mb-4">
                <div className="font-body text-xs font-semibold text-ink mb-2">Agenda de turnos (Premium)</div>
                <div className="font-body text-[11px] text-inksoft mb-2">
                  Bloques por día — ej. "Lunes a viernes, 19 a 21" y "Sábados, 9 a 14" son dos bloques distintos.
                </div>
                {editHorarioBloques.length > 0 && (
                  <div className="flex flex-col gap-1.5 mb-3">
                    {editHorarioBloques.map((b) => (
                      <div key={b.id} className="flex items-center justify-between gap-2 bg-panel rounded-md px-2.5 py-2">
                        <div className="font-body text-xs text-ink">
                          <strong>{b.dias.map((d) => DIAS_SEMANA[d].corto).join(', ')}</strong> · {b.desde}–{b.hasta} · {INTERVALOS_TURNO.find((i) => i.min === b.intervaloMin)?.label || `cada ${b.intervaloMin} min`}
                        </div>
                        <button type="button" onClick={() => quitarBloqueAdmin(b.id)} className="text-inksoft border-none bg-transparent leading-none shrink-0">✕</button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex gap-1.5 flex-wrap mb-2">
                  {DIAS_SEMANA.map((d) => (
                    <button
                      key={d.id}
                      type="button"
                      onClick={() => toggleDiaNuevoBloqueAdmin(d.id)}
                      className={`px-2.5 py-1.5 rounded-md border font-body text-xs font-medium ${
                        editNuevoBloqueDias.includes(d.id) ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                      }`}
                    >
                      {d.corto}
                    </button>
                  ))}
                </div>

                <label className="flex items-center gap-1.5 mb-2">
                  <input type="checkbox" checked={editNuevoBloqueTodoElDia} onChange={(e) => setEditNuevoBloqueTodoElDia(e.target.checked)} />
                  <span className="font-body text-xs text-ink">Todo el día</span>
                </label>

                {!editNuevoBloqueTodoElDia && (
                  <div className="flex gap-2 mb-2 items-center">
                    <input
                      type="time"
                      value={editNuevoBloqueDesde}
                      onChange={(e) => setEditNuevoBloqueDesde(e.target.value)}
                      className="px-3 py-2 rounded-lg border border-line font-body text-sm"
                    />
                    <span className="font-body text-xs text-inksoft">a</span>
                    <input
                      type="time"
                      value={editNuevoBloqueHasta}
                      onChange={(e) => setEditNuevoBloqueHasta(e.target.value)}
                      className="px-3 py-2 rounded-lg border border-line font-body text-sm"
                    />
                  </div>
                )}

                <select
                  value={editNuevoBloqueIntervalo}
                  onChange={(e) => setEditNuevoBloqueIntervalo(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-line font-body text-sm bg-panel mb-2"
                >
                  {INTERVALOS_TURNO.map((i) => (
                    <option key={i.min} value={i.min}>{i.label}</option>
                  ))}
                </select>

                <button
                  type="button"
                  onClick={agregarBloqueAdmin}
                  disabled={editNuevoBloqueDias.length === 0}
                  className="w-full py-2 rounded-lg border border-line font-body text-xs text-ink disabled:opacity-50 mb-3"
                >
                  + Agregar bloque
                </button>

                <button
                  type="button"
                  onClick={guardarHorarioAdmin}
                  disabled={guardandoHorarioAdmin}
                  className="px-3.5 py-2 rounded-lg border-none bg-teal text-white font-body text-xs font-semibold disabled:opacity-60"
                >
                  {guardandoHorarioAdmin ? 'Guardando...' : 'Guardar agenda'}
                </button>
                {horarioAdminGuardado && <span className="font-body text-[11px] text-teal ml-2">Guardado ✓</span>}
                <div className="font-body text-[11px] text-inksoft mt-2">
                  Esto es lo mismo que el profesional puede cargar solo desde su perfil — se guarda al toque, no hace falta tocar "Guardar cambios" de abajo.
                </div>
              </div>
            )}

            {errorForm && <div className="font-body text-xs text-maroon mb-3">{errorForm}</div>}
            <button
              type="submit"
              disabled={publicando || subiendoImagen}
              className="w-full py-2.5 rounded-lg border-none bg-maroon text-white font-body text-sm font-semibold"
            >
              {publicando ? (profesionalEditandoId ? 'Guardando...' : 'Publicando...') : (profesionalEditandoId ? 'Guardar cambios' : 'Publicar profesional')}
            </button>
          </form>

          <div className="bg-panel border border-line rounded-xl p-5 mb-8">
            <div className="font-body text-sm font-semibold text-ink mb-2">Importar en lote (desde WhatsApp)</div>
            <div className="font-body text-[11px] text-inksoft mb-2">
              Pegá el texto de un canal/grupo de WhatsApp con varios avisos de oficios o servicios seguidos (título, teléfono y descripción cada uno) — mismo formato que en Anuncios. A diferencia de los anuncios, acá <strong>ningún</strong> importado se publica solo: todos entran a "Solicitudes pendientes" de abajo con rubro y zona sin definir, para que los revises uno por uno, les asignes el rubro/zona real, y uses "Pedir más info" si hace falta antes de aprobar.
            </div>
            <textarea
              value={textoImportarServicios}
              onChange={(e) => setTextoImportarServicios(e.target.value)}
              placeholder="Pegá acá el texto completo copiado de WhatsApp..."
              rows={6}
              className="w-full px-3 py-2.5 rounded-lg border border-line font-body text-xs mb-2"
            />
            <button
              type="button"
              onClick={parsearTextoServicios}
              disabled={!textoImportarServicios.trim()}
              className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
            >
              Detectar avisos
            </button>

            {parseadosServicios.length > 0 && (
              <div className="mt-4">
                <div className="font-body text-xs text-inksoft mb-3">
                  Se detectaron <strong>{parseadosServicios.length}</strong> avisos. Los marcados <span className="text-ochre font-semibold">"texto cortado"</span> además quedan con una nota pidiendo el texto completo — pero insisto: TODOS quedan pendientes de revisión, completo o no.
                </div>

                <div className="flex flex-col gap-2 mb-3 max-h-[480px] overflow-y-auto pr-1">
                  {parseadosServicios.map((p, i) => (
                    <div key={i} className={`border rounded-lg p-3 ${p.incompleto ? 'border-ochre bg-ochresoft' : 'border-line bg-panel'}`}>
                      <div className="flex items-start gap-2 mb-2">
                        <input
                          type="checkbox"
                          checked={p.incluir}
                          onChange={(e) => actualizarParseadoServicio(i, { incluir: e.target.checked })}
                          className="mt-1 shrink-0"
                        />
                        <div className="flex-1 min-w-0">
                          <input
                            value={p.titulo}
                            onChange={(e) => actualizarParseadoServicio(i, { titulo: e.target.value })}
                            className="w-full font-body text-xs font-semibold text-ink bg-transparent border-none p-0 mb-1"
                          />
                          <div className="font-body text-[11px] text-inksoft mb-1">📞 {p.telefono} · {p.fecha}</div>
                          {p.incompleto && (
                            <div className="font-body text-[10px] font-bold text-ochre uppercase mb-1">⚠ Texto cortado — falta info</div>
                          )}
                        </div>
                      </div>
                      <textarea
                        value={p.descripcion}
                        onChange={(e) => actualizarParseadoServicio(i, { descripcion: e.target.value })}
                        rows={2}
                        className="w-full px-2 py-1.5 rounded-md border border-line font-body text-[11px] mb-2"
                      />
                      <a
                        href={`https://wa.me/591${p.telefono.replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block px-2.5 py-1 rounded-md bg-teal text-white font-body text-[11px] font-semibold"
                      >
                        💬 Invitar por WhatsApp
                      </a>
                    </div>
                  ))}
                </div>

                <button
                  type="button"
                  onClick={importarServiciosSeleccionados}
                  disabled={importandoServicios || parseadosServicios.filter((p) => p.incluir).length === 0}
                  className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-50"
                >
                  {importandoServicios
                    ? 'Importando...'
                    : `Importar ${parseadosServicios.filter((p) => p.incluir).length} a revisión`}
                </button>

                {resultadoImportacionServicios && (
                  <div className="mt-2 font-body text-xs text-teal">
                    Se crearon {resultadoImportacionServicios.creados} profesionales, todos pendientes de revisión.
                    {resultadoImportacionServicios.errores.length > 0 && (
                      <div className="text-maroon mt-1">{resultadoImportacionServicios.errores.join(' · ')}</div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>

          {profesionales.filter((p) => p.estado === 'pendiente_revision').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-ochre mb-3">
                Solicitudes pendientes de revisión ({profesionales.filter((p) => p.estado === 'pendiente_revision').length})
              </div>
              {[...profesionales]
                .filter((p) => p.estado === 'pendiente_revision')
                .sort((a, b) => {
                  const orden: Record<string, number> = { alto: 0, medio: 1, bajo: 2 }
                  const oa = orden[a.moderacionIA?.riesgo] ?? 3
                  const ob = orden[b.moderacionIA?.riesgo] ?? 3
                  return oa - ob
                })
                .map((p) => (
                <div key={p.id} className="bg-panel border border-ochre rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  <div className="font-body text-xs text-inksoft mb-1">
                    {buscarRubro(p.rubro)?.label} · {p.zona || 'sin zona'} · WhatsApp: {p.whatsapp}
                    {p.email && <> · Email: {p.email}</>}
                  </div>
                  {p.descripcion && <div className="font-body text-xs text-ink mb-2">{p.descripcion}</div>}
                  <div className="font-body text-[11px] text-inksoft mb-2">
                    {p.precio ? `Bs ${Number(p.precio).toLocaleString('es-BO')}` : 'Precio a convenir'}
                    {p.experiencia && ` · Experiencia: ${p.experiencia}`}
                  </div>
                  <BadgeRiesgoIA moderacionIA={p.moderacionIA} />

                  {pidiendoInfoId === p.id ? (
                    <div className="mt-3">
                      <textarea
                        value={notaPidiendoInfo}
                        onChange={(e) => setNotaPidiendoInfo(e.target.value)}
                        placeholder="¿Qué le pediste? (ej: le pedí una foto más clara, quedé de escribirle el viernes)"
                        rows={2}
                        className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            cambiarEstadoProfesional(p.id, 'info_solicitada', notaPidiendoInfo)
                            setPidiendoInfoId(null)
                            setNotaPidiendoInfo('')
                          }}
                          className="px-3.5 py-1.5 rounded-md border-none bg-ochre text-white font-body text-xs font-semibold"
                        >
                          Guardar y marcar en espera
                        </button>
                        <button
                          onClick={() => { setPidiendoInfoId(null); setNotaPidiendoInfo('') }}
                          className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2 mt-3 flex-wrap">
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'aprobado')}
                        className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                      >
                        Aprobar y publicar
                      </button>
                      <button
                        onClick={() => { setPidiendoInfoId(p.id); setNotaPidiendoInfo(p.notaAdmin || '') }}
                        className="px-3.5 py-1.5 rounded-md border border-ochre font-body text-xs text-ochre"
                      >
                        Pedir más info
                      </button>
                      <button
                        onClick={() => abrirEditarProfesional(p)}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'rechazado')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                      >
                        Rechazar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {profesionales.filter((p) => p.estado === 'info_solicitada').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-indigo-600 mb-3">
                ⏳ Esperando respuesta ({profesionales.filter((p) => p.estado === 'info_solicitada').length})
              </div>
              {profesionales
                .filter((p) => p.estado === 'info_solicitada')
                .map((p) => (
                <div key={p.id} className="bg-panel border border-indigo-200 rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  <div className="font-body text-xs text-inksoft mb-1">
                    {buscarRubro(p.rubro)?.label} · {p.zona || 'sin zona'} · WhatsApp: {p.whatsapp}
                    {p.email && <> · Email: {p.email}</>}
                  </div>
                  {p.notaAdmin && (
                    <div className="font-body text-xs text-indigo-700 bg-indigo-50 rounded-md px-2.5 py-2 mb-2">
                      📝 {p.notaAdmin}
                    </div>
                  )}
                  {pidiendoInfoId === p.id ? (
                    <div className="mt-1">
                      <textarea
                        value={notaPidiendoInfo}
                        onChange={(e) => setNotaPidiendoInfo(e.target.value)}
                        rows={2}
                        className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
                      />
                      <div className="flex gap-2">
                        <button
                          onClick={() => {
                            cambiarEstadoProfesional(p.id, 'info_solicitada', notaPidiendoInfo)
                            setPidiendoInfoId(null)
                            setNotaPidiendoInfo('')
                          }}
                          className="px-3.5 py-1.5 rounded-md border-none bg-indigo-600 text-white font-body text-xs font-semibold"
                        >
                          Actualizar nota
                        </button>
                        <button
                          onClick={() => { setPidiendoInfoId(null); setNotaPidiendoInfo('') }}
                          className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                        >
                          Cancelar
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex gap-2 flex-wrap">
                      <a
                        href={`https://wa.me/${p.whatsapp}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        💬 Escribirle de nuevo
                      </a>
                      <button
                        onClick={() => { setPidiendoInfoId(p.id); setNotaPidiendoInfo(p.notaAdmin || '') }}
                        className="px-3.5 py-1.5 rounded-md border border-indigo-200 font-body text-xs text-indigo-600"
                      >
                        Editar nota
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'aprobado')}
                        className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                      >
                        Aprobar y publicar
                      </button>
                      <button
                        onClick={() => abrirEditarProfesional(p)}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-teal"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'pendiente_revision')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft"
                      >
                        Volver a pendiente
                      </button>
                      <button
                        onClick={() => cambiarEstadoProfesional(p.id, 'rechazado')}
                        className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                      >
                        Rechazar
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {profesionales.filter((p) => p.planEstadoPago === 'informado_pago').length > 0 && (
            <div className="mb-8">
              <div className="font-body text-sm font-semibold text-teal mb-3">
                💳 Pagos de membresía Premium por confirmar ({profesionales.filter((p) => p.planEstadoPago === 'informado_pago').length})
              </div>
              {profesionales
                .filter((p) => p.planEstadoPago === 'informado_pago')
                .map((p) => (
                <div key={p.id} className="bg-panel border border-teal rounded-lg p-4 mb-3">
                  <div className="font-body text-sm font-medium text-ink mb-1">{p.nombre}</div>
                  <div className="font-body text-xs text-inksoft mb-3">
                    WhatsApp: {p.whatsapp}
                    {p.planVigenciaHasta && new Date(p.planVigenciaHasta).getTime() > Date.now() && (
                      <> · Ya tiene Premium vigente hasta {new Date(p.planVigenciaHasta).toLocaleDateString('es-BO')} — confirmar esto se lo extiende 30 días más desde esa fecha</>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => confirmarPagoPremium(p)}
                      className="px-3.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold"
                    >
                      Confirmar pago recibido
                    </button>
                    <button
                      onClick={() => rechazarPagoPremium(p.id)}
                      className="px-3.5 py-1.5 rounded-md border border-line font-body text-xs text-maroon"
                    >
                      No llegó / rechazar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="font-body text-sm font-semibold text-ink mb-3">
            Publicados ({profesionales.filter((p) => !p.estado || p.estado === 'aprobado').length})
          </div>
          {[...profesionales]
            .filter((p) => !p.estado || p.estado === 'aprobado')
            .sort((a, b) => (b.clicsWhatsapp || 0) - (a.clicsWhatsapp || 0))
            .map((p) => (
            <div key={p.id} className="bg-panel border border-line rounded-lg p-3.5 mb-2.5 flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-panelalt flex items-center justify-center text-maroon shrink-0 overflow-hidden">
                {p.imagenUrl ? (
                  <img src={p.thumbUrl || p.imagenUrl} alt={p.nombre} loading="lazy" decoding="async" className="w-full h-full object-cover" />
                ) : (
                  <ServiceIcon kind={p.icono} size={20} />
                )}
              </div>
              <div className="flex-1">
                <div className="font-body text-sm font-medium text-ink">{p.nombre}</div>
                <div className="font-body text-xs text-inksoft">
                  {buscarRubro(p.rubro)?.label} · {p.zona} · {p.plan === 'premium' ? 'Premium' : 'Básico'}
                </div>
                <div className="font-body text-[11px] text-inksoft mt-0.5">
                  👁 {p.vistas || 0} vistas · 💬 {p.clicsWhatsapp || 0} contactos
                </div>
              </div>
              <button
                onClick={() => abrirEditarProfesional(p)}
                className="font-body text-xs text-teal underline shrink-0"
              >
                Editar
              </button>
              <button
                onClick={() => borrarProfesional(p.id)}
                className="font-body text-xs text-maroon underline shrink-0"
              >
                Borrar
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === 'anuncios' && (
        <div>
          {macheos?.totales && (
            <div className="mb-5">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mb-4">
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalVistas}</div>
                  <div className="font-body text-[11px] text-inksoft">Vistas totales</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalMatcheos}</div>
                  <div className="font-body text-[11px] text-inksoft">Matcheos generados</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink">{macheos.totales.totalEmailsEnviados}</div>
                  <div className="font-body text-[11px] text-inksoft">Mails enviados</div>
                </div>
                <div className="bg-panel border border-line rounded-lg p-3">
                  <div className="font-display text-lg font-bold text-ink truncate" title={macheos.totales.anuncioMasVisto?.anuncioTitulo}>
                    {macheos.totales.anuncioMasVisto?.vistas ?? 0}
                  </div>
                  <div className="font-body text-[11px] text-inksoft truncate" title={macheos.totales.anuncioMasVisto?.anuncioTitulo}>
                    Más visto: {macheos.totales.anuncioMasVisto?.anuncioTitulo || '—'}
                  </div>
                </div>
              </div>

              <div className="font-body text-xs font-semibold text-inksoft mb-2">Ranking de anuncios por vistas y matcheos</div>
              <div className="space-y-1.5 mb-1">
                {macheos.porAnuncio.slice(0, 20).map((a: any, i: number) => (
                  <div key={a.anuncioId} className="bg-panel border border-line rounded-lg">
                    <button
                      type="button"
                      onClick={() => setAnuncioExpandido(anuncioExpandido === a.anuncioId ? null : a.anuncioId)}
                      className="w-full flex items-center gap-3 p-2.5 text-left"
                    >
                      <span className="font-body text-[11px] text-inksoft w-5 shrink-0">{i + 1}.</span>
                      <span className="font-body text-xs text-ink flex-1 truncate">{a.anuncioTitulo}</span>
                      <span className="font-body text-[11px] text-inksoft shrink-0">👁 {a.vistas}</span>
                      {a.matcheos > 0 && (
                        <span className="font-body text-[11px] text-teal shrink-0">
                          🎯 {a.matcheos} · ✉️ {a.emailsEnviados}
                        </span>
                      )}
                    </button>
                    {anuncioExpandido === a.anuncioId && (
                      <div className="border-t border-line px-3 py-2.5">
                        {a.destinatarios.length === 0 ? (
                          <div className="font-body text-[11px] text-inksoft">
                            {a.tipo === 'busqueda' ? 'Todavía no matcheó con ningún profesional.' : 'Este tipo de anuncio no genera matcheos automáticos.'}
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <div className="font-body text-[11px] font-semibold text-inksoft mb-1">A quiénes se avisó:</div>
                            {a.destinatarios.map((d: any, j: number) => (
                              <div key={j} className="font-body text-[11px] text-inksoft flex items-center gap-2">
                                <span className={d.emailEnviado ? 'text-teal' : 'text-maroon'}>{d.emailEnviado ? '✓' : '✕'}</span>
                                <span className="text-ink">{d.profesionalNombre || 'Profesional'}</span>
                                <span>{d.email || 'sin email cargado'}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {cargandoMacheos && <div className="font-body text-[11px] text-inksoft">Actualizando...</div>}
            </div>
          )}

          <div className="bg-panel border border-line rounded-xl p-5 mb-8">
            <div className="font-body text-sm font-semibold text-ink mb-1">Matcheos con IA</div>
            <div className="font-body text-[11px] text-inksoft mb-3">
              El matcheo automático de arriba solo cruza por rubro exacto. Este análisis mira los anuncios "Busco X" que se quedaron sin nadie (sin rubro, o rubro sin ningún profesional cargado) y sugiere, leyendo el texto, quién podría igual servir. No manda nada solo — cada sugerencia la aprobás vos, una por una.
            </div>

            <button
              type="button"
              onClick={analizarMatcheosIA}
              disabled={analizandoIA}
              className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
            >
              {analizandoIA ? 'Analizando...' : '🤖 Analizar con IA posibles matcheos'}
            </button>

            {mensajeAnalisisIA && (
              <div className="font-body text-xs text-inksoft mt-3">{mensajeAnalisisIA}</div>
            )}

            {sugerenciasIA && sugerenciasIA.length > 0 && (
              <div className="flex flex-col gap-2.5 mt-4">
                {sugerenciasIA.map((s) => {
                  const clave = `${s.anuncioId}:${s.profesionalId}`
                  const yaEnviada = sugerenciasEnviadas.has(clave)
                  return (
                    <div key={clave} className="border border-line rounded-lg p-3">
                      <div className="font-body text-xs text-inksoft mb-1">
                        <span className="font-semibold text-ink">{s.anuncioTitulo}</span> ↔ <span className="font-semibold text-ink">{s.profesionalNombre}</span>
                        <span className="text-inksoft"> ({s.profesionalRubroLabel})</span>
                      </div>
                      <div className="font-body text-[11px] text-inksoft italic mb-2">💡 {s.motivo}</div>
                      <button
                        type="button"
                        onClick={() => sugerirAAmbasPartes(s)}
                        disabled={yaEnviada || enviandoSugerenciaId === clave}
                        className={`px-3 py-1.5 rounded-md border-none font-body text-[11px] font-semibold disabled:opacity-50 ${
                          yaEnviada ? 'bg-teal text-white' : 'bg-maroon text-white'
                        }`}
                      >
                        {yaEnviada ? '✓ Sugerido a ambas partes' : enviandoSugerenciaId === clave ? 'Enviando...' : 'Sugerir a ambas partes'}
                      </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>

          <div className="font-body text-sm font-semibold text-ink mb-2">Importar en lote (desde WhatsApp)</div>
            <div className="font-body text-[11px] text-inksoft mb-2">
            Pegá el texto copiado de un canal/grupo de WhatsApp con varios avisos seguidos (título, teléfono y descripción cada uno). Se sube a nombre del cliente, sin que tenga cuenta acá — vos revisás cada uno antes de que se publique.
          </div>
          <textarea
            value={textoImportarAnuncios}
            onChange={(e) => setTextoImportarAnuncios(e.target.value)}
            placeholder="Pegá acá el texto completo copiado de WhatsApp..."
            rows={6}
            className="w-full px-3 py-2.5 rounded-lg border border-line font-body text-xs mb-2"
          />
          <button
            type="button"
            onClick={parsearTextoAnuncios}
            disabled={!textoImportarAnuncios.trim()}
            className="px-3.5 py-2 rounded-lg border-none bg-ink text-white font-body text-xs font-semibold disabled:opacity-50"
          >
            Detectar avisos
          </button>

          {parseadosAnuncios.length > 0 && (
            <div className="mt-4">
              <div className="font-body text-xs text-inksoft mb-3">
                Se detectaron <strong>{parseadosAnuncios.length}</strong> avisos. Los marcados <span className="text-ochre font-semibold">"texto cortado"</span> se importan pidiendo más datos en vez de publicarse directo — tenés el botón de WhatsApp al lado de cada uno para pedirle al contacto que te mande el texto completo.
              </div>

              <div className="flex flex-col gap-2 mb-3 max-h-[480px] overflow-y-auto pr-1">
                {parseadosAnuncios.map((p, i) => (
                  <div key={i} className={`border rounded-lg p-3 ${p.incompleto ? 'border-ochre bg-ochresoft' : 'border-line bg-panel'}`}>
                    <div className="flex items-start gap-2 mb-2">
                      <input
                        type="checkbox"
                        checked={p.incluir}
                        onChange={(e) => actualizarParseado(i, { incluir: e.target.checked })}
                        className="mt-1 shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <input
                          value={p.titulo}
                          onChange={(e) => actualizarParseado(i, { titulo: e.target.value })}
                          className="w-full font-body text-xs font-semibold text-ink bg-transparent border-none p-0 mb-1"
                        />
                        <div className="font-body text-[11px] text-inksoft mb-1">📞 {p.telefono} · {p.fecha}</div>
                        {p.incompleto && (
                          <div className="font-body text-[10px] font-bold text-ochre uppercase mb-1">⚠ Texto cortado — falta info</div>
                        )}
                      </div>
                    </div>
                    <textarea
                      value={p.descripcion}
                      onChange={(e) => actualizarParseado(i, { descripcion: e.target.value })}
                      rows={2}
                      className="w-full px-2 py-1.5 rounded-md border border-line font-body text-[11px] mb-2"
                    />
                    <a
                      href={`https://wa.me/591${p.telefono.replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-block px-2.5 py-1 rounded-md bg-teal text-white font-body text-[11px] font-semibold"
                    >
                      💬 Invitar por WhatsApp
                    </a>
                  </div>
                ))}
              </div>

              <button
                type="button"
                onClick={importarAnunciosSeleccionados}
                disabled={importandoAnuncios || parseadosAnuncios.filter((p) => p.incluir).length === 0}
                className="px-3.5 py-2 rounded-lg border-none bg-maroon text-white font-body text-xs font-semibold disabled:opacity-50"
              >
                {importandoAnuncios
                  ? 'Importando...'
                  : `Importar ${parseadosAnuncios.filter((p) => p.incluir).length} seleccionados`}
              </button>

              {resultadoImportacion && (
                <div className="mt-2 font-body text-xs text-teal">
                  Se crearon {resultadoImportacion.creados} anuncios.
                  {resultadoImportacion.errores.length > 0 && (
                    <div className="text-maroon mt-1">{resultadoImportacion.errores.join(' · ')}</div>
                  )}
                </div>
              )}
            </div>
          )}

          <div className="border-t border-line my-6" />

          <div className="font-body text-sm font-semibold text-ink mb-3">
            Anuncios clasificados {anuncios.length > 0 && <span className="text-inksoft font-normal">({anuncios.length})</span>}
          </div>
          {anuncios.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay ningún anuncio publicado.</div>}
          {anuncios
            .slice()
            .sort((a, b) => {
              // Los pendientes de revisar primero — son los que hay que
              // atender; aprobados/rechazados quedan abajo como
              // historial.
              const orden: Record<string, number> = { pendiente_revision: 0, info_solicitada: 1, aprobado: 2, rechazado: 3 }
              return (orden[a.estado] ?? 3) - (orden[b.estado] ?? 3) || (b.createdAt || '').localeCompare(a.createdAt || '')
            })
            .map((a) => (
              <div key={a.id} className="bg-panel border border-line rounded-lg p-3.5 mb-3">
                <div className="flex items-start justify-between gap-3 flex-wrap">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-body text-sm font-medium text-ink">{a.titulo}</span>
                      <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">
                        {labelTipoAnuncio(a.tipo)}
                      </span>
                      {a.estado === 'pendiente_revision' && (
                        <span className="inline-block bg-ochre text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">Pendiente</span>
                      )}
                      {a.estado === 'info_solicitada' && (
                        <span className="inline-block bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">⏳ Falta info</span>
                      )}
                      {a.estado === 'aprobado' && (
                        <span className="inline-block bg-teal text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">Aprobado</span>
                      )}
                      {a.estado === 'rechazado' && (
                        <span className="inline-block bg-maroonsoft text-maroon text-[10px] font-bold px-1.5 py-0.5 rounded-full">Rechazado</span>
                      )}
                      {a.creadoPorAdmin && (
                        <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded" title="Lo subiste vos a nombre de un cliente">
                          Importado
                        </span>
                      )}
                    </div>
                    <div className="font-body text-xs text-inksoft mt-1">{a.descripcion}</div>
                    {a.notaAdmin && (
                      <div className="font-body text-[11px] text-indigo-700 bg-indigo-50 rounded-md px-2.5 py-2 mt-1.5">
                        📝 {a.notaAdmin}
                      </div>
                    )}
                    <div className="font-body text-[11px] text-inksoft mt-1.5">
                      {a.autorEmail || (a.creadoPorAdmin ? 'Importado (sin cuenta)' : '')} · {a.whatsapp || a.telefonoOriginal || 'sin contacto'} {a.precio ? `· Bs ${Number(a.precio).toLocaleString('es-BO')}` : ''}
                    </div>
                    {a.moderacionIA && (
                      <div className={`font-body text-[11px] mt-1.5 ${a.moderacionIA.riesgo === 'alto' ? 'text-maroon' : a.moderacionIA.riesgo === 'medio' ? 'text-ochre' : 'text-inksoft'}`}>
                        🤖 Riesgo {a.moderacionIA.riesgo}: {a.moderacionIA.motivo}
                      </div>
                    )}
                  </div>
                  {a.imagenUrl && (
                    <img src={a.imagenUrl} alt={a.titulo} loading="lazy" className="w-16 h-16 rounded-lg object-cover shrink-0" />
                  )}
                </div>
                <div className="flex gap-2 flex-wrap mt-3">
                  {a.estado !== 'aprobado' && (
                    <button type="button" onClick={() => cambiarEstadoAnuncio(a.id, 'aprobado')} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-[11px] font-semibold">Aprobar</button>
                  )}
                  {(a.whatsapp || a.telefonoOriginal) && a.estado !== 'aprobado' && (
                    <a
                      href={`https://wa.me/${(a.whatsapp || `591${a.telefonoOriginal}`).replace(/\D/g, '')}?text=${encodeURIComponent(mensajeInvitacionAnuncio())}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      onClick={() => cambiarEstadoAnuncioConNota(a.id, 'info_solicitada', a.notaAdmin || 'Se le pidió más información por WhatsApp.')}
                      className="px-2.5 py-1.5 rounded-md border border-indigo-200 font-body text-[11px] text-indigo-600"
                    >
                      💬 Invitar por WhatsApp
                    </a>
                  )}
                  {a.estado !== 'rechazado' && (
                    <button type="button" onClick={() => cambiarEstadoAnuncio(a.id, 'rechazado')} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Rechazar</button>
                  )}
                  <button type="button" onClick={() => eliminarAnuncio(a.id)} className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon">Eliminar</button>
                </div>
              </div>
            ))}
        </div>
      )}

      {tab === 'reparto' && (
        <div>
          <button
            type="button"
            onClick={() => {
              const link = `${window.location.origin}/reparto-hoy?clave=${encodeURIComponent(password)}`
              navigator.clipboard.writeText(link)
              alert('Link copiado — pasáselo al repartidor por WhatsApp. No hace falta que inicie sesión.')
            }}
            className="mb-4 px-3.5 py-2 rounded-md border border-line font-body text-xs font-semibold"
          >
            🔗 Copiar link para el repartidor
          </button>
          {(() => {
            // Solo entran acá los pedidos con envío YA pagados (con
            // stock ya confirmado, porque sin eso ni siquiera llegan a
            // "pagado") y que todavía no salieron a reparto ni se
            // entregaron.
            const listos = pedidos.filter((p: any) => p.metodoEntrega === 'envio' && p.estado === 'pagado')
            const porFranja = (franja: '08:00' | '14:00') =>
              ordenarPorCercania(
                listos.filter((p: any) => calcularFranja(new Date(p.pagadoAt || p.createdAt)) === franja),
                DEPOSITO
              )
            const salida8 = porFranja('08:00')
            const salida14 = porFranja('14:00')

            const Tanda = ({ titulo, tanda }: { titulo: string; tanda: any[] }) => (
              <div className="mb-6">
                <div className="flex items-center justify-between mb-2.5">
                  <div className="font-display text-base font-bold text-ink">{titulo}</div>
                  {tanda.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        if (!confirm(`¿Marcar ${tanda.length} pedido(s) como "en entrega"? Es para cuando la moto ya salió con todos estos.`)) return
                        tanda.forEach((p) => cambiarEstadoPedido(p.id, 'en_entrega'))
                      }}
                      className="px-2.5 py-1.5 rounded-md border-none bg-maroon text-white font-body text-[11px] font-semibold"
                    >
                      Marcar salida de la moto ({tanda.length})
                    </button>
                  )}
                </div>
                {tanda.length === 0 && (
                  <div className="font-body text-xs text-inksoft">No hay pedidos pagados esperando esta salida.</div>
                )}
                {tanda.map((p: any, i: number) => (
                  <div key={p.id} className="bg-panel border border-line rounded-lg p-3 mb-2 flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-maroonsoft text-maroon font-body text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {i + 1}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-body text-[13px] font-medium text-ink">
                        {p.direccion || 'Sin dirección cargada'} · {p.zonaEntrega}
                        {p.entreCalles && ` (${p.entreCalles})`}
                      </div>
                      <div className="font-body text-[11px] text-inksoft">
                        {p.comprador || 'Sin email'} · {bs(p.total)}
                        {(p.lat == null || p.lng == null) && <span className="text-maroon"> · sin ubicación GPS, confirmar dirección a mano</span>}
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <label className="px-2 py-1 rounded-md border border-line font-body text-[10px] font-semibold cursor-pointer">
                        {subiendoFotoEntregaId === p.id ? 'Subiendo...' : '📷 Entregado'}
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          disabled={subiendoFotoEntregaId === p.id}
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) marcarEntregadoConFoto(p.id, file)
                            e.target.value = ''
                          }}
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => cambiarEstadoPedido(p.id, 'entregado')}
                        className="font-body text-[9px] text-inksoft underline"
                      >
                        marcar sin foto
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )

            return (
              <>
                <Tanda titulo="Salida 08:00" tanda={salida8} />
                <Tanda titulo="Salida 14:00" tanda={salida14} />
              </>
            )
          })()}
        </div>
      )}

      {tab === 'banners' && (
        <div>
          <div className="font-body text-sm font-semibold text-ink mb-3">
            Banners promocionales de la home
          </div>
          <div className="font-body text-xs text-inksoft mb-4">
            Se muestran en la página de inicio cuando alguien está en "🏠" (sin filtrar por Mujer/Hombre/Niños). Recomendado: imágenes apaisadas, más anchas que altas.
          </div>

          <div className="bg-panel border border-line rounded-lg p-3.5 mb-5">
            <div className="font-body text-xs font-semibold text-ink mb-2">Agregar banner nuevo</div>
            <input
              type="text"
              value={bannerLinkNuevo}
              onChange={(e) => setBannerLinkNuevo(e.target.value)}
              placeholder="Link opcional a donde lleva (https://...)"
              className="w-full px-3 py-2 rounded-md border border-line font-body text-xs mb-2"
            />
            <input
              type="file"
              accept="image/*"
              onChange={(e) => subirBanner(e.target.files?.[0] || null)}
              disabled={subiendoBanner}
              className="font-body text-xs"
            />
            {subiendoBanner && <div className="font-body text-xs text-inksoft mt-2">Subiendo...</div>}
          </div>

          {banners.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no cargaste ningún banner.</div>}
          {banners.map((b) => (
            <div key={b.id} className="bg-panel border border-line rounded-lg p-3 mb-2.5 flex items-center gap-3">
              <img src={b.imagenUrl} alt="Banner" className="w-24 h-14 rounded object-cover shrink-0 border border-line" />
              <div className="flex-1 min-w-0">
                <div className="font-body text-xs text-ink truncate">{b.link || 'Sin link'}</div>
                <div className="font-body text-[11px] text-inksoft">{b.activo !== false ? 'Activo' : 'Oculto'}</div>
              </div>
              <div className="flex gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => toggleBanner(b.id, b.activo === false)}
                  className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                >
                  {b.activo !== false ? 'Ocultar' : 'Activar'}
                </button>
                <button
                  type="button"
                  onClick={() => eliminarBanner(b.id)}
                  className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon"
                >
                  Eliminar
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === 'usuarios' && (
        <div>
          <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
            <div className="font-body text-sm font-semibold text-ink">
              Usuarios registrados {usuarios.length > 0 && <span className="text-inksoft font-normal">({usuarios.length})</span>}
            </div>
            <input
              type="text"
              value={buscarUsuario}
              onChange={(e) => setBuscarUsuario(e.target.value)}
              placeholder="Buscar por email o nombre..."
              className="px-3 py-1.5 rounded-md border border-line font-body text-xs w-64 max-w-full"
            />
          </div>
          {cargandoUsuarios && <div className="font-body text-sm text-inksoft">Cargando...</div>}
          {!cargandoUsuarios && usuarios.length === 0 && <div className="font-body text-sm text-inksoft">Todavía no hay usuarios registrados.</div>}
          {usuarios
            .filter((u) => {
              const q = buscarUsuario.trim().toLowerCase()
              if (!q) return true
              return (u.email || '').toLowerCase().includes(q) || (u.nombre || '').toLowerCase().includes(q)
            })
            .map((u) => {
              const productosDelUsuario = productos.filter((p) => p.vendedorId === u.uid)
              const profesionalesDelUsuario = profesionales.filter((p) => p.solicitanteUid === u.uid)
              const expandido = usuarioExpandidoId === u.uid
              return (
                <div key={u.uid} className="bg-panel border border-line rounded-lg p-3.5 mb-3">
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="flex-1 min-w-0">
                      <div className="font-body text-sm font-medium text-ink truncate flex items-center gap-2">
                        {u.email || u.nombre || u.uid}
                        {u.pausado && (
                          <span className="inline-block bg-maroonsoft text-maroon text-[10px] font-bold px-1.5 py-0.5 rounded-full">Pausado</span>
                        )}
                      </div>
                      <div className="font-body text-[11px] text-inksoft mt-0.5">
                        Registrado: {u.creadoEl ? new Date(u.creadoEl).toLocaleDateString('es-BO') : '—'}
                        {u.ultimoLogin && <> · Último login: {new Date(u.ultimoLogin).toLocaleDateString('es-BO')}</>}
                      </div>
                      <button
                        type="button"
                        onClick={() => setUsuarioExpandidoId(expandido ? null : u.uid)}
                        className="font-body text-[11px] text-teal font-semibold mt-1"
                      >
                        {productosDelUsuario.length} producto(s) · {profesionalesDelUsuario.length} servicio(s) {expandido ? '▲' : '▼'}
                      </button>
                    </div>
                    <div className="flex gap-2 flex-wrap justify-end">
                      <button
                        type="button"
                        onClick={() => pausarUsuario(u.uid, !u.pausado)}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px]"
                      >
                        {u.pausado ? 'Reactivar' : 'Pausar'}
                      </button>
                      <button
                        type="button"
                        onClick={() => eliminarUsuario(u.uid)}
                        className="px-2.5 py-1.5 rounded-md border border-line font-body text-[11px] text-maroon"
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>

                  {expandido && (
                    <div className="mt-3 pt-3 border-t border-line grid gap-2">
                      {productosDelUsuario.length === 0 && profesionalesDelUsuario.length === 0 && (
                        <div className="font-body text-xs text-inksoft">No tiene productos ni perfiles profesionales publicados.</div>
                      )}
                      {productosDelUsuario.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 font-body text-xs text-ink">
                          <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">Producto</span>
                          {p.nombre} · Bs {Number(p.precio || 0).toLocaleString('es-BO')} · {p.estado || 'activo'}{p.plan === 'premium' && ' · Premium'}
                        </div>
                      ))}
                      {profesionalesDelUsuario.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 font-body text-xs text-ink">
                          <span className="inline-block bg-panelalt text-inksoft text-[10px] font-semibold px-1.5 py-0.5 rounded">Servicio</span>
                          {p.nombre} · {p.especialidad || buscarRubro(p.rubro)?.label || 'Sin rubro'} · {p.estado}{p.plan === 'premium' && ' · Premium'}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )
            })}
        </div>
      )}

      {tab === 'categorias' && (
        <div>
          <div className="font-body text-sm text-inksoft mb-4">
            Acá se arma el árbol Categoría → Rubro que se usa en el selector de /servicios y en el formulario de publicar servicio.
            Salud, Ingeniería, etc. vienen con rubros de base; podés agregar categorías o rubros nuevos, y mover un rubro si quedó en la categoría que no corresponde.
          </div>

          <form onSubmit={crearCategoria} className="bg-panel border border-line rounded-lg p-4 mb-6 flex gap-2 items-center">
            <input
              value={nuevaCategoriaLabel}
              onChange={(e) => setNuevaCategoriaLabel(e.target.value)}
              placeholder="Nombre de la categoría nueva (ej: Tecnología)"
              className="flex-1 px-3 py-2 rounded-md border border-line font-body text-sm"
            />
            <button
              type="submit"
              disabled={guardandoCategoria}
              className="px-3.5 py-2 rounded-md border-none bg-maroon text-white font-body text-xs font-semibold shrink-0"
            >
              {guardandoCategoria ? 'Agregando...' : '+ Agregar categoría'}
            </button>
          </form>

          {errorCategorias && <div className="font-body text-xs text-maroon mb-4">{errorCategorias}</div>}

          {categorias.map((cat) => (
            <div key={cat.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
              <div className="flex items-center justify-between gap-2 mb-2">
                {renombrandoCategoriaId === cat.id ? (
                  <div className="flex gap-2 flex-1">
                    <input
                      value={nuevoNombreCategoria}
                      onChange={(e) => setNuevoNombreCategoria(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                    />
                    <button onClick={() => renombrarCategoria(cat.id)} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold">
                      Guardar
                    </button>
                    <button onClick={() => { setRenombrandoCategoriaId(null); setNuevoNombreCategoria('') }} className="px-2.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft">
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="font-display text-base font-bold text-ink">{cat.label}</div>
                    <button
                      onClick={() => { setRenombrandoCategoriaId(cat.id); setNuevoNombreCategoria(cat.label) }}
                      className="font-body text-xs text-inksoft underline shrink-0"
                    >
                      Renombrar
                    </button>
                  </>
                )}
              </div>

              <div className="flex flex-col gap-1.5 mb-3">
                {cat.rubros.length === 0 && (
                  <div className="font-body text-xs text-inksoft">Todavía sin rubros.</div>
                )}
                {cat.rubros.map((r) => (
                  <div key={r.id} className="flex items-center justify-between gap-2 bg-panelalt rounded-md px-2.5 py-1.5">
                    <span className="font-body text-sm text-ink">
                      {r.grupo && <span className="text-inksoft">{r.grupo.label} › </span>}
                      {r.label}
                    </span>
                    <select
                      value={cat.id}
                      onChange={(e) => moverRubro(r.id, e.target.value)}
                      className="px-2 py-1 rounded-md border border-line font-body text-[11px] bg-panel shrink-0"
                      title="Mover este rubro a otra categoría"
                    >
                      {categorias.map((c2) => (
                        <option key={c2.id} value={c2.id}>{c2.label}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              {categoriaAbierta === cat.id ? (
                <div className="flex gap-2">
                  <input
                    value={nuevoRubroLabel}
                    onChange={(e) => setNuevoRubroLabel(e.target.value)}
                    placeholder="Nombre del rubro (ej: Kinesiólogo)"
                    className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                  />
                  <button
                    onClick={() => crearRubro(cat.id)}
                    disabled={guardandoRubro}
                    className="px-3 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                  >
                    Guardar
                  </button>
                  <button
                    onClick={() => { setCategoriaAbierta(null); setNuevoRubroLabel('') }}
                    className="px-3 py-1.5 rounded-md border border-line font-body text-xs text-inksoft shrink-0"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { setCategoriaAbierta(cat.id); setNuevoRubroLabel('') }}
                  className="font-body text-xs text-maroon underline"
                >
                  + Agregar rubro en {cat.label}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'categorias-productos' && (
        <div>
          <div className="font-body text-sm text-inksoft mb-4">
            Acá se arma el árbol Categoría → Rubro que se usa para clasificar los productos (selector en /vender, filtros del catálogo y ficha del producto).
            Calzado, Ropa, Accesorios y Hogar vienen con rubros de base; podés agregar categorías o rubros nuevos, y mover un rubro si quedó en la categoría que no corresponde.
          </div>

          <form onSubmit={crearCategoriaProducto} className="bg-panel border border-line rounded-lg p-4 mb-6 flex gap-2 items-center">
            <input
              value={nuevaCategoriaProductoLabel}
              onChange={(e) => setNuevaCategoriaProductoLabel(e.target.value)}
              placeholder="Nombre de la categoría nueva (ej: Electrónica)"
              className="flex-1 px-3 py-2 rounded-md border border-line font-body text-sm"
            />
            <button
              type="submit"
              disabled={guardandoCategoriaProducto}
              className="px-3.5 py-2 rounded-md border-none bg-maroon text-white font-body text-xs font-semibold shrink-0"
            >
              {guardandoCategoriaProducto ? 'Agregando...' : '+ Agregar categoría'}
            </button>
          </form>

          {errorCategoriasProductos && <div className="font-body text-xs text-maroon mb-4">{errorCategoriasProductos}</div>}

          {categoriasProductos.map((cat) => (
            <div key={cat.id} className="bg-panel border border-line rounded-lg p-4 mb-3">
              <div className="flex items-center justify-between gap-2 mb-2">
                {renombrandoCategoriaProductoId === cat.id ? (
                  <div className="flex gap-2 flex-1">
                    <input
                      value={nuevoNombreCategoriaProducto}
                      onChange={(e) => setNuevoNombreCategoriaProducto(e.target.value)}
                      className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                    />
                    <button onClick={() => renombrarCategoriaProducto(cat.id)} className="px-2.5 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold">
                      Guardar
                    </button>
                    <button onClick={() => { setRenombrandoCategoriaProductoId(null); setNuevoNombreCategoriaProducto('') }} className="px-2.5 py-1.5 rounded-md border border-line font-body text-xs text-inksoft">
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="font-display text-base font-bold text-ink">{cat.label}</div>
                    <button
                      onClick={() => { setRenombrandoCategoriaProductoId(cat.id); setNuevoNombreCategoriaProducto(cat.label) }}
                      className="font-body text-xs text-inksoft underline shrink-0"
                    >
                      Renombrar
                    </button>
                  </>
                )}
              </div>

              <div className="flex flex-col gap-1.5 mb-3">
                {cat.rubros.length === 0 && (
                  <div className="font-body text-xs text-inksoft">Todavía sin rubros.</div>
                )}
                {cat.rubros.map((r) => (
                  <div key={r.id} className="flex items-center justify-between gap-2 bg-panelalt rounded-md px-2.5 py-1.5">
                    <span className="font-body text-sm text-ink">{r.label}</span>
                    <select
                      value={cat.id}
                      onChange={(e) => moverRubroProducto(r.id, e.target.value)}
                      className="px-2 py-1 rounded-md border border-line font-body text-[11px] bg-panel shrink-0"
                      title="Mover este rubro a otra categoría"
                    >
                      {categoriasProductos.map((c2) => (
                        <option key={c2.id} value={c2.id}>{c2.label}</option>
                      ))}
                    </select>
                  </div>
                ))}
              </div>

              {categoriaProductoAbierta === cat.id ? (
                <div className="flex gap-2">
                  <input
                    value={nuevoRubroProductoLabel}
                    onChange={(e) => setNuevoRubroProductoLabel(e.target.value)}
                    placeholder="Nombre del rubro (ej: Mochilas)"
                    className="flex-1 px-2.5 py-1.5 rounded-md border border-line font-body text-sm"
                  />
                  <button
                    onClick={() => crearRubroProducto(cat.id)}
                    disabled={guardandoRubroProducto}
                    className="px-3 py-1.5 rounded-md border-none bg-teal text-white font-body text-xs font-semibold shrink-0"
                  >
                    Guardar
                  </button>
                  <button
                    onClick={() => { setCategoriaProductoAbierta(null); setNuevoRubroProductoLabel('') }}
                    className="px-3 py-1.5 rounded-md border border-line font-body text-xs text-inksoft shrink-0"
                  >
                    Cancelar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { setCategoriaProductoAbierta(cat.id); setNuevoRubroProductoLabel('') }}
                  className="font-body text-xs text-maroon underline"
                >
                  + Agregar rubro en {cat.label}
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {tab === 'metricas' && (
        <div>
          {cargandoMetricas && <div className="font-body text-sm text-inksoft">Cargando métricas...</div>}
          {!cargandoMetricas && metricas?.error && (
            <div className="font-body text-sm text-maroon bg-panelalt border border-line rounded-lg p-3">
              No se pudieron cargar las métricas: {metricas.error}. Probá recargar la pestaña — si sigue igual, revisá los logs de la función /api/admin/metricas en Vercel.
            </div>
          )}
          {!cargandoMetricas && !metricas && (
            <div className="font-body text-sm text-inksoft">Todavía no se cargó nada — probá cambiar de pestaña y volver acá.</div>
          )}
          {!cargandoMetricas && metricas && !metricas.error && (
            <div>
              {metricas.flujoCaja && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">💰 Flujo de caja — Membresías Premium</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Es el único ingreso real y verificado que recibe la plataforma — los pedidos del marketplace se cobran directo al vendedor por su propio QR, no pasan por tu cuenta. Incluye tanto a profesionales como a vendedores de productos con Premium. El histórico de pagos se empezó a registrar recién, así que "histórico" cuenta solo desde ahora en adelante.
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-5">
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos confirmados (histórico)</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.pagosConfirmadosHistorico}</div>
                      <div className="font-body text-[11px] text-inksoft">{bs(metricas.flujoCaja.facturadoHistorico)}</div>
                    </div>
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos este mes</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.pagosEsteMes}</div>
                      <div className="font-body text-[11px] text-inksoft">{bs(metricas.flujoCaja.facturadoEsteMes)}</div>
                    </div>
                    <div className="bg-panel border border-teal rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Premium vigentes ahora</div>
                      <div className="font-display text-lg font-bold text-teal">{metricas.flujoCaja.premiumVigentesAhora}</div>
                      <div className="font-body text-[11px] text-inksoft">Tu ingreso recurrente actual</div>
                    </div>
                    <div className="bg-ochresoft border border-ochre rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Pagos por confirmar</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.porConfirmar}</div>
                      <div className="font-body text-[11px] text-inksoft">Dicen que ya pagaron — revisalos abajo, en "Servicios profesionales"</div>
                    </div>
                    <div className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Vencen en 7 días</div>
                      <div className="font-display text-lg font-bold text-ink">{metricas.flujoCaja.venciendoEn7Dias}</div>
                      <div className="font-body text-[11px] text-inksoft">Riesgo de no renovar</div>
                    </div>
                    <div className="bg-maroonsoft border border-maroon rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">Proyección próx. 30 días</div>
                      <div className="font-display text-lg font-bold text-maroon">{bs(metricas.flujoCaja.proyeccionProximos30Dias)}</div>
                      <div className="font-body text-[11px] text-inksoft">Si todos los vigentes renuevan</div>
                    </div>
                  </div>
                </>
              )}

              <div className="font-body text-sm font-semibold text-ink mb-1">Evolución en el tiempo</div>
              <div className="font-body text-[11px] text-inksoft mb-3">
                Visitas, vistas, clics y búsquedas se empiezan a contar día a día desde ahora — antes solo se guardaba un total acumulado, sin saber qué día. Pedidos, productos y profesionales publicados sí muestran toda la historia, porque ya tenían fecha guardada.
              </div>

              {metricas.comparativaSemanal && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-4">
                  {(
                    [
                      ['Visitas', metricas.comparativaSemanal.estaSemana.visitas, metricas.comparativaSemanal.cambioVisitas],
                      ['Pedidos', metricas.comparativaSemanal.estaSemana.pedidos, metricas.comparativaSemanal.cambioPedidos],
                      ['Facturado', metricas.comparativaSemanal.estaSemana.facturado, metricas.comparativaSemanal.cambioFacturado],
                    ] as [string, number, number | null][]
                  ).map(([label, valor, cambio]) => (
                    <div key={label} className="bg-panel border border-line rounded-lg p-3">
                      <div className="font-body text-[10px] text-inksoft mb-0.5">{label} · últimos 7 días</div>
                      <div className="font-display text-lg font-bold text-ink">
                        {label === 'Facturado' ? bs(valor) : valor.toLocaleString('es-BO')}
                      </div>
                      {cambio != null && (
                        <div className={`font-body text-[11px] font-semibold ${cambio >= 0 ? 'text-teal' : 'text-maroon'}`}>
                          {cambio >= 0 ? '↑' : '↓'} {Math.abs(cambio)}% vs. semana anterior
                        </div>
                      )}
                    </div>
                  ))}
                  <div className="bg-panel border border-line rounded-lg p-3">
                    <div className="font-body text-[10px] text-inksoft mb-0.5">Conversión aprox. · últimos 7 días</div>
                    <div className="font-display text-lg font-bold text-ink">
                      {metricas.comparativaSemanal.estaSemana.visitas > 0
                        ? `${((metricas.comparativaSemanal.estaSemana.pedidos / metricas.comparativaSemanal.estaSemana.visitas) * 100).toFixed(1)}%`
                        : '—'}
                    </div>
                    <div className="font-body text-[11px] text-inksoft">Pedidos / visitas — si baja, el problema es más de conversión que de tráfico.</div>
                  </div>
                </div>
              )}

              <div className="flex gap-3 mb-3 flex-wrap items-center">
                <div className="flex gap-1 bg-panelalt border border-line rounded-lg p-1">
                  {(['dia', 'mes', 'anio'] as const).map((p) => (
                    <button
                      key={p}
                      onClick={() => setPeriodoMetricas(p)}
                      className={`px-3 py-1.5 rounded-md font-body text-xs font-semibold ${periodoMetricas === p ? 'bg-panel text-ink' : 'text-inksoft'}`}
                    >
                      {p === 'dia' ? 'Por día' : p === 'mes' ? 'Por mes' : 'Por año'}
                    </button>
                  ))}
                </div>
                <select
                  value={campoMetricas}
                  onChange={(e) => setCampoMetricas(e.target.value as keyof typeof CAMPOS_METRICAS)}
                  className="px-3 py-1.5 rounded-lg border border-line font-body text-xs bg-panel"
                >
                  {Object.entries(CAMPOS_METRICAS).map(([campo, info]) => (
                    <option key={campo} value={campo}>{info.label}</option>
                  ))}
                </select>
              </div>

              <div className="bg-panel border border-line rounded-xl p-4 mb-8">
                <GraficoBarras
                  datos={(
                    periodoMetricas === 'dia' ? metricas.serieDiaria
                    : periodoMetricas === 'mes' ? metricas.serieMensual
                    : metricas.serieAnual
                  ).map((p: any) => ({ clave: p.clave, valor: p[campoMetricas] || 0 }))}
                  color={CAMPOS_METRICAS[campoMetricas].color}
                  formatoEtiqueta={(clave) =>
                    periodoMetricas === 'dia' ? clave.slice(5).replace('-', '/')
                    : periodoMetricas === 'mes' ? clave
                    : clave
                  }
                />
              </div>

              {metricas.porDiaSemana?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">¿Qué día se mueve más?</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Suma de toda la historia disponible, agrupada por día de la semana — para decidir, por ejemplo, qué día conviene publicar una oferta o subir precio de un servicio con más demanda.
                  </div>
                  <div className="bg-panel border border-line rounded-xl p-4 mb-8">
                    <GraficoBarras
                      datos={metricas.porDiaSemana.map((p: any) => ({ clave: p.clave, valor: p[campoMetricas] || 0 }))}
                      color={CAMPOS_METRICAS[campoMetricas].color}
                      formatoEtiqueta={(clave) => clave.slice(0, 3)}
                    />
                  </div>
                </>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-8">
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Usuarios registrados</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    {metricas.usuariosTotal != null ? metricas.usuariosTotal : '—'}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Total facturado</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    Bs {Number(metricas.pedidos?.totalFacturado || 0).toLocaleString('es-BO')}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Pedidos totales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.pedidos?.total ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Productos publicados</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.productos?.total ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Profesionales aprobados</div>
                  <div className="font-display text-2xl font-bold text-ink">
                    {metricas.profesionales?.porEstado?.aprobado ?? 0}
                  </div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Reseñas totales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalResenas ?? 0}</div>
                </div>
              </div>

              <div className="font-body text-sm font-semibold text-ink mb-3">Pedidos por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.pedidos?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft">{ESTADOS_LABEL[estado]?.texto || estado}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
              </div>

              <div className="font-body text-sm font-semibold text-ink mb-3">Productos por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.productos?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft capitalize">{estado}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
                <div className="bg-ochresoft border border-ochre rounded-lg px-3 py-2">
                  <div className="font-body text-[11px] text-inksoft">premium</div>
                  <div className="font-display text-lg font-bold text-ink">{metricas.productos?.premium ?? 0}</div>
                </div>
              </div>

              {metricas.productosMasVistos?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Productos más vistos</div>
                  <div className="mb-8">
                    {metricas.productosMasVistos.map((p: any, i: number) => (
                      <div key={p.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {p.nombre}</span>
                        <span className="font-body text-xs text-inksoft">{p.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="font-body text-sm font-semibold text-ink mb-3">Anuncios por estado</div>
              <div className="flex flex-wrap gap-2 mb-8">
                {Object.entries(metricas.anuncios?.porEstado || {}).map(([estado, cant]) => (
                  <div key={estado} className="bg-panelalt border border-line rounded-lg px-3 py-2">
                    <div className="font-body text-[11px] text-inksoft capitalize">{estado.replace('_', ' ')}</div>
                    <div className="font-display text-lg font-bold text-ink">{cant as number}</div>
                  </div>
                ))}
                <div className="bg-panel border border-line rounded-lg px-3 py-2">
                  <div className="font-body text-[11px] text-inksoft">vistas totales</div>
                  <div className="font-display text-lg font-bold text-ink">{metricas.anuncios?.totalVistas ?? 0}</div>
                </div>
              </div>

              {metricas.anunciosMasVistos?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Anuncios más vistos</div>
                  <div className="mb-8">
                    {metricas.anunciosMasVistos.map((a: any, i: number) => (
                      <div key={a.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {a.titulo}</span>
                        <span className="font-body text-xs text-inksoft">{a.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="grid grid-cols-2 gap-3 mb-8">
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Vistas de perfiles profesionales</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalVistas ?? 0}</div>
                </div>
                <div className="bg-panel border border-line rounded-xl p-4">
                  <div className="font-body text-[11px] text-inksoft mb-1">Clics a WhatsApp (profesionales)</div>
                  <div className="font-display text-2xl font-bold text-ink">{metricas.profesionales?.totalClicsWhatsapp ?? 0}</div>
                </div>
              </div>

              {metricas.profesionalesMasClicWhatsapp?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-3">Profesionales con más contactos por WhatsApp</div>
                  <div className="mb-8">
                    {metricas.profesionalesMasClicWhatsapp.map((p: any, i: number) => (
                      <div key={p.id} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">{i + 1}. {p.nombre}</span>
                        <span className="font-body text-xs text-inksoft">{p.clicsWhatsapp} clics · {p.vistas} vistas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              {metricas.categoriasMasBuscadas?.length > 0 && (
                <>
                  <div className="font-body text-sm font-semibold text-ink mb-1">Categorías y rubros más buscados</div>
                  <div className="font-body text-[11px] text-inksoft mb-3">
                    Para identificar nichos rentables — esto es lo que la gente filtra de verdad, no una suposición.
                  </div>
                  <div className="mb-4">
                    {metricas.categoriasMasBuscadas.map((c: any, i: number) => (
                      <div key={`${c.tipo}-${c.valor}`} className="flex items-center justify-between py-2 border-b border-line">
                        <span className="font-body text-sm text-ink">
                          {i + 1}. {c.valor} <span className="text-inksoft text-xs">({c.tipo === 'producto' ? 'producto' : 'servicio'})</span>
                        </span>
                        <span className="font-body text-xs text-inksoft">{c.clics} búsquedas</span>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="font-body text-[11px] text-inksoft mt-4">
                Todos estos números salen de datos reales de Firestore y Firebase Auth — no hay estimaciones ni cifras infladas.
              </div>
            </div>
          )}
          {!cargandoMetricas && metricas?.error && (
            <div className="font-body text-sm text-maroon">{metricas.error}</div>
          )}
        </div>
      )}
    </div>
  )
}