'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Producto } from '@/data/productos'
import { PRODUCTOS_SEED } from '@/data/productos'
import { ProductCard } from '@/components/ProductCard'
import { CartDrawer } from '@/components/CartDrawer'
import { NotificacionesBell } from '@/components/NotificacionesBell'
import { BannerCarousel } from '@/components/BannerCarousel'
import { useCarrito } from '@/lib/store'
import { useAuth } from '@/lib/auth'
import { useCategoriasProductos } from '@/lib/useCategoriasProductos'
import { PUBLICOS_PRODUCTO } from '@/data/publicoProducto'

export default function CatalogoPage() {
  const { categorias: categoriasProductos, buscarRubroProducto } = useCategoriasProductos()
  const [productos, setProductos] = useState<Producto[]>(PRODUCTOS_SEED)
  const [publico, setPublico] = useState('Todo')
  const [categoria, setCategoria] = useState('Todo')
  const [busqueda, setBusqueda] = useState('')
  const [carritoAbierto, setCarritoAbierto] = useState(false)
  const { items } = useCarrito()
  const { usuario, logout } = useAuth()

  useEffect(() => {
    fetch('/api/productos')
      .then((r) => r.json())
      .then((data) => {
        if (data.productos) setProductos(data.productos)
      })
      .catch(() => {
        // Si falla la carga (por ejemplo, Firebase no configurado todavía
        // en desarrollo), nos quedamos con el catálogo semilla local.
      })
  }, [])

  const filtrados = productos.filter((p) => {
    const matchPublico = publico === 'Todo' || (p.publico || 'unisex') === publico
    const matchCat = categoria === 'Todo' || buscarRubroProducto(p.rubro)?.categoriaId === categoria
    const matchBusqueda =
      p.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      p.vendedor.toLowerCase().includes(busqueda.toLowerCase())
    return matchPublico && matchCat && matchBusqueda
  })

  // Solo entran acá los descuentos reales (precioOriginal cargado por
  // el propio vendedor y mayor al precio actual) — nada de porcentajes
  // inventados para la sección de ofertas.
  const ofertas = productos.filter((p) => p.precioOriginal && p.precioOriginal > p.precio).slice(0, 8)

  const cantidadCarrito = items.reduce((s, i) => s + i.cantidad, 0)
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    if (typeof window === 'undefined') return
    const params = new URLSearchParams(window.location.search)
    const q = params.get('q') || ''
    if (q) setBusqueda(q)
  }, [])

  return (
    <div className="min-h-screen">
      <div className="bg-ink px-4 sm:px-5 py-3">
        <div className="max-w-[960px] mx-auto">
          <div className="flex items-center gap-3 mb-2.5">
            <Link href="/" className="font-display text-xl font-bold text-white shrink-0">Clasi Click</Link>
            <div className="flex-1" />
            <button
              onClick={() => setCarritoAbierto(true)}
              className="border-none bg-white/10 text-white px-3 sm:px-4 py-2 rounded-lg font-body text-sm shrink-0 whitespace-nowrap"
            >
              🛒 {cantidadCarrito > 0 && `(${cantidadCarrito})`}
            </button>
          </div>

          <div className="flex items-center gap-2 mb-2.5">
            <input
              value={busqueda}
              onChange={(e) => setBusqueda(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  const q = encodeURIComponent(busqueda || '')
                  router.push(`${pathname}${q ? `?q=${q}` : ''}`)
                }
              }}
              placeholder="Buscar productos o vendedores"
              className="flex-1 px-3.5 py-2 rounded-lg border-none bg-white/10 text-white font-body text-sm outline-none placeholder:text-white/50 min-w-0"
            />
            <button
              type="button"
              onClick={() => {
                const q = encodeURIComponent(busqueda || '')
                router.push(`${pathname}${q ? `?q=${q}` : ''}`)
              }}
              className="px-3 py-2 rounded-lg bg-white/20 text-white text-sm shrink-0"
              aria-label="Buscar"
            >
              🔍
            </button>
          </div>

          <div className="flex items-center gap-4 overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0" style={{ scrollbarWidth: 'none' }}>
            <Link href="/servicios" className="border-none bg-transparent text-white/80 font-body text-[13px] shrink-0 whitespace-nowrap">
              Servicios
            </Link>
            <Link href="/anuncios" className="border-none bg-transparent text-white/80 font-body text-[13px] shrink-0 whitespace-nowrap">
              Anuncios
            </Link>
            <Link href="/ayuda" className="border-none bg-transparent text-white/60 font-body text-[13px] shrink-0 whitespace-nowrap">
              Ayuda
            </Link>
            <Link href="/vender" className="border-none bg-white/10 text-white px-3 py-1.5 rounded-lg font-body text-[13px] shrink-0 whitespace-nowrap">
              Vender
            </Link>
            {usuario ? (
              <>
                <Link href="/mis-pedidos" className="border-none bg-transparent text-white/80 font-body text-[13px] shrink-0 whitespace-nowrap">
                  Mis pedidos
                </Link>
                <NotificacionesBell variante="oscura" />
                <button onClick={() => logout()} className="border-none bg-transparent text-white/60 font-body text-[12px] shrink-0 whitespace-nowrap">
                  {usuario.email?.split('@')[0]} · salir
                </button>
              </>
            ) : (
              <Link href="/login" className="border-none bg-transparent text-white/80 font-body text-[13px] shrink-0 whitespace-nowrap">
                Iniciar sesión
              </Link>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-[960px] mx-auto px-4 sm:px-5 py-5 sm:py-6 pb-12">
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="bg-panel border-2 border-maroon rounded-xl p-4 sm:p-5 text-center">
            <div className="text-2xl mb-1">🛍️</div>
            <div className="font-display text-sm sm:text-base font-bold text-ink">Productos</div>
            <div className="font-body text-[11px] sm:text-xs text-inksoft">Comprá acá abajo</div>
          </div>
          <Link
            href="/servicios"
            className="bg-teal border-2 border-teal rounded-xl p-4 sm:p-5 text-center"
          >
            <div className="text-2xl mb-1">🧑‍🔧</div>
            <div className="font-display text-sm sm:text-base font-bold text-white">Servicios</div>
            <div className="font-body text-[11px] sm:text-xs text-white/80">Profesionales</div>
          </Link>
        </div>

        {ofertas.length > 0 && (
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-lg">🔥</span>
              <div className="font-display text-base font-bold text-ink">Ofertas</div>
            </div>
            <div className="flex gap-3 overflow-x-auto pb-1 -mx-4 px-4 sm:mx-0 sm:px-0" style={{ scrollbarWidth: 'none' }}>
              {ofertas.map((p) => (
                <div key={p.id} className="w-40 sm:w-44 shrink-0">
                  <ProductCard p={p} />
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-2 mb-3 flex-wrap items-center">
          <button
            onClick={() => { setPublico('Todo'); setCategoria('Todo') }}
            aria-label="Ver todo"
            title="Ver todo"
            className={`w-9 h-9 rounded-full border flex items-center justify-center text-base shrink-0 ${
              publico === 'Todo' ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
            }`}
          >
            🏠
          </button>
          {PUBLICOS_PRODUCTO.map((pub) => (
            <button
              key={pub.id}
              onClick={() => setPublico(pub.id)}
              className={`px-4 py-1.5 rounded-full border font-body text-sm font-medium ${
                publico === pub.id ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
              }`}
            >
              {pub.label}
            </button>
          ))}
        </div>

        {publico === 'Todo' ? (
          <BannerCarousel />
        ) : (
          <div className="flex gap-2 mb-5 flex-wrap">
            <button
              onClick={() => setCategoria('Todo')}
              className={`px-4 py-1.5 rounded-full border font-body text-sm font-medium ${
                categoria === 'Todo' ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
              }`}
            >
              Todo
            </button>
            {categoriasProductos.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setCategoria(c.id)
                  fetch('/api/analitica/categoria', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ tipo: 'producto', valor: c.label }),
                  }).catch(() => {})
                }}
                className={`px-4 py-1.5 rounded-full border font-body text-sm font-medium ${
                  categoria === c.id ? 'border-maroon bg-maroonsoft text-maroon' : 'border-line bg-panel text-inksoft'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {filtrados.map((p) => (
            <ProductCard key={p.id} p={p} />
          ))}
        </div>

        {filtrados.length === 0 && (
          <div className="text-center py-14 text-inksoft font-body text-sm">
            No encontramos productos para esa búsqueda.
          </div>
        )}
      </div>

      {carritoAbierto && <CartDrawer onClose={() => setCarritoAbierto(false)} />}
    </div>
  )
}
